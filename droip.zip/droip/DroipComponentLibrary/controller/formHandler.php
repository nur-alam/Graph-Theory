<?php

namespace ComponentLib\Controller;

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

use WP_Error;
use WP_REST_Server;
use WP_REST_Controller;
use WP_REST_Response;
use WP_User;

class AuthFormHandler extends WP_REST_Controller
{
  protected $rest_base = 'Auth';
  protected $namespace = DROIP_COMPONENT_LIBRARY_APP_PREFIX . '/v1';

  public function __construct()
  {
    $this->init_rest_api_endpoint('droip-login', WP_REST_Server::CREATABLE, array($this, 'handle_login'));
    $this->init_rest_api_endpoint('droip-register', WP_REST_Server::CREATABLE, array($this, 'handle_register'));
    $this->init_rest_api_endpoint('droip-forgot-password', WP_REST_Server::CREATABLE, array($this, 'handle_forgot_password'));
  }

  public function init_rest_api_endpoint($endpoint, $methods, $callback)
  {
    add_action('rest_api_init', function () use ($endpoint, $methods, $callback) {
      register_rest_route(
        $this->namespace,
        '/' . $this->rest_base . '/' . $endpoint,
        array(
          array(
            'methods'             => $methods,
            'callback'            => $callback,
            'permission_callback' => array($this, 'get_item_permissions_check'),
            'args'                => $this->get_endpoint_args_for_item_schema($methods),
          ),
          'schema' => array($this, 'get_item_schema'),
        )
      );
    });
  }

  public function get_item_permissions_check($request)
  {
    return true;
  }

  function wp_unique_username($username, $suffix = 1)
  {
    $original_username = $username;
    while (username_exists($username)) {
      $username = $original_username . '_' . $suffix++;
    }
    return $username;
  }

  function handle_login($request)
  {
    $form_data = $request->get_body_params();
    $username = isset($form_data['username']) ? sanitize_text_field($form_data['username']) : '';
    $password = isset($form_data['password']) ? sanitize_text_field($form_data['password']) : '';

    if (
      isset($username) && strlen($username) > 0 &&
      isset($password) && strlen($password) > 0
    ) {
      $user = wp_signon(array(
        'user_login' => $username,
        'user_password' => $password,
        'remember' => true
      ));

      if (is_wp_error($user)) {
        $response = array(
          'message' => $user->errors[array_key_first($user->errors)],
        );
        return new WP_REST_Response($response, 500);
      }
      $response = array(
        'message' => 'User logged in',
        'user' => array(
          'username' => $user->get('user_login'),
          'id' => $user->get('ID'),
          'display_name' => $user->get('display_name'),
          'email' => $user->get('user_email'),
          'user_type' => $user->get('user_type')
        )
      );
      return new WP_REST_Response($response, 200);
    }
    $response = array(
      'message' => 'Invalid form data',
    );
    return new WP_REST_Response($response, 400);
  }

  function handle_register($request)
  {
    $form_data = $request->get_body_params();
    $username = isset($form_data['username']) ? sanitize_text_field($form_data['username']) : '';
    $email = isset($form_data['email']) ? sanitize_email($form_data['email']) : '';
    $password = isset($form_data['password']) ? sanitize_text_field($form_data['password']) : '';
    $confirm_password = isset($form_data['confirm_password']) ? sanitize_text_field($form_data['confirm_password']) : '';

    $user_data = array(
      'user_login' => $username,
      'user_email' => $email,
      'user_pass' => $password,
      'meta_input' => array()
    );

    foreach ($form_data as $name => $value) {
      if ($name !== 'username' && $name !== 'email' && $name !== 'password' && $name !== 'confirm_password')
        $user_data['meta_input'][DROIP_COMPONENT_LIBRARY_APP_PREFIX . '_' . $name] = $value;
    }

    if (
      isset($username) && strlen($username) > 0
      && isset($email) && strlen($email) > 0 &&
      isset($password) && strlen($password) > 0 && $password === $confirm_password
    ) {
      $id = wp_insert_user($user_data);

      if (is_wp_error($id)) {
        $response = array(
          'message' => $id->errors[array_key_first($id->errors)]
        );
        return new WP_REST_Response($response, 500);
      }
      $response = array(
        'message' => 'User created',
        'user_id' => $id
      );
      return new WP_REST_Response($response, 200);
    }
    $response = array(
      'message' => 'Invalid form data',
    );
    return new WP_REST_Response($response, 400);
  }

  function handle_forgot_password($request)
  {
    $form_data = $request->get_body_params();
    $email = isset($form_data['email']) ? sanitize_text_field($form_data['email']) : '';
    $email = sanitize_email($email);

    if (
      isset($email) && strlen($email) > 0
    ) {
      $user = get_user_by('email', $email);
      if (is_wp_error($user)) {
        $response = array(
          'message' => $user->errors[array_key_first($user->errors)]
        );
        return new WP_REST_Response($response, 500);
      }

      if (!$user) {
        $response = array(
          'message' => 'User not found',
        );
        return new WP_REST_Response($response, 404);
      }

      $send = retrieve_password($user->get('user_login'));

      if (is_wp_error($send)) {
        $response = array(
          'message' => $send->errors[array_key_first($send->errors)]
        );
        return new WP_REST_Response($response, 500);
      }

      if ($send) {
        $response = array(
          'message' => 'Email sent',
        );
        return new WP_REST_Response($response, 200);
      }
      $response = array(
        'message' => 'Something went wrong',
      );
      return new WP_REST_Response($response, 500);
    }
  }
}


new AuthFormHandler();
