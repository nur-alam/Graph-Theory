import { addComponentCategory, registerDroipComponentLibrary } from '.';
const { base_url } = DroipComponentLibrary;

const categories = {
	id: 'droipComponentLibrary',
	title: 'Forms',
	categoryList: [
		{
			id: 'droipComponentLibrary-auth',
			title: 'Auth',
			iconClass: 'form',
			elementGroups: [
				{
					id: 'droipComponentLibrary-auth-login',
					title: 'Login',
					elements: [
						{
							id: 'droipComponentLibrary-auth-login-plain',
							srcType: 'full',
							title: 'Login Plain',
							elementUrl: base_url + 'Editor/Components/Login/element.json',
							previewImage: base_url + 'Editor/Components/Login/preview.png',
							keywords: ['button', 'fill'],
						},
					],
					keywords: ['login', 'signin'],
				},
				{
					id: 'droipComponentLibrary-auth-registration',
					title: 'Registration',
					elements: [
						{
							id: 'droipComponentLibrary-auth-registration-plain',
							srcType: 'full',
							title: 'Registration Plain',
							elementUrl: base_url + 'Editor/Components/Register/element.json',
							previewImage: base_url + 'Editor/Components/Register/preview.png',
							keywords: ['button', 'fill'],
						},
					],
					keywords: ['registration', 'signup'],
				},
				{
					id: 'droipComponentLibrary-auth-forgot_password',
					title: 'Forgot Password',
					elements: [
						{
							id: 'droipComponentLibrary-auth-forgot_password-plain',
							srcType: 'full',
							title: 'Forgot Password Plain',
							elementUrl: base_url + 'Editor/Components/ForgotPassword/element.json',
							previewImage: base_url + 'Editor/Components/ForgotPassword/preview.png',
							keywords: ['button', 'fill'],
						},
					],
					keywords: ['forgotPassword', 'resetPassword'],
				},
			],
			keywords: [''],
		},
	],
	keywords: [''],
};

addComponentCategory(categories);
registerDroipComponentLibrary();
