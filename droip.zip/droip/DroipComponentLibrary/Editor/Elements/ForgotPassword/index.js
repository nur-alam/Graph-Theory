import React from 'react';
const { droip } = window;

const onSettingChangeHandler = (elementId) => {
	const { addElement, deleteElement, getCanvasElement } = droip;
	const parentElement = getCanvasElement(elementId);
	const { reCaptcha } = parentElement.properties.settings;
	let reCaptchaId = false;
	let btnIndex = false;

	(parentElement?.children || []).forEach((id, index) => {
		const el = getCanvasElement(id);
		if (el.name === 'recaptcha') {
			reCaptchaId = id;
		}
		if (el.name === 'button') {
			btnIndex = index;
		}
	});

	if (reCaptcha && !reCaptchaId) {
		addElement({
			name: 'recaptcha',
			parentId: elementId,
			index: btnIndex,
			changeSelectedElement: false,
			style: 'margin-top: 10px; margin-bottom: 10px',
		});
	} else if (!reCaptcha && reCaptchaId) {
		deleteElement({ elementId: reCaptchaId, forceDelete: true });
	}
};

export const getCurrentActiveState = (parentId) => {
	const parentElement = droip.getCanvasElement(parentId);
	const {
		properties: { settings },
	} = parentElement;
	let state = settings?.state;
	return state || 'normal';
};

const ForgotPassword = (props) => {
	const { elementId, renderChildren, className } = props;

	const { getCanvasElement, getAllAttributes } = droip;
	const element = getCanvasElement(elementId);

	const templates = () => [['droip-forgot-password-error', { manualDelete: false, properties: {} }]];

	return (
		<form {...getAllAttributes(element)} className={className}>
			{renderChildren({ template: templates() })}
		</form>
	);
};

export default {
	name: 'droip-forgot-password',
	title: 'Forgot Password',
	description: 'HTML form element',
	icon: `${droip?.iconPrefix}-form`,
	hoverIcon: `${droip?.iconPrefix}-form-fill`,
	className: '',
	category: 'component library',
	visibility: false,
	children: [],
	properties: {
		tag: 'form',
		settings: {
			reCaptcha: false,
			state: 'normal',
		},
		attributes: {},
	},
	Component: ForgotPassword,
	constraints: {
		childrens: [
			{
				element: '*',
				condition: 'ALLOW',
			},
		],
	},
	source: 'DroipComponentLibrary',
	defaultStyle: `
		padding: 40px;
		border-radius: 10px;
		box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
		width: 60%;
		margin-left: auto;
		margin-right: auto;
		box-sizing: border-box;
		`,
	controls: { margin: true, padding: true, height: true, width: true },
	settings: [
		{
			key: 'reCaptcha',
			label: 'reCaptcha',
			setting: { ...droip.elementSettings.TOGGLER },
		},
		{
			setting: { ...droip.elementSettings.DIVIDER_TRANSPARENT },
		},
		{
			key: 'state',
			label: 'State',
			setting: {
				...droip.elementSettings.TAB,
				tabs: [
					{
						value: 'normal',
						label: 'Normal',
					},
					{
						value: 'error',
						label: 'Error',
					},
				],
			},
		},
	],
	onSettingsChange: onSettingChangeHandler,
};
