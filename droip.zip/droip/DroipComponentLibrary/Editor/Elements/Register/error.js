import React from 'react';
import { getCurrentActiveState } from '.';
const { droip } = window;

const RegisterError = (props) => {
	const { elementId, renderChildren, className } = props;

	const { getCanvasElement, getAllAttributes } = droip;
	const element = getCanvasElement(elementId);

	const templates = () => [];

	return (
		<div
			{...getAllAttributes(element)}
			className={className}
			data-element_hide={(getCurrentActiveState(element.parentId) !== 'error').toString()}
		>
			{renderChildren({ template: templates() })}
		</div>
	);
};

export default {
	name: 'droip-register-error',
	title: 'Register Error',
	description: 'HTML form element',
	className: '',
	category: 'component library',
	visibility: false,
	children: [],
	properties: {
		tag: 'div',
		settings: {},
	},
	Component: RegisterError,
	constraints: {
		childrens: [
			{
				element: '*',
				condition: 'ALLOW',
			},
		],
	},
	source: 'DroipComponentLibrary',
	defaultStyle: `
		width: 100%;
		`,
	controls: { margin: true, padding: true, height: true, width: true },
	settings: [],
};
