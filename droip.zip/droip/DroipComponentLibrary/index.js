import { Login, LoginError, Register, RegisterError, ForgotPassword, ForgotPasswordError } from './Editor/Elements';
const { droip } = window;

const AllElements = [Login, LoginError, Register, RegisterError, ForgotPassword, ForgotPasswordError];

const registerEachElement = (element) => {
	if (!element) {
		return;
	}
	droip.RegisterElement(element.default);
};

export const registerDroipComponentLibrary = () => {
	AllElements.forEach(registerEachElement);
};

export const addComponentCategory = (componentCategory) => droip.addComponentCategory(componentCategory);

export const conf = {
	ICON_PREFIX: 'droip',
	APP_SRC: 'DroipComponentLibrary',
};

const DroipComponentLibrary = {};
AllElements.forEach((a) => {
	if (!a.default) {
		return;
	}
	DroipComponentLibrary[a.default.name] = a.default;
});

export default DroipComponentLibrary;
