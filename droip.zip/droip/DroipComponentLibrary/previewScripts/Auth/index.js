import { alertMessage as showAlert, hideState, showState } from '../utils';

const { default: axios } = require('axios');
const { getHTMLElementByID, debounce, bytesToMB } = require('../utils');

// reset form and file input container after successfull submission
const formResetHandler = (authEl) => {
	if (authEl instanceof HTMLFormElement) {
		// reset form after successfull submission
		authEl.reset();
	}
};

const alertMessage = (container, message, state, errState) => {
	if (state === 'error') {
		showState(errState);
		showAlert(container, message, state);
		const errEl = errState.querySelector('.droip-errormessage');
		errEl.innerHTML = message;
	} else {
		hideState(errState);
		showAlert(container, message, state);
	}
};

const submitHandler = debounce((authEl, properties, id, errState) => {
	const submitButton = authEl.querySelector('[type="submit"]');
	if (submitButton) {
		submitButton.setAttribute('disabled', 'true');
	}
	let formData = new FormData(authEl);

	axios
		.post(`${wp_droip.restUrl}DroipComponentLibrary/v1/Auth/${properties.name}`, formData)
		.then((res) => {
			if (res.status === 200) {
				formResetHandler(authEl);
				if (properties.successURL && typeof properties.successURL === 'string') {
					if (properties.successURL === '#') window.location.reload();
					else window.location.href = properties.successURL;
				} else {
					const messageContainer = document.querySelector('body');
					alertMessage(messageContainer, res.data.message, 'success', errState);
				}
			} else {
				const errorMessageContainer = document.querySelector('body');
				alertMessage(errorMessageContainer, res.data.message, 'error', errState);
			}
		})
		.catch((error) => {
			const errorMessageContainer = document.querySelector('body');
			const errorMessage = error?.response?.data?.message || window.wp.i18n.__('Failed! Please try again', 'droip');
			alertMessage(errorMessageContainer, errorMessage, 'error', errState);
		});
}, 300);

function loadAuthActionsUsingElementID({ properties, id }) {
	/**
	 * @type {HTMLFormElement}
	 */

	let authEl = getHTMLElementByID(id);

	const errState = authEl.querySelector(`[data-ele_name="${properties.name}-error"]`);

	authEl.addEventListener('submit', (e) => {
		e.preventDefault();
		submitHandler(authEl, properties, id, errState);
		return false;
	});
}

function initAuth() {
	const { auth } = DroipComponentLibrary || {};
	if (typeof auth !== 'undefined' && Object.keys(auth).length > 0) {
		Object.keys(auth).map((id) => {
			loadAuthActionsUsingElementID({ properties: auth[id], id });
		});
	}
}

try {
	initAuth();
} catch (error) {}
