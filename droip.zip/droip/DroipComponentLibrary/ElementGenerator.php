<?php


namespace ComponentLib;

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

class ElementGenerator
{
  private $element = array();
  private $attributes = array();
  private $setting = array();
  private $options = array();
  private $generate_child_element = null;
  private $properties = array();
  public  $auth_forms = array();

  public function __construct($props)
  {
    $this->element                            = $props['element'];
    $this->attributes                         = $props['attributes'];
    $this->options                            = $props['options'];
    $this->generate_child_element             = $props['generate_child_element'];
    $this->properties                         = $this->element['properties'];
    $this->setting                            = $this->properties['settings'];
    $this->auth_forms                         = $props['auth_forms'];
    $this->add_element_config();
  }


  private function add_element_config()
  {
    $id = $this->element['id'];
    if ($this->element['name'] === 'droip-login' || $this->element['name'] === 'droip-register' || $this->element['name'] === 'droip-forgot-password') {
      $this->auth_forms[$id] = array_merge($this->properties['attributes'], $this->setting, array('name' => $this->element['name']));
    }
  }

  public function generate_common_element($hide = false, $children_html = false)
  {
    $extra_attributes = '';
    if ($hide) {
      $extra_attributes .= ' data-element_hide="true"';
    }

    $html = '';
    $tag  = isset($this->properties['tag']) ? $this->properties['tag'] : 'div';
    $name = $this->element['name'];
    $user = wp_get_current_user();

    if (($name === 'droip-login' || $name === 'droip-register' || $name === 'droip-forgot-password') && $user->ID !== 0) return '';

    if (! $children_html) {
      $children_html = $this->generate_child_elements();
    }
    $html = "<$tag $this->attributes data-ele_name='$name' $extra_attributes>$children_html</$tag>";
    return $html;
  }

  private function generate_child_elements()
  {
    $html        = '';
    $child_count = isset($this->element['children']) ? count($this->element['children']) : 0;
    for ($i = 0; $i < $child_count; $i++) {
      $html .= call_user_func($this->generate_child_element, $this->element['children'][$i], $this->options);
    }
    return $html;
  }
}
