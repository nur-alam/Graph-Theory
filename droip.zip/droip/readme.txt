=== Droip - The No-code Website Builder for WordPress ===
Contributors: droip
Donate link: https://www.droip.com
Tags: no code, page builder, website builder, drag and drop, droip, landing page, visual editor
Requires at least: 5.3
Tested up to: 6.2
Requires PHP: 7.0
Stable tag: 1.0.4
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html


### Description

All-in-one no-code website builder to create any website you can imagine.

Create any complex layouts, design landing pages, make interactions, and build pop-ups and advanced forms without writing any code.

Take control of your website design and functionality with an all-in-one no-code website builder without relying on any third-party plugins.

Richly design web pages that load fast and pass page speed score. Stay ahead with your website in this age of core web vitals.

You can utilize layers, have responsive controls, add custom breakpoints, and enjoy the complete freedom of web page designing on a true no-code website builder.

### Links to Site

👉 [Droip Live demo](https://droip.com/)
👉 [Documentation](https://droip.com/)
👉 [Droip Premium](https://droip.com/)

### The No-code Website Builder That Serves All Creators

Droip, the no-code website builder, is made to meet the demands of all creators. Whether you're a developer, designer, marketing, or agency owner, Droip is your visual editor to design any landing page or web layout you can imagine.

### Complete Website Design Freedom

Droip provides an open canvas and an extensive collection of design elements that you can simply drag and drop, allowing designers to convert their designs into functioning sites that perfectly match their creative vision. With Droip’s visual editor, you have complete control over every pixel and customize your element’s typography, structure, background, and more.

**Advanced Flex:** With Droip’s Flexboxes you can align and distribute space among items in a container. It works just like the way regular Flexboxes work at the code level. You can apply any Flex properties to your elements.

**Advanced Grid:** Droip also offers advanced Grid capabilities, allowing you to create highly customizable grid layouts. It allows you to create customizable grid layouts, enabling precise element placement and sizing.

**Clip Path & Shape:** Create any SVG shapes, image shapes,s and text clips on a rich editor and use them as SVG images/icons on your webpage.

**Background Options:** Choose from 5 background options, apply multiple backgrounds, and style text with ease using Droip's versatile background options.

### Reuse Style With Class Manager

- **Style Reusability:** Define element structure and initial styles with Classes for easy reuse across elements for consistent styling.
- **Sub-class Inheritance:** Sub-classes inherit parent class attributes while allowing for unique customization.
- **State and Pseudo Class Styling:** Style elements in different states and use Pseudo Classes for targeted element selection, enhancing interactivity and design flexibility.

### Reuse Elements With Symbols

1. **Reusable Elements:** Convert any element or group of elements into a Symbol for future reuse throughout your projects.
2. **Automatic Updates:** Any changes made to a Symbol automatically apply to all instances of that Symbol, saving time and effort.
3. **Easy Creation and Management:** Create Symbols from elements, categorize them, and easily edit, rename, or delete Symbols from the Symbols panel.
4. **Customization and Detachment:** Customize Symbol instances by unlinking them from the main Symbol, allowing independent editing without affecting other instances.
5. **Header and Footer Symbols:** Create custom headers and footers, add conditions to show or hide them on specific pages, creating dynamic and targeted content.

### Extend Functionalities With Custom Code & Attributes

Take your website customization to the next level with Droip's code-level control. Edit and customize the HTML, CSS, and JavaScript code that underpins the design, allowing you to create any necessary functionality.

You can also add custom HTML, CSS, and JavaScript events and develop anything you want. No third-party plugin is required to add code snippets.

### Advanced Interactions & Limitless Animations

Droip empowers you to add dynamic animations to your elements and pages, from subtle fades to complex motion graphics. You have complete control over timing, sequencing, and interaction triggers to create complex animation effects and interactions.

- **Apply interaction on an element:** You apply interaction on an element for: on mouse click (tap), mouse hover, mouse moves over the element (continuous), and scrolling into view.
- **Apply interaction on a page:** Tigger an interaction on a page on mouse move on the viewport, when the page is scrolling, the page load, scroll into view, page scrolled.
- **Select interaction Action:** You can choose from 41 different entrance animations including fading, zooming, bouncing, sliding, rotating, attention, Light speed, and many of their variations.
- **Transition effects:** Droip offers a range of transition effects to create smooth and visually appealing animations between different states or elements. These effects include easing, acceleration, deceleration, and more.
- **Custom Timing Editor:** Define a custom easing curve and set keyframe values to create a more natural and dynamic animation.
- **Custom Response:** You can also create a custom response for your triggers instead of selecting a response from the library.

### Media Manager - Manage Media Like Never Before

With Droip, managing your media becomes a breeze, allowing you to focus on creating stunning visuals.

- **Smart Media File Management:** Streamline your media file management with Droip's intuitive system, providing a smarter and more efficient alternative to the default WordPress media manager.
- **Built-in Image Editor:** Take advantage of Droip's image editing capabilities, allowing you to crop, edit, adjust, and apply filters to your uploaded images. You can also revert to the original version if desired.
- **14000+ Extensive SVG Icon Library:** Droip’s Media Manager is a home to a diverse collection of SVG icons, including default icons (562), material icons (10615), line awesome icons (1541), mono icons (179), CSS icons (703), and ZW icons (566).
- **Image Library Integration:** Seamlessly integrate with popular image libraries like Unsplash and Pexels, allowing you to use their vast collection of high-quality photos directly in your web pages.
- **SVG File Support:** Upload and use SVG files effortlessly, either by dragging and dropping from your computer or utilizing Droip's library of over 14,000 SVG files.
- **Lottie Animation Support:** Easily incorporate Lottie animations into your website without the need for additional plugins or manual work. Droip's no-code builder natively supports JSON-based Lottie files.
- **Advanced Video Control:** Have more control over your videos, including adjusting size and position, choosing from fill, contain, cover, and initial options, fixing the position or enabling scrolling with page scrolling, rotation, looping, audio control, and Slo-Mo effects, eliminating the need for additional video player plugins.

### Modal Builder: Create Pop-ups That Convert

Ditch boring pop-ups and Create captivating and conversion-optimized pop-ups with Droip’s easy-to-use drag and drop pop-up builder.

1. **Easy Modal Creation:** Quickly create engaging pop-ups using the intuitive interface of Droip's Modal Builder.
2. **Customizable Design:** Tailor the appearance of your pop-ups to match your website's branding and design. Customize colors, fonts, backgrounds, and more.
3. **Conditional Display:** Set specific conditions for when your modals should appear. Trigger modals based on user actions, time on page, scroll position, or other criteria.
4. **Pre-built Library:** Access a library of pre-built modal templates and elements of the modal builder to save time and effort in creating modals from scratch. Choose from a variety of functional and visually appealing designs.
5. **Modal Layout Control:** Precisely position your pop-ups on the screen using the Modal Layout feature. Divide the screen into sections and assign the modal to your preferred section. Adjust horizontal and vertical offsets for precise placement.

### Visual Form Builder: Build Any Web Forms & Survey

From basic contact forms to complex surveys, Droip’s visual form builder offers all the necessary form elements that you can simply drag and drop to create any web form. Access a single dashboard to manage, analyze, and export form data, streamlining your form management process.

1. **Extensive Form Element Library:** Access a wide range of form elements such as Label, Input, Textarea, reCAPTCHA ,File Upload, and more for custom web forms.
2. **Create Newsletter Form:** Create and collect leads with newsletter forms without third-party plugins.
3. **Seamless Email Marketing:** Connect forms with popular email marketing solutions like MailChimp, Mailerlite, without the need for additional plugins.
4. **Advanced Form Settings:** Configure actions, notifications, messages, modal windows, and redirections.
5. **Form Data Management and Export:** Manage, analyze, and export form data easily.
6. **Limit Entries:** Limit the number of entries to be submitted on a single form.
7. **Limit Form Submission:** Restrict the number of submissions from a single IP address, ensuring data control and preventing spam.

### Seamless Collaborations With Role Manager

Ensure appropriate level of access and collaboration with user roles. From administrators to content editors, empower your team with the right level of control and enhance workflow like never before.

### Accessibility: Inclusive Website Creation

Droip provides accessibility options that let you customize the display, color contrast, and more of your canvas. A no-code website builder that is accessible to all users, ensuring a seamless and inclusive website creation experience

- **Large Text:** Increase the size of the text for better readability.
- **Disable Motion:** Disable any motion for a more comfortable experience.
- **Big Black Cursor:** Replace the default cursor with a larger and black-colored cursor.
- **Big White Cursor:** Replace the default cursor with a larger and white-colored cursor.
- **Magnifier:** Add a magnify effect to the cursor for improved visibility.
- **Increase Contrast:** Enhance the color contrast of the entire interface.
- **Mouse Pointer Highlighter:** Highlight the mouse pointer to make it more visible.
- **Color Blindness Tools:** Simulate different types of color deficiencies for better design accessibility.
- **Visual Impairments:** Cater to users with cataracts by providing appropriate visual settings.
- **Color Picker with Contrast Ratio and WCAG Rating:** Easily check the accessibility of chosen colors based on contrast ratios and WCAG guidelines.

### Improve Accessiblity & SEO With Page Audit

Perform page audits and identify issues such as missing links, improperly named classes, and missing alt text. This is a valuable feature that can save you time and improve the accessibility and SEO of your website.

- **Alt Text Missing:** Identify media elements without defined alternate text, aiding visually impaired users and improving SEO.
- **Link Missing:** Highlight link blocks without any set links, ensuring proper functionality.
- **Class Name Missing:** Identify elements without defined class names for improved organization and styling capabilities.

### Optimize Page Rank With Built-in SEO

Boost your website's search engine visibility effortlessly with Droip's built-in SEO feature. Set up meta titles and descriptions, optimize Open Graph tags, and take control of your website's SEO.

### Better Performance & Load Times

Droip prioritizes speed and performance to ensure swift load times and an improved user experience.

- **Efficient Font Management:** Droip avoids loading unnecessary fonts, optimizing the loading process.
- **Selective Styles Loading:** Only relevant styles specific to each page are loaded, reducing unnecessary overhead.
- **Streamlined HTML:** Droip generates slim HTML code without excessive elements or data attributes, enhancing performance.
- **Minified Assets:** All assets in the Droip no-code website builder are minified and optimized for faster load times, aligning with core web vitals standards.
- **No Extra Library Loaded:** Droip doesn't load any additional libraries for animations or interactions, resulting in a streamlined website without unnecessary bulk.

### Complete Responsiveness With Unlimited Breakpoints

Make your website responsive for any device available in the world. Apart from the commonly used devices, the Droip no-code website builder has the system to add custom breakpoints to design websites for any device size.

Ready to embark on a web-building adventure with code-level control and full design freedom? Try Droip out for yourself and experience the incredible possibilities of a no-code website builder that surpasses expectations. Unleash your creativity and create extraordinary websites with Droip today!
