<?php
/**
 * This class act like controller for Editor, Iframe, Frontend
 *
 * @package droip
 */

namespace Droip;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Frontend\Editor;
use Droip\Frontend\Iframe;
use Droip\Frontend\TheFrontend;
use Droip\Manager\TemplateRedirection;

/**
 * Frontend handler class
 */
class Frontend {

	/**
	 * Initialize the class
	 *
	 * @return void
	 */
	public function __construct() {
		new TemplateRedirection();
		$this->plugin_editor_page_or_iframe_or_the_content();
	}


	/**
	 * This action trigger when post data loaded done
	 *
	 * @param object $post WordPress post object.
	 * @return void
	 */
	public function post_loaded( $post ) {
		if ( ! HelperFunctions::user_has_post_edit_access( $post->ID ) || ! HelperFunctions::user_has_editor_access() ) {
      //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			wp_die( __( 'Sorry, you are not allowed to access this page.', 'droip' ) );
		}
	}

	/**
	 * Render the plugin editor page
	 *
	 * @return void
	 */
	public function plugin_editor_page_or_iframe_or_the_content() {
    //phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$action = HelperFunctions::sanitize_text( isset( $_GET['action'] ) ? $_GET['action'] : '' );

		if ( $action === DROIP_EDITOR_ACTION ) {
			add_action( 'the_post', array( $this, 'post_loaded' ) );

      //phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$load_for = HelperFunctions::sanitize_text( isset( $_GET['load_for'] ) ? $_GET['load_for'] : '' );
			if ( $load_for === 'droip-iframe' ) {
				new Iframe();
			} elseif ( $load_for === 'migration' ) {
				new TheFrontend( 'migration' );
			} else {
				new Editor();
			}
		} else {
			new TheFrontend();
		}
	}
}
