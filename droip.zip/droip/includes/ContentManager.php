<?php
/**
 * This class act like controller for Editor, Iframe, Frontend
 *
 * @package droip
 */

namespace Droip;

use Droip\API\ContentManager\ContentManagerHelper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Frontend handler class
 */
class ContentManager {

	/**
	 * Initialize the class
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'parse_request', [$this, 'custom_parse_request'] );
    add_action( 'init', [$this, 'register_parent_post_type'] );
	}

  public function register_parent_post_type() {
    $all_post_types = ContentManagerHelper::get_all_post_types();
    foreach ($all_post_types as $key => $post_type) {
      $args = array(
        'public' => true,
        'show_ui' => false,
        'label'  => $post_type['post_title'],
        // Add other arguments as needed
        'rewrite' => array( 'slug' => $post_type['post_name'] ), // Define the slug for parent posts
      );
      register_post_type( ContentManagerHelper::get_child_post_post_type_value($post_type['ID']), $args );
    }
  }

  public function custom_parse_request( $wp ) {
    global $wp_rewrite;

    // Get the site URL and path to account for subfolder installation
    $parsed_url_path = parse_url(site_url(), PHP_URL_PATH);
    $site_url_path = is_null($parsed_url_path) ? '' : trim($parsed_url_path, '/');

    // Get the requested URL path
    $requested_path = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );

    // Remove the subfolder part from the requested path
    if ( $site_url_path && strpos( $requested_path, $site_url_path ) === 0 ) {
        $requested_path = substr( $requested_path, strlen( $site_url_path ) );
        $requested_path = trim( $requested_path, '/' );
    }

    // Get the parent and child slugs from the URL path
    $path_parts = explode( '/', $requested_path );
    $parent_slug = isset( $path_parts[0] ) ? $path_parts[0] : '';
    $child_slug = isset( $path_parts[1] ) ? $path_parts[1] : '';

    if(!$child_slug){
      $post_id = HelperFunctions::get_post_id_if_possible_from_url();
      if($post_id){
        $post = get_post($post_id);
        $child_slug = $post->post_name;
        $parent_post = get_post($post->post_parent);
        if($parent_post){
          $parent_slug = $parent_post->post_name;
        }
      }
    }

    //TODO: Need to check ?p=post_id for draft post preview.
    // Check if the URL corresponds to a parent post
    $parent_post = get_page_by_path( $parent_slug, OBJECT, ContentManagerHelper::PARENT_POST_TYPE );
    if ( $parent_post ) {
        // This is a parent post
        $wp->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_parent_post'] = $parent_post->ID;

        // Check if the URL corresponds to a child post
        if ( ! empty( $child_slug ) ) {
            $args = array(
              'post_type'      => ContentManagerHelper::get_child_post_post_type_value($parent_post->ID), // Replace 'your_post_type' with your actual post type
              'posts_per_page' => 1, // Limit to one post
              'name'           => $child_slug, // Replace 'your_post_name' with the post_name value
              'post_parent'    => $parent_post->ID, // Replace 123 with the post parent ID
            );
            $posts = get_posts($args);
            if(count($posts) > 0){
                $child_post = $posts[0];
                $wp->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_child_post'] = $child_post->ID;
            }
        }

        // Load custom template for both parent and child posts
        // add_filter( 'template_include', [$this, 'custom_load_custom_template'] );
    }
  }
  

  // function custom_load_custom_template( $template ) {
  //     // Check if the current page is a parent or child post
  //     if ( isset( $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_parent_post'] ) || isset( $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_child_post'] ) ) {
  //         // Load your custom template file
  //         $custom_template = DROIP_FULL_CANVAS_TEMPLATE_PATH;
  //         if ( file_exists( $custom_template ) ) {
  //             return $custom_template;
  //         }
  //     }
  //   //   var_dump($GLOBALS['wp']->query_vars);die();
  //     // Return the original template if not a parent or child post
  //     return $template;
  // }

}
