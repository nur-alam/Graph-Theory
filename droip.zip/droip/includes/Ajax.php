<?php

/**
 * All Ajax/API calls will goes here
 *
 * @package droip
 */

namespace Droip;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Collaboration\Collaboration;
use Droip\Ajax\DynamicContent;
use Droip\Ajax\Media;
use Droip\Ajax\Page;
use Droip\Ajax\PageSettings;
use Droip\Ajax\Symbol;
use Droip\Ajax\UserData;
use Droip\Ajax\Walkthrough;
use Droip\Ajax\WordpressData;
use Droip\Ajax\Collection;
use Droip\Ajax\ExportImport;
use Droip\Ajax\Comments;
use Droip\Ajax\WpAdmin;
use Droip\Ajax\Form;
use Droip\Ajax\Mailchimp;
use Droip\Ajax\RBAC;
use Droip\Ajax\Taxonomy;

/**
 * Droip Ajax handler
 */
class Ajax
{

	/**
	 * Initialize the class
	 *
	 * @return void
	 */
	public function __construct()
	{
		/**
		 * Manage Post API call's from Builder
		 */
		add_action('wp_ajax_droip_get_apis', array($this, 'droip_get_apis'));
		add_action('wp_ajax_droip_post_apis', array($this, 'droip_post_apis'));

		/**
		 * Manage Post API call's from WP Admin
		 */
		add_action('wp_ajax_droip_wp_admin_get_apis', array($this, 'droip_wp_admin_get_apis'));
		add_action('wp_ajax_droip_wp_admin_post_apis', array($this, 'droip_wp_admin_post_apis'));

		/**
		 * Manage Post API call's from Frontend (logged in not required)
		 */
	}

	/**
	 * Initialize post api
	 *
	 * @return void
	 */
	public function droip_post_apis()
	{
		HelperFunctions::verify_nonce('wp_rest');
		if (!is_admin()) {
			wp_send_json_error('Not authorized');
		}
		/**
		 * PAGE APIS
		 */

		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$endpoint = HelperFunctions::sanitize_text(isset($_POST['endpoint']) ? $_POST['endpoint'] : null);
		if ('save-page-data' === $endpoint) {
			Page::save_page_data();
		}

		if ($endpoint === 'add-new-page') {
			Page::add_new_page();
		}

		if ($endpoint === 'update-page-data') {
			Page::update_page_data();
		}

		if ($endpoint === 'remove-unused-style-block-from-db') {
			Page::remove_unused_style_block_from_db();
		}

		if ($endpoint === 'duplicate-page') {
			Page::duplicate_page();
		}

		if ($endpoint === 'delete-page') {
			Page::delete_page();
		}

		if ($endpoint === 'back-to-droip-editor') {
			Page::back_to_droip_editor();
		}

		if ($endpoint === 'back-to-wordpress-editor') {
			Page::back_to_wordpress_editor();
		}

		/**
		 * PAGE SETTINGS
		 */
		if ('save-page-settings-data' === $endpoint) {
			PageSettings::save_page_setting_data();
		}

		/**
		 * PAGE SETTINGS
		 */
		if ('save-custom-code-data' === $endpoint) {
			PageSettings::save_custom_code();
		}

		/**
		 * USER APIS
		 */
		if ($endpoint === 'save-user-controller') {
			UserData::save_user_controller();
		}
		if ($endpoint === 'save-user-saved-data') {
			UserData::save_user_saved_data();
		}
		if ($endpoint === 'save-user-custom-fonts-data') {
			UserData::save_user_custom_fonts_data();
		}

		/**
		 * SYMBOL SAVE API
		 */
		if ($endpoint === 'save-user-saved-symbol-data') {
			Symbol::save();
		}

		/**
		 * SYMBOL UPDATE API
		 */
		if ($endpoint === 'update-user-saved-symbol-data') {
			Symbol::update();
		}

		/**
		 * SYMBOL DELETE API
		 */
		if ($endpoint === 'delete-user-saved-symbol-data') {
			Symbol::delete();
		}

		/**
		 * MEDIA APIS
		 */
		if ($endpoint === 'upload-media') {
			Media::upload_media();
		}

		if ($endpoint === 'upload-font-zip') {
			Media::upload_font_zip();
		}

		if ($endpoint === 'remove-custom-font-folder-from-server') {
			Media::remove_custom_font_folder_from_server();
		}

		if ($endpoint === 'upload-base64-img') {
			Media::upload_base64_img();
		}

		/**
		 * WALKTHROUGH
		 */
		if ('set-walkthrough-shown-state' === $endpoint) {
			Walkthrough::set_walkthrough_state();
		}

		/**
		 * Collaboration data save
		 */
		if ('save-collaboration-actions' === $endpoint) {
			Collaboration::save_actions();
		}

		/**
		 * Export page dat
		 */
		if ('import-page-data' === $endpoint) {
			ExportImport::import();
		}

		/**
		 * Export page dat
		 */
		if ('export-page-data' === $endpoint) {
			ExportImport::export();
		}
	}

	/**
	 * Initialize the get apis
	 *
	 * @return void
	 */
	public function droip_get_apis()
	{
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$endpoint = HelperFunctions::sanitize_text(isset($_GET['endpoint']) ? $_GET['endpoint'] : null);
		if ('collect-collaboration-actions' !== $endpoint && 'delete-collaboration-connection' !== $endpoint) {
			// TODO: Need to verify for collaboration.
			HelperFunctions::verify_nonce('wp_rest');
		}
		if (!is_admin()) {
			wp_send_json_error('Not authorized');
		}
		/**
		 * PAGE APIS
		 */
		if ($endpoint === 'get-page-data') {
			Page::get_page_blocks_and_styles();
		}

		if ($endpoint === 'get-pages-list') {
			Page::fetch_list_api();
		}
		if ($endpoint === 'get-post-list-for-search') {
			Page::get_post_list_for_search();
		}
		if ($endpoint === 'get-posts-list') {
			Page::fetch_post_list_data_post_type_wise();
		}

		if ($endpoint === 'get-current-page-data') {
			Page::get_current_page_data();
		}
		if ($endpoint === 'get-unused-class-info-from-db') {
			Page::get_unused_class_info_from_db();
		}

		/**
		 * USER DATA APIS
		 */
		if ($endpoint === 'get-user-controller') {
			UserData::get_user_controller();
		}

		/**
		 * USER DATA APIS
		 */
		if ($endpoint === 'get-user-saved-data') {
			UserData::get_user_saved_data();
		}

		if ($endpoint === 'get-user-custom-fonts-data') {
			UserData::get_user_custom_fonts_data();
		}

		/**
		 * GET SYMBOL LIST API
		 */
		if ($endpoint === 'get-symbol-list') {
			Symbol::fetch_list(false, true);
		}

		/**
		 * GET Single SYMBOL API
		 */
		if ($endpoint === 'get-single-symbol') {
			$symbol_id = HelperFunctions::sanitize_text( isset( $_GET['symbol_id'] ) ? $_GET['symbol_id'] : null );
			Symbol::get_single_symbol($symbol_id, false, true);
		}

		/**
		 * GET DYNAMIC CONTENT API
		 */
		if ($endpoint === 'get-dynamic-content') {
			DynamicContent::get_dynamic_element_data();
		}

		if ( $endpoint === 'get-post-terms' ) {
			Taxonomy::get_post_terms();
		}

		if ( $endpoint === 'get-terms' ) {
			Taxonomy::get_terms();
		}

		/**
		 * GET WordPress MENUS API
		 */
		if ($endpoint === 'get-wp-menus') {
			WordpressData::get_wordpress_menus_data();
		}

		/**
		 * GET WordPress POST TYPES API
		 */
		if ($endpoint === 'get-wp-post-types') {
			WordpressData::get_wordpress_post_types_data();
		}

		/**
		 * GET WordPress POST TYPES API
		 */
		if ( $endpoint === 'get-wp-comment-types' ) {
			WordpressData::get_wordpress_comment_types_data();
		}

		/**
		 * GET Mailchimp Data
		 */
		if ($endpoint === 'get-mailchimp-data') {
			$mailchimp = Mailchimp::get_instance();
			$data      = $mailchimp->get_data();
			wp_send_json($data);
		}
		/**
		 * GET WordPress SINGLE MENU DATA API
		 */
		if ($endpoint === 'get-wp-sigle-menu') {
			//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$term_id = HelperFunctions::sanitize_text(isset($_GET['term_id']) ? $_GET['term_id'] : null);
			WordpressData::get_wordpress_single_menu_data($term_id);
		}

		/**
		 * PAGE SETTINGS
		 */
		if ($endpoint === 'get-page-settings-data') {
			PageSettings::get_page_settings_data();
		}

		if ($endpoint === 'get-custom-code') {
			PageSettings::get_custom_code();
		}

		/**
		 * WALKTHROUGH
		 */
		if ('get-walkthrough-shown-state' === $endpoint) {
			Walkthrough::get_walkthrough_state();
		}

		/**
		 * COLLECTION
		 */
		if ('get-collection' === $endpoint) {
			Collection::get_collection();
		}

		/**
		 * COMMENTS
		 */
		if ( 'get-comments' === $endpoint ) {
			Comments::get_comments();
		}

		/**
		 * AUTHOR LIST
		 */
		if ('get-authors' === $endpoint) {
			WordpressData::get_author_list();
		}

		/**
		 * USER LIST
		 */
		if (
			'get-users' === $endpoint
		) {
			WordpressData::get_user_list();
		}

		/**
		 * CATEGORY LIST
		 */
		if ('get-categories' === $endpoint) {
			WordpressData::get_category_list();
		}

		/**
		 * GET ACCESS LEVEL
		 */
		if ('editor-access-level' === $endpoint) {
			RBAC::get_editor_access_level();
		}

		/**
		 * Collaboration data get
		 */
		if ('collect-collaboration-actions' === $endpoint) {
			Collaboration::send_actions();
		}
		/**
		 * Collaboration data get
		 */
		if ('delete-collaboration-connection' === $endpoint) {
			$session_id = HelperFunctions::get_session_id();
			Collaboration::delete_connection($session_id);
		}
	}

	/**
	 * Initialize the admin post apis
	 *
	 * @return void
	 */
	public function droip_wp_admin_post_apis()
	{
		if (!is_admin() && !HelperFunctions::has_access(DROIP_ACCESS_LEVELS['FULL_ACCESS'])) {
			wp_send_json_error('Not authorized');
		}

		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$endpoint = HelperFunctions::sanitize_text(isset($_POST['endpoint']) ? $_POST['endpoint'] : null);
		
		if ($endpoint === 'save-common-data') {
			WpAdmin::save_common_data();
		}

		if ($endpoint === 'update-license-validity') {
			WpAdmin::update_license_validity();
		}

		if ($endpoint === 'update-access-level') {
			RBAC::update_access_level();
		}

		if ($endpoint === 'delete-form-row') {
			Form::delete_form_row();
		}

		if ($endpoint === 'delete-form') {
			Form::delete_form();
		}

		if ($endpoint === 'update-form-cell') {
			Form::update_form_row();
		}
	}

	/**
	 * Initialize the admin get apis
	 *
	 * @return void
	 */
	public function droip_wp_admin_get_apis()
	{
		if (!is_admin()) {
			wp_send_json_error('Not authorized');
		}

		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$endpoint = HelperFunctions::sanitize_text(isset($_GET['endpoint']) ? $_GET['endpoint'] : null);
		
		if ($endpoint === 'get-common-data') {
			WpAdmin::get_common_data();
		}

		// From manipulation from admin dashboard.
		if ($endpoint === 'get-forms') {
			Form::get_forms();
		}

		if ($endpoint === 'get-form-data') {
			Form::get_form_data();
		}

		if ($endpoint === 'get-members-based-on-role') {
			RBAC::members_based_on_role();
		}

		if ($endpoint === 'download-form-data') {
			if (!HelperFunctions::has_access(DROIP_ACCESS_LEVELS['FULL_ACCESS'])) {
				wp_send_json_error('Not authorized');
			}

			Form::download_form_data();
		}

		/**
		 * GET Mailchimp Api Key Check
		 */

		if ($endpoint === 'validate-mailchimp-api-key') {
			//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$api_key = HelperFunctions::sanitize_text(isset($_GET['api_key']) ? $_GET['api_key'] : '');
			//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$server = HelperFunctions::sanitize_text(isset($_GET['server']) ? $_GET['server'] : '');
			Mailchimp::validate_api_key($api_key, $server);
		}
		// From manipulation from admin dashboard.
	}
}
