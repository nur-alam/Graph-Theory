<?php

/**
 * FormValidator class
 * 
 * This class is responsible for validating form data
 *
 * @package droip
 */

namespace Droip\ExportImport;

use Droip\Ajax\Media;
use Droip\Ajax\UserData;
use Droip\API\ContentManager\ContentManagerHelper;
use Droip\HelperFunctions;

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

//TODO: need to check lottie element

class TemplateImport
{
  private $zip_file_path = null;
  private $batch_id = null;
  private $variable_id_tracker = []; //this value is need to change the variable for every page or symbol
  private $post_id_tracker = [];
  private $delete_zip_after_import = true;

  
  private $asset_upload_tracker = [];  // [ 'old_attachment_id':{'new_attachment_id': , 'url': 'new_url', old_url:'old_url'}]
  // private $new_asset_urls = [];
  private $asset_upload_batch_size = 5;

  public function __construct()
  {
    
  }

  public function import($zip_file_path, $batch_id = 'b_1', $delete_zip_after_import = true){
    $this->delete_zip_after_import = $delete_zip_after_import;
    $this->batch_id = $batch_id;
    if(HelperFunctions::is_remote_url($zip_file_path)){
      $file_name_new = uniqid('', true) . '.zip'; // 'random.ext'
      $zip_file_path = HelperFunctions::download_zip_from_remote($zip_file_path, $file_name_new);
      if($zip_file_path){
        $this->zip_file_path = $zip_file_path;
      }else{
        wp_send_json_error('Failed to download zip file');
      }
    }else{
      $this->zip_file_path = $zip_file_path;
    }

    $zip = new \ZipArchive;
    $res = $zip->open($this->zip_file_path);

    if ($res === TRUE) {
      $upload_dir = wp_upload_dir();
      $temp_folder = 'droip_temp';
      $temp_folder_path = $upload_dir['basedir'] . '/' . $temp_folder;

      $zip->extractTo($temp_folder_path);
      $zip->close();

      if($this->delete_zip_after_import){
        unlink($this->zip_file_path);
      }

      $droip_json_file = $temp_folder_path . '/template-data.json';
      $json_data = file_get_contents($droip_json_file);
      $json_data = json_decode($json_data, true);

      if(empty($json_data) || !isset($json_data['pages'], $json_data['assetUrls'], $json_data['variables'], $json_data['globalStyleBlocks'], $json_data['customFonts'], $json_data['viewPorts'], $json_data['contentManager'], $json_data['templates'])){
        wp_send_json_error('Failed to import template, Upload Droip Exported Zip file');
      }
      $environment = [
        'temp_folder_path' => $temp_folder_path,
        'upload_dir' => $upload_dir,
        'temp_folder' => $temp_folder,
        'json_data' => $json_data,
        'batch_id' => $this->batch_id,
        'variable_id_tracker' => $this->variable_id_tracker,
        'post_id_tracker' => $this->post_id_tracker,
        'asset_upload_tracker' => $this->asset_upload_tracker,
        'queue' => [
          'assetUrls', 
          'viewPorts', 
          'customFonts', 
          'variables', 
          'globalStyleBlocks', 
          'contentManager', 
          'symbols', 
          'pages',
          'popups', 
          'templates', 
          'utility_pages', 
          'siteInfo'
        ],
      ];
      HelperFunctions::update_global_data_using_key( 'droip_project_import', $environment );
      return true;
    }
    return false;
  }

  public function process(){
    $environment = HelperFunctions::get_global_data_using_key( 'droip_project_import' );
    if(!$environment){
      return ['status'=> false, 'message' =>'Nothing found to import'];
    }
    $queue = $environment['queue'];
    $temp_folder_path = $environment['temp_folder_path'];

    if ( count($queue) > 0 ) {
      $this->batch_id = $environment['batch_id'];
      $this->variable_id_tracker = $environment['variable_id_tracker'];
      $this->post_id_tracker = $environment['post_id_tracker'];
      $this->asset_upload_tracker = $environment['asset_upload_tracker'];
      
      $upload_dir = $environment['upload_dir'];
      $temp_folder = $environment['temp_folder'];
      $json_data = $environment['json_data'];

      $current_task = array_shift($queue);
      switch ( $current_task ) {
        case 'assetUrls':{
          $this_batch_assets = array();
          $left_assets = array();
          $count = 0;
          if (count($json_data['assetUrls']) > $this->asset_upload_batch_size) {
            foreach ($json_data['assetUrls'] as $key => $a) {
              if($count < $this->asset_upload_batch_size){
                $this_batch_assets[$key] = $a;
              }else{
                $left_assets[$key] = $a;
              }
              $count++;
            }

            array_unshift($queue, $current_task);
          }else{
            $this_batch_assets = $json_data['assetUrls'];
          }
          $this->import_assets($this_batch_assets, $upload_dir, $temp_folder);
          $json_data['assetUrls'] = $left_assets;
          break;
        }
        // viewPorts
        case 'viewPorts':{
          $this->import_view_ports($json_data['viewPorts']);  
          break;
        }
        // customFonts
        case 'customFonts':{
          $this->import_custom_fonts($json_data['customFonts']);
          break;
        }
        // variables
        case 'variables':{
          $this->import_variables($json_data['variables']);
          break;
        }
    
        // globalStyleBlocks
        case 'globalStyleBlocks':{
          $this->import_global_style_blocks($json_data['globalStyleBlocks']);
          break;
        }
        
        // contentManager
        case 'contentManager':{
          $this->import_content_manager($json_data['contentManager']);
          break;
        }
    
        // symbols
        case 'symbols':{
          $this->import_pages($json_data['symbols']);
          break;
        }
    
        // popups
        case 'popups':{
          $this->import_pages($json_data['popups']);
          break;
        }

        // pages
        case 'pages':{
          $this->import_pages($json_data['pages']);
          break;
        }
        // templates
        case 'templates':{
          $this->import_pages($json_data['templates']);
          break;
        }
        
        // utility_pages
        case 'utility_pages':{
          $this->import_pages($json_data['utility_pages']);
          break;
        }
        
        // siteInfo
        case 'siteInfo':{
          $this->import_site_info($json_data['siteInfo']);
          break;
        }
        default:
          # code...
          break;
      }

      $environment['queue'] = $queue;
      $environment['json_data'] = $json_data;
      $environment['variable_id_tracker'] = $this->variable_id_tracker;
      $environment['post_id_tracker'] = $this->post_id_tracker;
      $environment['asset_upload_tracker'] = $this->asset_upload_tracker;
      HelperFunctions::update_global_data_using_key( 'droip_project_import', $environment );
      return ['status'=>'importing', 'queue' => $queue, 'done' => $current_task];
    }else{
      HelperFunctions::delete_directory($temp_folder_path);
      flush_rewrite_rules(true);
      HelperFunctions::update_global_data_using_key( 'droip_project_import', false );
      return ['status'=>'done', 'queue' => $queue];
    }
  }

  private function import_site_info($new_site_info)
  {
    if(!empty($new_site_info['page_on_front']) && isset($this->post_id_tracker[$new_site_info['page_on_front']])){
      update_option('page_on_front', $this->post_id_tracker[$new_site_info['page_on_front']]);
    }
    if(!empty($new_site_info['show_on_front'])){
      update_option('show_on_front', $new_site_info['show_on_front']);
    }
  }

  private function import_view_ports($new_view_ports){
    $control = HelperFunctions::get_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY );
    if(!$control){
      $control = array();
    }

    if(!isset($new_view_ports['list'])){
      $new_view_ports['list'] = array();
    }
    if( !isset( $control['viewport'], $control['viewport']['list'] ) ){
      $control['viewport'] = $new_view_ports;
    }else{
      $control['viewport']['list'] = (object) array_merge((array) $control['viewport']['list'], (array) $new_view_ports['list']);
    }
    HelperFunctions::update_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY, $control );
    return true;
  }
  
  private function import_custom_fonts($new_fonts){
    $custom_fonts = HelperFunctions::get_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY );
    if(!$custom_fonts){
      $custom_fonts = array();
    }
    $custom_fonts =  array_merge((array) $custom_fonts, (array) $new_fonts);

    HelperFunctions::update_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY, $custom_fonts );
    return true;
  }
  private function import_global_style_blocks($new_blocks){
    $new_styles = $this->add_prefix_to_style_blocks($new_blocks); 
    $global_styles = HelperFunctions::get_global_data_using_key(DROIP_GLOBAL_STYLE_BLOCK_META_KEY);
    if(!$global_styles){
      $global_styles = array();
    }
    $global_styles = array_merge((array) $global_styles, (array) $new_styles);
    HelperFunctions::save_global_style_blocks($global_styles);
    return true;
  }

  private function add_prefix_to_style_block_class_names($name){
    if(is_array($name)){
      foreach ($name as $key => $c) {
        $name[$key] = in_array($c, DROIP_PRESERVED_CLASS_LIST) ? $c : $this->add_prefix($c);
      }
    }else{
      $name = in_array($name, DROIP_PRESERVED_CLASS_LIST) ? $name : $this->add_prefix($name);
    }
    return $name;
  }

  private function add_prefix_to_style_blocks($style_blocks){
    $new_styles = [];
    foreach ($style_blocks as $key => $block) {
      $obj = $block;
      $obj['id'] = $this->add_prefix($obj['id']);
      $obj['name'] = $this->add_prefix_to_style_block_class_names($obj['name']);
      if(isset($obj['isDefault'])){
        //remove isDefault from object
        if($obj['isDefault'] === true){
          $obj['isGlobal'] = true;
        }
        unset($obj['isDefault']);
      }
      $new_styles[$this->add_prefix($key)] = $obj;
    }

    //STRING RELATED TASK START HERE
    $style_string = json_encode($new_styles);
    $style_string = $this->update_variable_data_from_css_string( $style_string );
    $style_string = $this->update_assets_url_from_css_string( $style_string );
    
    $new_styles = json_decode($style_string, true);
    //STRING RELATED TASK END HERE
    return $new_styles;
  }

  private function update_assets_url_from_css_string($string){
    return $string; //TODO: need to change assets url
    $string = stripslashes($string);
    
    foreach ($this->asset_upload_tracker as $key => $asset) {
      // Define the pattern to match 'http://jshossen.com'
      $pattern = '/' . preg_quote($asset['old_url'], '/') . '/';
      // Define the replacement URL
      $replacement = $asset['url'];
      // Replace the old URL with the new one
      $string = preg_replace($pattern, $replacement, $string);
    }

    return $string;
  }
  
  private function update_variable_data_from_css_string($string){
    foreach ($this->variable_id_tracker as $old => $new) {
      $pattern = '/var\(--' . preg_quote($old, '/') . '\)/';
      $replacement = "var(--$new)";
      $string = preg_replace($pattern, $replacement, $string);
    }
    return $string;
  }
  
  private function import_variables( $new_variables, $mode = 'default' ){
    $variables = UserData::get_droip_variable_data();

    $new_data = $new_variables['data'];
    foreach ($new_data as $key => $g) {
      foreach ($new_data[$key]['variables'] as $key2 => $v) {
        $new_id = $this->add_prefix($v['id']);
        $this->variable_id_tracker[$v['id']] = $new_id;
        $v['id'] = $new_id;
        $mode_value = isset($v['value'][$mode]) ? $v['value'][$mode] : $v['value']['default'];
        $v['value'] = array('default' => $mode_value);
        $new_data[$key]['variables'][$key2] = $v;
      }
    }
    $variables['data'] = array_merge((array) $variables['data'], (array) $new_data);
    $saved_data = HelperFunctions::get_global_data_using_key( DROIP_USER_SAVED_DATA_META_KEY );
    if(!$saved_data){
      $saved_data = array();
    }
    $saved_data['variableData'] = $variables;

    HelperFunctions::update_global_data_using_key( DROIP_USER_SAVED_DATA_META_KEY, $saved_data );
    return true;
  }

  private function import_content_manager($content_manager_posts){
    foreach ($content_manager_posts as $key => $parent_post) {
      $this->insert_single_post($parent_post);
    }
  }
  
  private function import_pages($new_pages){
    foreach ($new_pages as $key => $new_page) {
      $this->insert_single_post($new_page);
    }
  }

  private function add_post_all_meta($post){
    $meta = $post['meta'];
    $post_id = $post['ID'];

    foreach ($meta as $key => $value) {
      $v = $value[0];
      // if(in_array($key, $this->reserved_dynamic_post_meta_keys)){
      // }
      $updated_key_value = $this->handle_droip_related_meta($key, $v, $post);
      update_post_meta( $post_id, $updated_key_value[0], $updated_key_value[1] );
    }
  }


  private function update_element_properties_symbol_id($data, $post_id) {
    foreach ($data as $key => $block) {
      if (isset($block['properties'], $block['properties']['symbolId'])) {
          $block['properties']['symbolId'] = $post_id; // Update symbolId with post_id
          $data[$key] = $block;
          break;
      }
    }
    return $data;
  }

  private function handle_droip_related_meta($key, $v, $post){
    // '_wp_page_template', 'droip_used_style_block_ids', 'droip', 'droip_global_style_block_random', 'droip_used_style_block_ids_random', 'droip_page_seo_settings', 'droip_variable_mode', 'droip_template_conditions','droip_cm_fields', 'droip_cm_basic_fields'
    $post_type = $post['post_type'];
    $post_parent = $post['post_parent'];
    $post_id = $post['ID'];

    if(is_serialized($v)){
      $v = maybe_unserialize($v);
    }
    switch ($key) {
      case 'droip':
        if($post_type === 'droip_symbol'){
          $v['data'] = $this->add_prefix_to_droip_blocks($v['data']);
          $v['data'] = $this->update_element_properties_symbol_id($v['data'], $post_id);
          $v['styleBlocks'] = $this->add_prefix_to_style_blocks($v['styleBlocks']);
          $v['conditions'] = $this->check_droip_conditions($v['conditions']);
        }else if($post_type === 'droip_popup'){
          $v = $this->add_prefix_to_droip_blocks($v);
          foreach ($v as $key2 => $v2) {
            if($v2['name'] === 'popup' && isset($v2['properties'], $v2['properties']['popup'], $v2['properties']['popup'], $v2['properties']['popup']['visibilityConditions'])){
              $v2['properties']['popup']['visibilityConditions'] = $this->check_droip_conditions($v2['properties']['popup']['visibilityConditions']);
            }
            $v[$key2] = $v2;
          }
        }else{
          //template, pages
          $v['blocks'] = $this->add_prefix_to_droip_blocks($v['blocks']);
        }
        return [$key, $v];
      case '_wp_page_template':
        return [$key, DROIP_FULL_CANVAS_TEMPLATE_PATH];
        
      case 'droip_variable_mode':
        return [$key, ''];//TODO: need to get template mode or selected mode by user
        return [$key, $this->add_prefix($v)];

      case 'droip_page_seo_settings':
        //TODO: need to update seo settings for droip_template
        return [$key, $v];

      case 'droip_used_style_block_ids':
        foreach ($v as $key2 => $value) {
          $v[$key2] = $this->add_prefix($value);
        }
        return [$key, $v];
        
      case 'droip_used_style_block_ids_random':
        foreach ($v as $key2 => $value) {
          $v[$key2] = $this->add_prefix($value);
        }
        return [$key, $v];

      case 'droip_global_style_block_random':
        $updated_blocks = $this->add_prefix_to_style_blocks($v);
        return [$key, $updated_blocks];
        
      case 'droip_template_conditions':
        $v = $this->check_droip_conditions($v);
        return [$key, $v];
        
      case 'droip_cm_fields':
        //TODO: need to update cm fields default assets data
        return [$key, $v];
      case 'droip_cm_basic_fields':
        return [$key, $v];

      default:{
        if(str_contains($key, 'droip_cm_field_')){
          //thats means this is content manager item field post_meta key
          // Use preg_replace to replace the first instance of the numbers after 'droip_cm_field_' with $post_parent
          $key = preg_replace('/(droip_cm_field_)\d+/', '${1}' . $post_parent, $key);
          
          if( is_array($v) && isset($v['id'], $v['url'], $v['file_extension'])){
            //this is content manager asset
            $new_attachment_id = $this->asset_upload_tracker[$v['id']]['attachment_id'];
            if($new_attachment_id){
              $attachment_post = get_post($new_attachment_id);
              if($attachment_post){
                $m = new Media();
                $v = $m->format_media_data($attachment_post);
              }
            }
          }
        }
        return [$key, $v];
      }
    }
  }

  private function check_droip_conditions($conditions){
    foreach ($conditions as $key => $condition) {
      if(str_contains($condition['category'], 'droip_cm_')){
        $post_parent = str_replace('droip_cm_', '', $condition['category']);
        if(isset($this->post_id_tracker[$post_parent])){
          $post_parent = $this->post_id_tracker[$post_parent];
        }
        $condition['category'] = ContentManagerHelper::get_child_post_post_type_value($post_parent);
        if(isset($condition['apply'], $condition['apply']['to'])){
          $condition['apply']['to'] = $this->post_id_tracker[$condition['apply']['to']];
        }
      }
      $conditions[$key] = $condition;
    }
    return $conditions;
  } 

  private function add_prefix_to_droip_blocks($blocks){
    $new_data = [];
    foreach ($blocks as $key => $block) {
      $obj = $block;
      if(isset($obj['styleIds']) && count($obj['styleIds']) > 0){
        foreach ($obj['styleIds'] as $key2 => $style_id) {
          $obj['styleIds'][$key2] = $this->add_prefix($style_id);
        }
      }
      //update assets url for droip block
      $obj = $this->update_asset_url_for_droip_block($obj);

      //update symbol id for droip block
      $obj = $this->update_symbol_id_for_droip_block($obj);

      //update interaction data for droip block
      $obj = $this->update_interaction_data_for_droip_block($obj);

      //update collection post type for droip content manager
      $obj = $this->update_collection_settings_for_droip_block($obj);
      //TODO: need to update collection element filter data for cm (may be not need to do anything.)

      //TODO: update page link for link block element 
      //TODO: need to update nav menu functionality 
      
      //
      $new_data[$key] = $obj;
    }
    return $new_data;
  }

  private function insert_single_post($new_post){
    $new_post_id = wp_insert_post(
      array(
        'post_title' => $new_post['post_title'],
        'post_content' => $new_post['post_content'],
        'post_status' => $new_post['post_status'],
        'post_name' => $new_post['post_name'],
        'post_parent' => $new_post['post_parent'],
        'menu_order' => $new_post['menu_order'],
        'post_type' => $new_post['post_type'],
      )
    );
    
    if($new_post_id){
      $this->post_id_tracker[$new_post['ID']] = $new_post_id;
      $new_post['ID'] = $new_post_id;
      $this->add_post_all_meta($new_post);

      if(isset($new_post['children']) && count($new_post['children']) > 0){
        foreach ($new_post['children'] as $key => $child) {
          $child['post_parent'] = $new_post_id;
          if(str_contains($child['post_type'], 'droip_cm_')){
            $child['post_type'] = ContentManagerHelper::get_child_post_post_type_value($new_post_id);
          }
          $this->insert_single_post($child);
        }
      }
    }
    return $new_post_id;
  }

  private function import_assets($asset_urls, $upload_dir, $temp_folder){

    foreach ($asset_urls as $key => $asset_item) {
      $attachment_id = $asset_item['attachment_id'];

      if(empty($this->asset_upload_tracker[$attachment_id]['url'])){
        // new asset
        $new_asset = $this->upload_file($asset_item, $upload_dir, $temp_folder);
        if ($new_asset) {
          $this->asset_upload_tracker[$attachment_id]['attachment_id'] = $new_asset['attachment_id'];
          $this->asset_upload_tracker[$attachment_id]['url'] = $new_asset['url'];
          $this->asset_upload_tracker[$attachment_id]['old_url'] = $asset_item['url'];

          // $item = [
          //   'new_url' => $new_asset['url'],
          //   'new_attachment_id' => $new_asset['attachment_id'],
          // ];

          // $this->new_asset_urls[$key] = array_merge($asset_item, $item);
        }
      }
      
      // else {
      //   $item = [
      //     'new_url' => $this->asset_upload_tracker[$attachment_id]['url'],
      //     'new_attachment_id' => $this->asset_upload_tracker[$attachment_id]['attachment_id'],
      //   ];

      //   $this->new_asset_urls[$key] = array_merge($asset_item, $item);
      // }
    }
  }

  private function upload_file($asset_item, $upload_dir, $temp_folder)
  {
    $asset_name = basename($asset_item['url']);
    $source_file_path = $upload_dir['basedir'] . '/' . $temp_folder . '/' . $asset_name;

    if (file_exists($source_file_path)) {
      $file_name = basename($source_file_path);

      // Set the destination directory
      $upload_dir = wp_upload_dir();
      $upload_path = $upload_dir['path'] . '/' . $file_name;

      // Upload the file
      $file_array = array(
        'name'     => $file_name,
        'tmp_name' => $source_file_path,
      );

      $_FILES['file'] = $file_array;

      $attachment_id = media_handle_upload('file', 0, array(), array('test_form' => false, 'action' => 'upload-attachment'));

      // Check if the upload was successful
      if (!is_wp_error($attachment_id)) {
        $post = get_post($attachment_id);

        $new_asset = [
          'url' =>  $post->guid,
          'attachment_id' => $attachment_id,
        ];

        return  $new_asset;
      }
    }

    return null;
  }

  private function update_symbol_id_for_droip_block($block){
    if($block['name'] === 'symbol'){
      $block['properties']['symbolId'] = $this->post_id_tracker[$block['properties']['symbolId']];
    }
    return $block;
  }
  
  private function update_collection_settings_for_droip_block($block){
    if($block['name'] === 'collection'){
      $dc = $block['properties']['dynamicContent'];
      if(isset($dc['collectionType'], $dc['type']) && $dc['collectionType'] === 'posts' && str_contains($dc['type'], 'droip_cm_')){
        $post_parent = str_replace('droip_cm_', '', $dc['type']);
        $dc['type'] = ContentManagerHelper::get_child_post_post_type_value($this->post_id_tracker[$post_parent]);

        $block['properties']['dynamicContent'] = $dc;
      }
    }
    return $block;
  }
  
  private function update_interaction_data_for_droip_block($block){
    if( isset($block['properties']['interactions']) ){

      $block['properties']['interactions']['deviceAndClassList'] = $this->update_interaction_device_and_class_list($block['properties']['interactions']['deviceAndClassList']);

      $elementAsTrigger = $block['properties']['interactions']['elementAsTrigger'];
      foreach ($elementAsTrigger as $key => $trigger) {

        foreach ($trigger as $key2 => $singleTrigger) {

          foreach ($singleTrigger as $key3 => $customOrPreset) {

            if(isset($customOrPreset['deviceAndClassList'])){
              $customOrPreset['deviceAndClassList'] = $this->update_interaction_device_and_class_list($customOrPreset['deviceAndClassList']);
            }
            foreach ($customOrPreset['data'] as $ele_id => $singleRes) {
              $obj = $singleRes;
              if ( str_contains( $ele_id, '____info' ) ) {
                if (isset($obj['applyToClass'], $obj['styleBlockId']) && $obj['applyToClass']) {
                  $obj['styleBlockId'] = $this->add_prefix($obj['styleBlockId']);
                }
              }
              $customOrPreset['data'][$ele_id] = $obj;
            }

            $singleTrigger[$key3] = $customOrPreset;
          }
          $trigger[$key2] = $singleTrigger;
        }

        $elementAsTrigger[$key] = $trigger;
      }
      $block['properties']['interactions']['elementAsTrigger'] = $elementAsTrigger;
    }
    return $block;
  }

  private function update_interaction_device_and_class_list($deviceAndClassList){
    if($deviceAndClassList && $deviceAndClassList['applyToClass'] && !empty($deviceAndClassList['styleBlockId'])){
      $deviceAndClassList['styleBlockId'] = $this->add_prefix($deviceAndClassList['styleBlockId']);
      $new_class_list = $this->add_prefix_to_style_block_class_names($deviceAndClassList['classList']);
      $deviceAndClassList['classList'] = $new_class_list;
    }

    return $deviceAndClassList;
  }

  private function update_asset_url_for_droip_block($block){
    // image
    if($block['name'] === 'image' && isset($block['properties']['wp_attachment_id'])){
      $block_attachment_id = $block['properties']['wp_attachment_id'];

      if(isset($this->asset_upload_tracker[$block_attachment_id])){
        $block['properties']['wp_attachment_id'] = $this->asset_upload_tracker[$block_attachment_id]['attachment_id'];
        $block['properties']['attributes']['src'] = $this->asset_upload_tracker[$block_attachment_id]['url'];
      };
    }else if($block['name'] === 'video'){
      foreach ($this->asset_upload_tracker as $key => $asset_item) {
        if($block['properties']['attributes']['src'] === $asset_item['old_url'] ){
          $block['properties']['attributes']['src'] = $asset_item['url'];
          $block['properties']['wp_attachment_id'] = $asset_item['attachment_id'];
        }

        if($block['properties']['thumbnail']['url'] === $asset_item['old_url'] ){
          $block['properties']['thumbnail']['url'] = $asset_item['url'];
          $block['properties']['thumbnail']['wp_attachment_id'] = $asset_item['attachment_id'];
        }
      }
    }else if($block['name'] === 'lottie'){

      foreach ($this->asset_upload_tracker as $key => $asset_item) {
        if($block['properties']['lottie']['src'] === $asset_item['old_url'] ){
          $block['properties']['lottie']['src'] = $asset_item['url'];
          $block['properties']['wp_attachment_id'] = $asset_item['attachment_id'];
        }
      }
    }

    else if($block['name'] === 'lightbox'){
      foreach ($this->asset_upload_tracker as $key => $asset_item) {
        if($block['properties']['lightbox']['thumbnail']['src'] === $asset_item['old_url'] ){
          $block['properties']['lightbox']['thumbnail']['src'] = $asset_item['url'];
          $block['properties']['wp_attachment_id'] = $asset_item['attachment_id'];
        }
      }

      if(!empty($block['properties']['lightbox']['media'])){
        $media = $block['properties']['lightbox']['media'];

        foreach ($media as $key => $media_item) {
          if(!empty($media_item['id']) && isset($this->asset_upload_tracker[$media_item['id']])){
            $media[$key]['id'] = $this->asset_upload_tracker[$media_item['id']]['attachment_id'];
            $media[$key]['sources']['original'] = $this->asset_upload_tracker[$media_item['id']]['url'];
          }
        }
        $block['properties']['lightbox']['media'] = $media;
      }

    }

    return $block;
  }
  
  private function add_prefix($string){
    $prefix = $this->batch_id . '_';
    //TODO: if already a prefix exists, replace with new prefix
    return $prefix . $string;
  }

}
