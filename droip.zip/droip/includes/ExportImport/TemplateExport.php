<?php

/**
 * FormValidator class
 * 
 * This class is responsible for validating form data
 *
 * @package droip
 */

namespace Droip\ExportImport;

use Droip\Ajax\UserData;
use Droip\HelperFunctions;

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

class TemplateExport
{

  private $discarded_meta = ['_edit_lock', '_edit_last'];
  public $asset_urls;
  private $asset_urls_tracker = [];

  public function __construct()
  {
    $this->asset_urls = [];
  }

  public function export_and_get_url()
  {
    // creating a zip file name for template export.
    $site_name = get_bloginfo('name');
    // Check if $site_name is empty or not found
    if (empty($site_name)) {
      $site_name = 'droip-template'; // Fallback name
    }
    // Convert the site name to a slug format
    $zip_filename = strtolower(str_replace(' ', '-', $site_name));

    $template_data = array(
      'exportId' => uniqid('', true),
      'pages' => $this->get_all_pages(),
      'viewPorts' => $this->get_view_ports(),
      'symbols' => $this->get_all_symbols(),
      'popups' => $this->get_all_popups(),
      'templates' => $this->get_all_templates(),
      'utility_pages' => $this->get_all_utility_pages(),
      'customFonts' => $this->get_custom_fonts(),
      'globalStyleBlocks' => $this->get_global_style_blocks(),
      'variables' => UserData::get_droip_variable_data(),
      'contentManager' => $this->get_all_content_manager_data(),
      'siteInfo' => array(
        'siteName' => get_bloginfo('name'),
        'siteUrl' => get_bloginfo('url'),
        'siteDescription' => get_bloginfo('description'),
        'siteLogo' => get_site_icon_url(),
        'page_on_front' => get_option('page_on_front'),
        'show_on_front' => get_option('show_on_front'),
      )
    );

    $this->extract_asset_url_from_template_data($template_data);
    $template_data['assetUrls'] = $this->asset_urls_tracker;

    $zip_file_url = $this->make_zip_and_get_url($zip_filename, $template_data);

    return $zip_file_url;
  }
  private function extract_asset_url_from_template_data($template_data)
  {
    $this->extract_asset_url_from_content_manager($template_data['contentManager']);
    $this->extract_asset_url_from_pages($template_data['pages']);
    $this->extract_asset_url_from_template($template_data['templates']);
    $this->extract_asset_url_from_popups($template_data['popups']);
    $this->extract_asset_url_from_symbols($template_data['symbols']);
    $this->extract_asset_url_from_string(json_encode($template_data['globalStyleBlocks']));
  }

  private function extract_asset_url_from_string($string){
    if (!$string)
      return;
    $string = stripslashes($string);
    // Define a regular expression pattern to match any image URLs
    $pattern = '/https?:\/\/[^\s]+\/[^\s]+\.(jpg|jpeg|png|gif|svg|webp)/i';
    // Find all image URLs matching the pattern in the string
    preg_match_all($pattern, $string, $matches);
    // Output the found image URLs
    $image_urls = $matches[0];
    foreach ($image_urls as $key => $url) {
      $this->push_to_asset_urls_tracker(false, $url);
    }
  }
  private function extract_asset_url_from_content_manager($contentManager)
  {
    $types = ['image', 'video'];

    foreach ($contentManager as $key => $collection) {
      $asset_field_ids = [];
      $meta = $collection->meta;

      if (isset($meta['droip_cm_fields']) && !empty($meta['droip_cm_fields'])) {
        $fields = maybe_unserialize($meta['droip_cm_fields'][0]);

        //droip_cm_field_952_dp23nqfx
        if (is_array($fields) && !empty($fields)) {
          foreach ($fields as $field) {
            if (isset($field['type']) && in_array($field['type'], $types)) {
              $asset_field_ids[] = 'droip_cm_field_' . $collection->ID . '_' . $field['id'];
            }
          }
        }
      }

      if (count($collection->children) > 0) {
        foreach ($collection->children as $collection_data) {
          $meta = $collection_data->meta;

          foreach ($asset_field_ids as $asset_field_id) {
            if (isset($meta[$asset_field_id]) && !empty($meta[$asset_field_id])) {
              $asset = maybe_unserialize($meta[$asset_field_id][0]);

              if (!empty($asset) && isset($asset['id'])) {
                $this->push_to_asset_urls_tracker($asset['id'], $asset['url']);
              }
            }
          }
        }
      }
    }
  }

  private function extract_asset_url_from_pages($pages)
  {
    foreach ($pages as $page) {
      $meta = $page->meta;
      if (isset($meta['droip']) && !empty($meta['droip'])) {
        $droip_data = maybe_unserialize($meta['droip'][0]);

        if (is_array($droip_data) && !empty($droip_data)) {
          $this->exact_asset_url_from_blocks($droip_data['blocks'], 'pages');
        }
      }
      if(!empty($meta['droip_global_style_block_random'])){
        $droip_global_style_block_random = maybe_unserialize($meta['droip_global_style_block_random'][0]);
        $this->extract_asset_url_from_string(json_encode($droip_global_style_block_random));
      }
    }
  }

  private function extract_asset_url_from_template($templates)
  {
    foreach ($templates as $template) {
      $meta = $template->meta;
      if (isset($meta['droip']) && !empty($meta['droip'])) {
        $droip_data = maybe_unserialize($meta['droip'][0]);

        if (is_array($droip_data) && !empty($droip_data)) {
          $this->exact_asset_url_from_blocks($droip_data['blocks'], 'templates');
        }
      }
      if(!empty($meta['droip_global_style_block_random'])){
        $droip_global_style_block_random = maybe_unserialize($meta['droip_global_style_block_random'][0]);
        $this->extract_asset_url_from_string(json_encode($droip_global_style_block_random));
      }
    }
  }

  private function extract_asset_url_from_popups($popups)
  {
    foreach ($popups as $popup) {
      $meta = $popup->meta;

      if (isset($meta['droip']) && !empty($meta['droip'])) {
        $droip_data = maybe_unserialize($meta['droip'][0]);
        if (is_array($droip_data) && !empty($droip_data)) {
          $this->exact_asset_url_from_blocks($droip_data, 'popups');
        }
      }
    }
  }

  private function extract_asset_url_from_symbols($symbols)
  {
    foreach ($symbols as $symbol) {

      $meta = $symbol->meta;
      if (isset($meta['droip']) && !empty($meta['droip'])) {
        $droip_data = maybe_unserialize($meta['droip'][0]);

        if (is_array($droip_data) && !empty($droip_data)) {
          $this->exact_asset_url_from_blocks($droip_data['data'], 'symbols');
          $this->extract_asset_url_from_string(json_encode($droip_data['styleBlocks']));
        }
      }
    }
  }



  private function exact_asset_url_from_blocks($blocks, $context)
  {
    $upload_dir = wp_upload_dir();
    $base_url = $upload_dir['baseurl'];

    // $asset_urls = [];

    foreach ($blocks as $key => $block) {
      if ($block['name'] === 'image' && $block['properties']['attributes']['src']) {
        $this->push_to_asset_urls_tracker($block['properties']['wp_attachment_id'], $block['properties']['attributes']['src']);
      }

      if ($block['name'] === 'video' && $block['properties']['attributes']['src']) {
        $this->push_to_asset_urls_tracker(false, $block['properties']['attributes']['src']);
        if ($block['properties']['thumbnail']['url']) {
          $this->push_to_asset_urls_tracker($block['properties']['thumbnail']['wp_attachment_id'], $block['properties']['thumbnail']['url']);
        }
      }

      if ($block['name'] === 'lottie' && $block['properties']['lottie']['src']) {
        $this->push_to_asset_urls_tracker(false, $block['properties']['lottie']['src']);
      }
      if ($block['name'] === 'lightbox' && $block['properties']['lightbox']['thumbnail']['src']) {
        $this->push_to_asset_urls_tracker(false, $block['properties']['lightbox']['thumbnail']['src']);

        $lightbox_media = $block['properties']['lightbox']['media'];

        foreach ($lightbox_media as $key => $media_item) {
          if ($media_item['sources']['original']) {
            $this->push_to_asset_urls_tracker(false, $media_item['sources']['original']);
          }
        }
      }
    }

    // filter asset_urls using base_url if base_url not included remove item because it's not uploaded to wp media library
    // $asset_urls = array_filter($asset_urls, function ($asset_item) use ($base_url) {
    //   return strpos($asset_item['url'], $base_url) !== false;
    // });

    // $this->asset_urls = array_merge($this->asset_urls, $asset_urls);
  }

  private function make_zip_and_get_url($zip_filename, $template_data)
  {
    try {
      if (empty($wp_filesystem)) {
        require_once ABSPATH . '/wp-admin/includes/file.php';
        WP_Filesystem();
      }

      global $wp_filesystem;
      $zip = new \ZipArchive();

      $upload_dir = wp_upload_dir();

      // Step 1: create zip file path and json file path
      $template_filename = 'template-data.json';
      $zip_file_path = $upload_dir['basedir'] . "/$zip_filename.zip";
      $template_file_path = $upload_dir['basedir'] . '/' . $template_filename;

      // Step 2: Convert the data to JSON and write to the file
      $is_template_file_write = $wp_filesystem->put_contents(
        $template_file_path,
        json_encode($template_data, JSON_PRETTY_PRINT),
        FS_CHMOD_FILE // predefined mode settings for WP files
      );

      if ($is_template_file_write === false) {
        throw new \Exception('Failed to write template file');
      }

      // Step 3: Open the zip file
      if (true !== $zip->open($zip_file_path, \ZipArchive::CREATE)) {
        throw new \Exception('Failed to create zip file');
      }

      // Step 4: Add file to the zip file
      foreach ($template_data['assetUrls'] as $key => $asset_item) {
        $url = $asset_item['url'];
        $file_name = basename($url);

        $subdir_with_filename = explode("/uploads", $url)[1];  // /2021/05/1.jpg
        $file_path = $upload_dir['basedir'] . $subdir_with_filename; // /var/www/html/wp-content/uploads/2021/05/1.jpg

        if (file_exists($file_path)) {
          $zip->addFile($file_path, $file_name);
        }
      }

      // Step 5: add template file to zip
      if (false === $zip->addFile($template_file_path, $template_filename)) {
        throw new \Exception('Failed to add template-data.json file to zip');
      }

      $zip->close();

      // Step 6: remove the template file after zip file is created
      unlink($template_file_path);

      // Step 7: Download the created zip file
      return home_url("/?page-export=true&file-name=$zip_filename.zip");
    } catch (\Exception $e) {
      return false;
    }
  }

  private function get_global_style_blocks()
  {
    return HelperFunctions::get_global_data_using_key(DROIP_GLOBAL_STYLE_BLOCK_META_KEY);
  }

  private function get_all_pages()
  {
    return $this->get_posts_with_meta('page', ['publish']);
  }

  private function get_all_popups()
  {
    return $this->get_posts_with_meta(DROIP_APP_PREFIX . '_popup', ['publish', 'draft']);
  }

  private function get_all_templates()
  {
    return $this->get_posts_with_meta(DROIP_APP_PREFIX . '_template', ['publish']);
  }
  
  private function get_all_utility_pages()
  {
    return $this->get_posts_with_meta(DROIP_APP_PREFIX . '_utility', ['publish']);
  }

  private function get_all_symbols()
  {
    return $this->get_posts_with_meta(DROIP_APP_PREFIX . '_symbol', ['draft']);
  }

  private function get_all_content_manager_data()
  {
    $parent_posts =  $this->get_posts_with_meta(DROIP_APP_PREFIX . '_cm', ['publish']);

    foreach ($parent_posts as $key => $parent_post) {
      $parent_posts[$key]->children = $this->get_posts_with_meta(DROIP_APP_PREFIX . '_cm_' . $parent_post->ID, ['publish']);
    }

    return $parent_posts;
  }

  private function get_view_ports(){
    $control = HelperFunctions::get_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY );

    if(!$control){
      $control = [];
    }
    if(!isset($control['viewport'])){
      $control['viewport'] = HelperFunctions::get_initial_view_ports();
    }
    return $control['viewport'];
  }

  private function get_custom_fonts()
  {
    $custom_fonts = HelperFunctions::get_global_data_using_key(DROIP_USER_CUSTOM_FONTS_META_KEY);
    return $custom_fonts ? $custom_fonts : [];
  }
  private function get_posts_with_meta($post_type, $post_status = ['publish'])
  {
    $all_posts = get_posts(array(
      'post_type' => $post_type,
      'posts_per_page' => -1,
      'post_status' => $post_status
    ));
    foreach ($all_posts as $key => $post) {
      $post_meta = get_post_meta($post->ID);
      foreach ($this->discarded_meta as $discarded_meta_key) {
        unset($post_meta[$discarded_meta_key]);
      }
      $post->meta = $post_meta;
      $all_posts[$key] = $post;
    }

    return $all_posts;
  }

  private function push_to_asset_urls_tracker($attachment_id, $url){
    if(!$attachment_id){
      $attachment_id = attachment_url_to_postid($url);
    }
    if($attachment_id){
      $this->asset_urls_tracker[$attachment_id] = [
        'attachment_id' => $attachment_id,
        'url' => $url
      ];
    }
  }
}
