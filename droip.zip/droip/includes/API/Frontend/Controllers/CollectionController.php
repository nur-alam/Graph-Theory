<?php
/**
 * Collection controller
 *
 * @package droip
 */

namespace Droip\API\Frontend\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Users;
use Droip\Frontend\Preview\Preview;
use Droip\HelperFunctions;
use WP_REST_Server;


/**
 * CollectionController
 * Collection related routes and controller functions
 */
class CollectionController extends FrontendRESTController {
	/**
	 * Register register
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/collection',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_collection' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
				),
				'schema' => array( $this, 'get_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/comments',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_comments' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
				),
				'schema' => array( $this, 'get_item_schema' ),
			)
		);
		
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/users',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_users' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
				),
				'schema' => array( $this, 'get_item_schema' ),
			)
		);
	}

	/**
	 * Creates a collection page
	 *
	 * @param \WP_REST_Request $request all user request parameter.
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_collection( $request ) {
		$page          = filter_var( $request->get_param( 'page' ), FILTER_VALIDATE_INT );
		$page = empty($page) ? 1 : $page;
		$collection_id = filter_var( $request->get_param( 'collection_id' ), FILTER_SANITIZE_STRING );
		$filter     	 = json_decode($request->get_param( 'filter' ), true);
		$droip_data     	 = json_decode($request->get_param( 'droip_data' ), true);
		$context     	 = json_decode($request->get_param( 'context' ), true);
		$query = filter_var( $request->get_param( 'q' ), FILTER_SANITIZE_STRING );

		$blocks = $droip_data['blocks'];
		$styles = $droip_data['styles'];

		$filters = array();

		if (isset( $filter['taxonomy'] )) {
			foreach($filter['taxonomy'] as $name => $value) {
				if (!empty( $value )) {
					$filters[] = array(
						'id' 		 => 'taxonomy',
						'type' 		 => 'taxonomy',
						'taxonomy' => $name,
						'terms' 	 => $value,
					);
				}
			}
		}
		$options = [];
		if($context){
			if(isset($context['type']) && $context['type'] === 'post'){
				$options = array(
					'post' => get_post($context['id'])
				);
			}else if(isset($context['type']) && $context['type'] === 'user'){
				$options = array(
					'user' => Users::get_user_by_id($context['id'])
				);
			}
		}

		$collection_wrapper_html_string = HelperFunctions::get_html_using_preview_script( $blocks, $styles, $collection_id, null, array_merge(array(
			'page'				=> $page,
			'filters'			=> $filters,
			'q' => $query,
		), $options)
		);

		return rest_ensure_response( $collection_wrapper_html_string );
	}

	/**
	 * Creates a collection page
	 *
	 * @param \WP_REST_Request $request all user request parameter.
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_comments( $request ) {
		$page          = filter_var( $request->get_param( 'page' ), FILTER_VALIDATE_INT );
		$page = empty($page) ? 1 : $page;

		$collection_id = filter_var( ( $request->get_param( 'collection_id' ) ), FILTER_SANITIZE_STRING );
		$post_id       = filter_var( ( $request->get_param( 'post_id' ) ), FILTER_VALIDATE_INT );
		$droip_data     	 = json_decode($request->get_param( 'droip_data' ), true);

		$blocks = $droip_data['blocks'];
		$styles    = $droip_data['styles'];

		$collection_wrapper_html_string = HelperFunctions::get_html_using_preview_script( $blocks, $styles, $collection_id, null, array(
			'page'				=> $page,
			'post' => get_post($post_id),
		)
		);

		return rest_ensure_response( $collection_wrapper_html_string );
	}
	
	
	/**
	 * Creates a collection page
	 *
	 * @param \WP_REST_Request $request all user request parameter.
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_users( $request ) {
		$page          = filter_var( $request->get_param( 'page' ), FILTER_VALIDATE_INT );
		$page = empty($page) ? 1 : $page;
		$collection_id = filter_var( ( $request->get_param( 'collection_id' ) ), FILTER_SANITIZE_STRING );
		$post_id       = filter_var( ( $request->get_param( 'post_id' ) ), FILTER_VALIDATE_INT );
		$droip_data     	 = json_decode($request->get_param( 'droip_data' ), true);
		$query = filter_var( $request->get_param( 'q' ), FILTER_SANITIZE_STRING );

		$blocks = $droip_data['blocks'];
		$styles    = $droip_data['styles'];

		$collection_wrapper_html_string = HelperFunctions::get_html_using_preview_script( $blocks, $styles, $collection_id, null, array(
			'post' => get_post($post_id),
			'page'				=> $page,
			'q' => $query,
		)
		);

		return rest_ensure_response( $collection_wrapper_html_string );
	}
}
