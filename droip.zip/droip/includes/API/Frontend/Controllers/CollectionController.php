<?php
/**
 * Collection controller
 *
 * @package droip
 */

namespace Droip\API\Frontend\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
use Droip\Frontend\Preview\Preview;
use Droip\HelperFunctions;
use WP_REST_Server;


/**
 * CollectionController
 * Collection related routes and controller functions
 */
class CollectionController extends FrontendRESTController {
	/**
	 * Register register
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/collection',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_collection' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::READABLE ),
				),
				'schema' => array( $this, 'get_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/comments',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_comments' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::READABLE ),
				),
				'schema' => array( $this, 'get_item_schema' ),
			)
		);
	}

	/**
	 * Creates a collection page
	 *
	 * @param \WP_REST_Request $request all user request parameter.
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_collection( $request ) {
		$page          = filter_var( $request->get_param( 'page' ), FILTER_VALIDATE_INT );
		$page = empty($page) ? 1 : $page;
		$collection_id = filter_var( $request->get_param( 'collection_id' ), FILTER_SANITIZE_STRING );
		$filter     	 = json_decode($request->get_param( 'filter' ), true);
		$droip_data     	 = json_decode($request->get_param( 'droip_data' ), true);

		$blocks = $droip_data['blocks'];
		$styles = $droip_data['styles'];
		$collection_data       = $blocks[ $collection_id ];
		$posts_per_page = isset( $collection_data['properties']['dynamicContent']['items'] ) ? $collection_data['properties']['dynamicContent']['items'] : 3;

		$filters = array();

		if (isset( $filter['taxonomy'] )) {
			foreach($filter['taxonomy'] as $name => $value) {
				if (!empty( $value )) {
					$filters[] = array(
						'id' 		 => 'taxonomy',
						'type' 		 => 'taxonomy',
						'taxonomy' => $name,
						'terms' 	 => $value,
					);
				}
			}
		}

		$collection_wrapper_html_string = HelperFunctions::get_html_using_preview_script( $blocks, $styles, $collection_id, null, array(
						'posts_count' => $posts_per_page,
						'page'				=> $page,
						'filter'			=> $filters
					)
		);

		return rest_ensure_response( $collection_wrapper_html_string );
	}

	/**
	 * Creates a collection page
	 *
	 * @param \WP_REST_Request $request all user request parameter.
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_comments( $request ) {
		$page          = filter_var( ( $request->get_param( 'page' ) ), FILTER_VALIDATE_INT );
		$collection_id = filter_var( ( $request->get_param( 'collection_id' ) ), FILTER_SANITIZE_STRING );
		$post_id       = filter_var( ( $request->get_param( 'post_id' ) ), FILTER_VALIDATE_INT );
		$droip_data     	 = json_decode($request->get_param( 'droip_data' ), true);

		$blocks = $droip_data['blocks'];
		$styles    = $droip_data['styles'];
		$collection_data       = $blocks[ $collection_id ];

		$commentSorting = isset($collection_data['properties']['dynamicContent']['commentSorting']) ? $collection_data['properties']['dynamicContent']['commentSorting'] : '';
		$commentFilter = isset($collection_data['properties']['dynamicContent']['commentFilters']) ? $collection_data['properties']['dynamicContent']['commentFilters'] : '';

		// change key name from type, value to order, orderby
		if (isset($commentSorting['type']) || isset($commentSorting['value'])) {
			$order = 'DESC';
			$orderby = 'comment_date_gmt';
			if (isset($commentSorting['type'])) {
				$order = $commentSorting['type'];
			}
			if (isset($commentSorting['value'])) {
				$orderby = $commentSorting['value'];
			}

			$commentSorting = array(
				'orderby' => $orderby,
				'order' => $order
			);
		}

		$collection_properties = $collection_data['properties'];

		$posts_per_page = isset( $collection_data['properties']['dynamicContent']['items'] ) ? $collection_data['properties']['dynamicContent']['items'] : 3;
		$offset         = ($page - 1) * $posts_per_page;
		$comments = HelperFunctions::get_comments(
			array(
				'post_id' => $post_id,
				// 'parent' => 0,
				'type' => $collection_properties['commentType'] ?? 'comments',
				'number' => $posts_per_page,
				'offset'      => $offset,
				'sorting' => $commentSorting,
				'filter' => $commentFilter
			)
		);
		$collection_wrapper_html_string = HelperFunctions::get_html_using_preview_script( $blocks, $styles, $collection_id, null, array(
			'comments' => $comments,
		)
		);

		return rest_ensure_response( $collection_wrapper_html_string );
	}
}
