<?php
/**
 * Preivew scripts data and styles helper
 *
 * @package droip
 */

namespace Droip\Frontend\Preview;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * DataHelper Class
 */
class DataHelper {

	/**
	 * Temporary IDs store variable
	 */
	public $temp_ids = array();
	/**
	 * Temporary Data store variable
	 */
	public $temp_data = array();

	/**
	 * Get unique new id
	 *
	 * @param int    $id data id.
	 * @param string $prefix class prefix id.
	 *
	 * @return int new id.
	 */
	private function get_unique_new_id( $id, $prefix = 'droip-symbol' ) {
		if ( isset( $this->temp_ids[ $id ] ) ) {
			$new_id = $this->temp_ids[ $id ];
		} else {
			$new_id                = $prefix . '-' . uniqid();
			$this->temp_ids[ $id ] = $new_id;
		}

		return $new_id;
	}

	/**
	 * Recursively update data id to new id.
	 *
	 * @param array  $data data.
	 * @param string $root root id.
	 * @param string $symbol_id symbol id.
	 *
	 * @return void update $temp_data for return.
	 */
	public function rec_update_data_id_to_new_id( $data, $root, $symbol_id = null ) {
		$id = $this->get_unique_new_id( $root );

		$prefix = null;
		if ( $symbol_id ) {
			$prefix = 'droip-symbol-' . $symbol_id;
		}
		$this_element       = $data[ $root ];
		$this_element['id'] = $id;

		if ( $this_element['parentId'] !== null ) {
			$this_element['parentId'] = $this->get_unique_new_id( $this_element['parentId'] );
		}

		if ( isset( $this_element['children'] ) && $this_element['children'] > 0 ) {
			$chs = array();
			foreach ( $this_element['children'] as $key => $c ) {
				$id    = $this->get_unique_new_id( $c );
				$chs[] = $id;
				$this->rec_update_data_id_to_new_id( $data, $c, $symbol_id );
			}
			$this_element['children'] = $chs;
		}

		if ( isset( $this_element['properties']['contents'] ) ) {
			$contents = array();
			foreach ( $this_element['properties']['contents'] as $key => $value ) {
				if ( is_array( $value ) ) {
					$id         = $this->get_unique_new_id( $value['id'] );
					$contents[] = array( 'id' => $id );
					$this->rec_update_data_id_to_new_id( $data, $value['id'], $symbol_id );
				} else {
					$contents[] = $value;
				}
			}
			$this_element['properties']['contents'] = $contents;
		}

		if ( isset( $this_element['properties']['interactions'] ) ) {
			foreach ( $this_element['properties']['interactions'] as $el_as_target_key => $el_as_target_value ) {
				if ( $el_as_target_key === 'deviceAndClassList' ) {
					$class_list = $this_element['properties']['interactions'][ $el_as_target_key ]['classList'];
					foreach ( $class_list as $key => $c ) {
						$class_list[ $key ] = $prefix ? $prefix . '-' . $c : $c;
					}
					$this_element['properties']['interactions'][ $el_as_target_key ]['classList'] = $class_list;
				} elseif ( $el_as_target_key === 'elementAsTrigger' ) {
					foreach ( $el_as_target_value as $event_key => $event_value ) {

						foreach ( $event_value as $custom_or_preset_key => $custom_or_preset_value ) {
							foreach ( $custom_or_preset_value as $single_res_key => $single_res_value ) {
								$new_data = array();
								foreach ( $single_res_value['data'] as $ele_id => $animation ) {
									if ( strpos( $ele_id, '____info' ) !== false ) {
										continue;
									}
									$new_id              = $this->get_unique_new_id( $ele_id );
									$new_data[ $new_id ] = $animation;
									if ( isset( $single_res_value['data'][ $ele_id . '____info' ], $single_res_value['data'][ $ele_id . '____info' ]['classList'] ) ) {

										if ( $prefix ) {
											$class_list = $single_res_value['data'][ $ele_id . '____info' ]['classList'];
											$class_list = array_map(
												function ( $val ) use ( $prefix ) {
													return $prefix . '-' . $val;
												},
												$class_list
											);
											$single_res_value['data'][ $ele_id . '____info' ]['classList'] = $class_list;
										}

										$new_data[ $new_id . '____info' ] = $single_res_value['data'][ $ele_id . '____info' ];
									}
								}
									$this_element['properties']['interactions'][ $el_as_target_key ][ $event_key ][ $custom_or_preset_key ][ $single_res_key ]['data'] = $new_data;
							}
						}
					}
				}
			}
		}

		$this->temp_data[ $this_element['id'] ] = $this_element;
	}

	public static function get_data_n_styles_from_root($root_id,&$data_n_styles, $data = array(), $styles = array() )
	{
		if ($root_id && isset($data[$root_id])) {
			$root_data = $data[$root_id];

			// Insert data
			$data_n_styles['blocks'][$root_id] = $root_data;

			// Insert styles
			if (isset($root_data['styleIds'])) {
				foreach ($root_data['styleIds'] as $styleId) {
					if (isset($styles[$styleId])) {
						$data_n_styles['styles'][$styleId] = $styles[$styleId];
					}
				}
			}

			// Text rendering element content may contain some element too, like bold, italic, strikethrough 
			if (
				isset($root_data['name']) &&
				(
					$root_data['name'] == 'paragraph' ||
					$root_data['name'] == 'heading' ||
					$root_data['name'] == 'text'
				) &&
				isset($root_data['properties']['contents']) &&
				is_array($root_data['properties']['contents'])
			) {
				foreach ($root_data['properties']['contents'] as $key => $content) {
					if (is_array($content) && isset($content['id'])) {
						self::get_data_n_styles_from_root($content['id'],$data_n_styles, $data, $styles );
					}
				}
			}

			// Insert children data recursively
			if (isset($root_data['children'])) {
				foreach ($root_data['children'] as $childId) {
					self::get_data_n_styles_from_root($childId, $data_n_styles, $data, $styles);
				}
			}
		}
	}
}
