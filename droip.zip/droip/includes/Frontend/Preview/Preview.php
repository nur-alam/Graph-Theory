<?php
/**
 * Preview script for html markup generator
 *
 * @package droip
 */

namespace Droip\Frontend\Preview;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Symbol;
use Droip\Frontend\Preview\ExceptionalElements;
use Droip\Ajax\UserData;
use Droip\Ajax\WpAdmin;
use Droip\API\ContentManager\ContentManagerHelper;
use Droip\HelperFunctions;

/**
 * Preview class
 */
class Preview extends ExceptionalElements {

	/**
	 * $root for entry id or parent element id.
	 */
	protected $root = null;
	/**
	 * $data is for all element data array.
	 */
	protected $data = array();
	/**
	 * $symbol_id if preview is generate for symbol then it has symbol_id for maintain class-prefix.
	 */
	protected $symbol_id = null;
	/**
	 * $style_blocks for all style blocks merged array. like=> global, migrated, symbols. etc.
	 */
	protected $style_blocks = array();
	/**
	 * $only_used_style_blocks only used style blocks.
	 */
	private $only_used_style_blocks = array();
	/**
	 * $only_used_popup_id_array only used popup post ids.
	 */
	public static $only_used_popup_id_array = array();
	/**
	 * $printed_font_family_tracker for tracking already printed font family markup.
	 */
	private static $printed_font_family_tracker = array();
	/**
	 * $view_ports user all viewports data.
	 */
	private $view_ports = array();

	/**
	 * Initialize some variables for element related data. Like: custom codes, lightbox, map, slider etc.
	 * START
	 */
	/**
	 * $sliders for collect slider elements data.
	 */
	private $sliders = array();
	/**
	 * $maps for collect map elements data.
	 */
	private $maps = array();
	/**
	 * $lotties for collect lottie elements data.
	 */
	private $lotties = array();
	/**
	 * $popups for collect popup elements data.
	 */
	private $popups = array();
	/**
	 * $tabs for collect tab elements data.
	 */
	private $tabs = array();
	/**
	 * $lightboxes for collect lightbox elements data.
	 */
	private $lightboxes = array();
	/**
	 * $re_captchas for collect reCaptcha elements data.
	 */
	private $re_captchas = array();
	/**
	 * $videos for collect video elements data.
	 */
	private $videos = array();
	/**
	 * $interactions for collect interaction elements data.
	 */
	private $interactions = array();
	/**
	 * $collections for collect collection elements data.
	 */
	private $collections = array();
	/**
	 * $forms for collect form elements data.
	 */
	private $forms = array();
	/**
	 * $custom_codes for collect customCode elements data.
	 */
	public $custom_codes = '';

	/**
	 * $dropdown for collect dropdown elements data.
	 */
	private $dropdown = array();
	/**
	 * Initialize some variables for element related data. Like: custom codes, lightbox, map, slider etc.
	 * END
	 */


	/**
	 * List of exceptional elements.
	 */
	private $exceptional_elements = array(
		'custom-code',
		'map',
		'svg',
		'svg-icon',
		'textarea',
		'select',
		'video',
		'radio-group',
		'checkbox-element',
		'radio-button',
		'image',
		'nav_menu',
		'collection',
		'collection-wrapper',
		'comments',
		'comment-item',
		'pagination',
		'pagination-item',
		'pagination-number',
		'terms',
		'menus',
		'symbol',
		'link-block',
		'form',
		'button',
		'file-upload-inner',
		'file-upload-threshold-text',
		'file-upload',
		'popup-body'
	);
	
	/**
	 * List of dynamic content element.
	 */
	private $exceptional_elements_contains_dyn_content = array( 'nav_menu', 'collection' );
	/**
	 * List of inline elements.
	 */
	private $inline_elements = array( 'button', 'link-block', 'link-text' );

	/**
	 * List of anchor elements.
	 */
	private $prevent_anchor_elements = array( 'heading', 'image', 'paragraph' );
	/**
	 * List anchor attrs.
	 */
	private $anchor_attrs = array( 'href', 'target', 'rel' );


	/**
	 * Preview script initilizer
	 *
	 * @param array  $data elments data array.
	 * @param array  $style_blocks elments style_blocks array.
	 * @param string $root root element id.
	 * @param string $symbol_id if preview script is initiate for symbol element generation.
	 *
	 * @return void
	 */
	public function __construct( $data, $style_blocks, $root = null, $symbol_id = null ) {
		if ( $root ) {
			$this->root = $root;
		} else {
			$this->root = 'root';
		}
		$this->data         = $data;
		$this->style_blocks = $style_blocks;
		$this->view_ports   = UserData::get_view_port_list();
		if ( $symbol_id ) {
			$this->symbol_id = $symbol_id;
		}
	}



	/**
	 * Get the style blocks that are used in the html
	 * this method is called after getHtml() method call and from the same instance
	 *
	 * @return string
	 */
	public function get_only_used_style_blocks() {
		return $this->only_used_style_blocks;
	}

	/**
	 * Get the style tag string
	 *
	 * @param  array|bool $blocks all styleblocks.
	 * @return string
	 */
	public function getStyleTag( $blocks = false ) {
		if ( ! $blocks ) {
			$blocks = $this->style_blocks;
		}

		$s = '';

		if ( $blocks ) {
			foreach ( $this->view_ports as $key => $vp ) {
					$css = '';
				foreach ( $blocks as $style_block ) {
					$css .= $this->getRawCssDeviceWise( $style_block, $vp );
				}
				if($css){
					$s .= "<style data='" . DROIP_APP_PREFIX . '-element-styles-' . $key . "'>";
					$s .= $css;
					$s .= '</style>';
				}
			}
		}
		return $s;
	}

	/**
	 * Get the html string
	 *
	 * @param array $block single style block.
	 * @param array $vp viewport.
	 *
	 * @return string
	 */
	private function getRawCssDeviceWise( $block, $vp ) {
		$css_string = '';
		$selector   = $this->getSelectorFromBlock( $block );
		$variants   = $block['variant'];

		foreach ( $variants as $key => $value ) {
			$variant = explode( '_', $key );
			if ( $variant[0] === $vp['id'] ) {
				$css_string .= $this->createMediaQueryString( $selector, $key, $value, $vp );
			}
		}
		return $css_string;
	}

	/**
	 * Create Media Query String
	 *
	 * @param string $selector calss/tag selector like => .class-name.
	 * @param string $device_name media query key like => md.
	 * @param string $css_text css text like => color:red.
	 * @param object $vp current viewport object.
	 *
	 * @return string
	 */
	private function createMediaQueryString( $selector, $device_name, $css_text, $vp ) {
		if ( $css_text === '' ) {
			return '';
		}
		$css_string = '';
		$variant    = explode( '_', $device_name );
		$type       = $vp['type'];
		if ( count( $variant ) === 1 ) {
			// default class or sub class for devices.
			if ( $variant[0] === 'md' ) {
				$css_string .= $selector . '{' . $css_text . '}';
			} elseif ( isset( $this->view_ports[ $variant[0] ] ) ) {
				$css_string .= '@media only screen and (' . $type . '-width: ' . $this->view_ports[ $variant[0] ][ $type . 'Width' ] . 'px) {' . $selector . '{' . $css_text . '}}';
			}
		} elseif ( count( $variant ) === 2 ) {
			// active, hover, focus or pseudo class.
			$psuedo_class = $this->checkIfHasPsuedoClassValue( $variant[1] );
			// $class_prefix = DROIP_CLASS_PREFIX;
			if ( $variant[0] === 'md' ) {
				$css_string .= $selector . $psuedo_class . '{' . $css_text . '}';
				// $css_string .= $selector . '.' . $class_prefix . '-' . $variant[1] . '{' . $css_text . '}';
			} elseif ( isset( $this->view_ports[ $variant[0] ] ) ) {
				$css_string .= '@media only screen and (' . $type . '-width: ' . $this->view_ports[ $variant[0] ][ $type . 'Width' ] . 'px) {';
				$css_string .= $selector . $psuedo_class . '{' . $css_text . '}';
				// $css_string .= $selector . '.' . $class_prefix . '-' . $variant[1] . '{' . $css_text . '}';
				$css_string .= '}';
			}
		} elseif ( count( $variant ) === 3 ) {
			// active, hover, focus + pseudo class.
			$psuedo_class1 = $this->checkIfHasPsuedoClassValue( $variant[1] );
			$psuedo_class2 = $this->checkIfHasPsuedoClassValue( $variant[2] );
			// $class_prefix  = DROIP_CLASS_PREFIX;

			if ( $variant[0] === 'md' ) {
				$css_string .= "$selector:$psuedo_class1:$psuedo_class2{$css_text}";
				// $css_string .= "$selector.$class_prefix" . '-' . $variant[1] . '-' . $variant[2] . "{$css_text}";
			} elseif ( isset( $this->view_ports[ $variant[0] ] ) ) {
				$css_string .= '@media only screen and (' . $type . '-width: ' . $this->view_ports[ $variant[0] ][ $type . 'Width' ] . 'px) {';
				$css_string .= $selector . $psuedo_class1 . $psuedo_class2 . '{' . $css_text . '}';
				// $css_string .= "$selector.$class_prefix" . '-' . $variant[1] . '-' . $variant[2] . "{$css_text}";
				$css_string .= '}';
			}
		}
		return $css_string;
	}

	/**
	 * Get the custom fonts links
	 *
	 * @return string
	 */
	public function getCustomFontsLinks() {
		$post_id = $this->symbol_id ? $this->symbol_id : HelperFunctions::get_post_id_if_possible_from_url();
		$post    = get_post( $post_id );

		if ( 'droip_symbol' === $post->post_type ) {
			$symbol = Symbol::get_single_symbol( $post_id, true );
			if ( isset( $symbol['symbolData'], $symbol['symbolData']['customFonts'] ) ) {
				$s = '';
				foreach ( $symbol['symbolData']['customFonts'] as $key => $f ) {
					$s .= $this->getFontsHTMLMarkup( $f );
				}
			}
		} else {
			$custom_fonts = HelperFunctions::get_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY );
			$used_fonts   = get_post_meta( $post_id, DROIP_META_NAME_FOR_USED_FONT_LIST, true );
			$s            = '';
			if ( $custom_fonts && is_array( $custom_fonts ) && $used_fonts && is_array( $used_fonts ) ) {
				foreach ( $used_fonts as $font ) {
					if ( isset( $custom_fonts[ $font ], $custom_fonts[ $font ]['fontUrl'] ) ) {
						//phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
						$s .= $this->getFontsHTMLMarkup( $custom_fonts[ $font ] );
					}
				}
			}
			return $s;
		}

		return '';
	}

	/**
	 * Get fonts html markup
	 * If HTML markup already created for a single font => thats means font link markup already created. then it will return empty string.
	 * Like, If same symbol used multiple times....
	 *
	 * @param object $fonts_data Single Fonts data.
	 * @return string <link markup
	 */
	public function getFontsHTMLMarkup( $fonts_data ) {
		if ( ! in_array( $fonts_data['family'], self::$printed_font_family_tracker, true ) ) {
			self::$printed_font_family_tracker[] = $fonts_data['family'];
			//phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
			return '<link class="' . DROIP_CLASS_PREFIX . '-custom-fonts-link" href="' . $fonts_data['fontUrl'] . '" rel="stylesheet">';
		}
		return '';
	}

	/**
	 * Get the html string
	 *
	 * @return string
	 */
	public function getHTML( $options = [] ) {
		return $this->recGenHTML( $this->root, $options );
	}

	/**
	 * Get the script tag string
	 *
	 * @return string
	 */
	public function getScriptTag() {
		$s = '';
		$empty_vars = $this->getVariableString( 'Sliders', $this->sliders );
		$empty_vars .= $this->getVariableString( 'Maps', $this->maps );
		$empty_vars .= $this->getVariableString( 'Lotties', $this->lotties );
		$empty_vars .= $this->getVariableString( 'Popups', $this->popups );
		$empty_vars .= $this->getVariableString( 'Lightboxes', $this->lightboxes );
		$empty_vars .= $this->getVariableString( 'ReCaptchas', $this->re_captchas );
		$empty_vars .= $this->getVariableString( 'Videos', $this->videos );
		$empty_vars .= $this->getVariableString( 'Tabs', $this->tabs );
		$empty_vars .= $this->getVariableString( 'Interactions', $this->interactions );
		$empty_vars .= $this->getVariableString( 'Collections', $this->collections );
		$empty_vars .= $this->getVariableString( 'Forms', $this->forms );
		$empty_vars .= $this->getVariableString( 'Dropdown', $this->dropdown );
		
		
		if($empty_vars){
			$s .= "<script data='" . DROIP_APP_PREFIX . "-elements-property-vars'>";
			$s .= $empty_vars;
			$s .= '</script>';
		}

		if ( $this->custom_codes ) {
			$s .= "<script data='" . DROIP_APP_PREFIX . "-elements-property-dev-mode'>";
			$s .= $this->custom_codes;
			$s .= '</script>';
		}
		return $s;
	}

	private function getVariableString( $name, $value ) {
		if(count($value) === 0)return '';
		$prefix = DROIP_APP_PREFIX;
		$value  = wp_json_encode( $value );
		$s      = "var $prefix$name = window.$prefix$name === undefined? $value : {...$prefix$name, ...$value};";
		return $s;
	}

	/**
	 * Returns the JS code with `<script>` tag user put into `Page settings`
	 *
	 * @return string
	 */
	public static function getBodyCustomCode() {
		$post_id     = HelperFunctions::get_post_id_if_possible_from_url();
		$custom_code = get_post_meta( $post_id, DROIP_PAGE_CUSTOM_CODE, true );
		$code        = '<div data-' . DROIP_APP_PREFIX . "-code='custom-code'>";

		if ( isset( $custom_code['body'], $custom_code['body']['value'] ) ) {
			$code .= $custom_code['body']['value'];
		}
		$code .= '</div>';
		return $code;
	}

	/**
	 * Returns the css code with `<style>` tag user put into `Page settings`
	 *
	 * @return string
	 */
	public static function getHeadCustomCode() {
		$post_id     = HelperFunctions::get_post_id_if_possible_from_url();
		$custom_code = get_post_meta( $post_id, DROIP_PAGE_CUSTOM_CODE, true );
		$code = '';
		if ( isset( $custom_code['head'], $custom_code['head']['value'] ) ) {
			$code .= '<meta data-' . DROIP_APP_PREFIX . "-code='start' />";
			$code .= $custom_code['head']['value'];
			$code .= '<meta data-' . DROIP_APP_PREFIX . "-code='end' />";
		}
		return $code;
	}

	/**
	 * Returns `<meta>` tag with provided content
	 *
	 * @param string $name The meta name.
	 * @param string $content The meta description.
	 * @return string The `<meta />` tag.
	 */
	private static function getMeta($name, $content)
	{
		// Replace &nbsp; and \u00a0 with a space
		$content = preg_replace('/(?:&nbsp;|\x{00a0})/u', ' ', $content);

		// Escape double quotes in the content to avoid breaking the HTML attribute
		$content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');

		return "<meta name=\"{$name}\" content=\"{$content}\" />";
	}


	/**
	 * All meta tags
	 *
	 * @return string
	 */
	public static function getSeoMetaTags() {
		$post_id      = HelperFunctions::get_post_id_if_possible_from_url();
		$seo_settings = false;

		//get set settings from template if current page is droip template
		$template_data = HelperFunctions::get_template_data_if_current_page_is_droip_template();
		if($template_data){
			$seo_settings = get_post_meta( $template_data['template_id'], DROIP_PAGE_SEO_SETTINGS_META_KEY, true );
		}else{
			$seo_settings = get_post_meta( $post_id, DROIP_PAGE_SEO_SETTINGS_META_KEY, true );
		}

		$meta_tags    = '';

		if ( $seo_settings && $seo_settings['seoSettings'] && $seo_settings['seoSettings']['seoTitleTag'] && $seo_settings['seoSettings']['seoTitleTag']['value'] ) {
			$seo_title = self::getSeoValue($post_id, $seo_settings['seoSettings']['seoTitleTag']['value']);

			$meta_tags .= self::getMeta('title', $seo_title);
		}

		if ( $seo_settings && $seo_settings['seoSettings'] && $seo_settings['seoSettings']['seoMetaDesc'] && $seo_settings['seoSettings']['seoMetaDesc']['value'] ) {
			$seo_meta_desc = self::getSeoValue($post_id, $seo_settings['seoSettings']['seoMetaDesc']['value']);
			$meta_tags .= self::getMeta('description', $seo_meta_desc);
		}

		if ( $seo_settings && $seo_settings['openGraph'] && $seo_settings['openGraph']['openGraphImage'] && $seo_settings['openGraph']['openGraphImage']['value'] ) {
			$seo_open_graph_image = self::getSeoValue($post_id, $seo_settings['openGraph']['openGraphImage']['value']);

			$meta_tags .= self::getMeta('og:image', $seo_open_graph_image);
			$meta_tags .= self::getMeta('twitter:image', $seo_open_graph_image);
		}

		if ( $seo_settings && $seo_settings['openGraph'] && $seo_settings['openGraph']['openGraphTitle'] ) {
			// If og:title is sameAsSeoTitle.
			if (
			$seo_settings['openGraph']['openGraphTitle']['sameAsSeoTitle'] &&
			$seo_settings && $seo_settings['seoSettings'] && $seo_settings['seoSettings']['seoTitleTag'] && $seo_settings['seoSettings']['seoTitleTag']['value']
			) {
				$seo_title = self::getSeoValue($post_id, $seo_settings['seoSettings']['seoTitleTag']['value']);

				$meta_tags .= self::getMeta('og:title', $seo_title);
				$meta_tags .= self::getMeta('twitter:title', $seo_title);
			} elseif ( $seo_settings['openGraph']['openGraphTitle']['value'] ) {

				$og_title = self::getSeoValue($post_id, $seo_settings['openGraph']['openGraphTitle']['value']);

				$meta_tags .= self::getMeta('og:title', $og_title);
				$meta_tags .= self::getMeta('twitter:title', $og_title);
			}
		}

		if ( $seo_settings && $seo_settings['openGraph'] && $seo_settings['openGraph']['openGraphDesc'] ) {
			// If og:description is sameAsSeoMeta.
			if (
			$seo_settings['openGraph']['openGraphDesc']['sameAsSeoMeta'] &&
			$seo_settings && $seo_settings['seoSettings'] && $seo_settings['seoSettings']['seoMetaDesc'] && $seo_settings['seoSettings']['seoMetaDesc']['value']
			) {
				$seo_meta_desc = self::getSeoValue($post_id, $seo_settings['seoSettings']['seoMetaDesc']['value']);

				$meta_tags .= self::getMeta('og:description', $seo_meta_desc);
				$meta_tags .= self::getMeta('twitter:description', $seo_meta_desc);
			} elseif ( $seo_settings['openGraph']['openGraphDesc']['value'] ) {

				$og_meta_des = self::getSeoValue($post_id, $seo_settings['openGraph']['openGraphDesc']['value']);

				$meta_tags .= self::getMeta('og:description', $og_meta_des);
				$meta_tags .= self::getMeta('twitter:description', $og_meta_des);
			}
		}

		$meta_tags .= self::getMeta( 'og:url', get_permalink( $post_id ) );
		return $meta_tags;
	}

	/**
	 * Get the seo title
	 * 
	 * @param int $post_id post id.
	 * @param string|array $value seo title tag value.
	 * 
	 * @return string
	 */

	private static function getSeoValue($post_id, $value)
	{
		$seo_value = '';

		if (is_array($value)) {
			$post = get_post($post_id);
			$post_parent_id = null;
			//if template preview open
			if ($post->post_type && str_contains($post->post_type, DROIP_APP_PREFIX . '_template')) {
				// get post condition
				$post_conditions = get_post_meta($post->ID, DROIP_APP_PREFIX . '_template_conditions', true); // droip_cm_parentId
				$condition = $post_conditions[0];
				if (
					isset($condition['category']) &&
					!empty($condition['category'])
				) {
					if (strpos($condition['category'], DROIP_CONTENT_MANAGER_PREFIX) !== false) {
						//content manager related post
						$post_parent_id = str_replace(DROIP_CONTENT_MANAGER_PREFIX . '_', '', $condition['category']);

						$args = [
							'post_parent' => $post_parent_id,
							'page' => 1,
							'posts_per_page' => 1,
						];

						$res = ContentManagerHelper::get_all_child_items($args);

						if ($res && $res[0]) {
							$post = (object) $res[0];
						}
					}
				}
			}

			foreach ($value as $key => $val) {
				$option_type = $val['type'];
				$option_value = $val['value'];

				if ($option_type === 'text') {
					$seo_value .= $option_value;
				} else if ($option_type === 'post') {
					// post author
					if (isset($post->$option_value) && $option_value === 'post_author') {
						$seo_value .= get_the_author_meta('display_name', $post->post_author);
					} else if ($option_value === 'post_id') {
						$seo_value .= isset($post->ID) ? $post->ID : '';
					} else {
						$seo_value .= isset($post->$option_value) ? $post->$option_value : '';
					}
				} else if ($option_type === DROIP_CONTENT_MANAGER_PREFIX . '_field') {
					$meta_key = ContentManagerHelper::get_child_post_meta_key_using_field_id($post->post_parent, $option_value);

					$post_meta_value = get_post_meta($post->ID, $meta_key, true);

					// for image field
					if ($post_meta_value && isset($post_meta_value['url'])) {
						$post_meta_value = $post_meta_value['url'];
					}

					$seo_value .= strip_tags($post_meta_value);
				} else if ($option_type === 'featured_image') {
					$seo_value .= get_the_post_thumbnail_url( $post->ID );
				}
			}
		} else {
			$seo_value = $value;
		}

		return $seo_value;
	}

	/**
	 * Check if has pseudo class value
	 *
	 * @param string $s pseudo class name like => active, hover, focus, child(5th).
	 *
	 * @return string
	 */
	private function checkIfHasPsuedoClassValue( $s ) {
		if ( strpos( $s, '-----' ) !== false ) {
			$s_arr = explode( '-----', $s );
			$s     = $s_arr[0] . '(' . $s_arr[1] . ')';
		}
		return str_contains( $s, 'before' ) || str_contains( $s, 'after' ) ? '::' . $s : ':' . $s;
	}


	/**
	 * Get the selector from block
	 *
	 * @param array $block single style block.
	 *
	 * @return string
	 */
	private function getSelectorFromBlock( $block ) {
		$selector = '';

		$prefix = null;
		if ( $this->symbol_id ) {
			$prefix = 'droip-symbol-' . $this->symbol_id;
		}
		if ( $block['type'] === 'class' ) {
			if ( is_array( $block['name'] ) ) {
				$block['name'] = array_map(
					function ( $val ) use ( $prefix, $block ) {
						return $prefix && !in_array($val, DROIP_PRESERVED_CLASS_LIST) ? $prefix . '-' . $val : $val;
					},
					$block['name']
				);
				$selector      = '.' . str_replace( ' ', '.', $this->makeClassStringFromArray( $block['name'] ) );
			} else {
				$selector = '.' . $this->makeClassStringFromArray( array( $prefix && !in_array($block['name'], DROIP_PRESERVED_CLASS_LIST) ? $prefix . '-' . $block['name'] : $block['name'] ) );
			}
		} elseif ( $block['type'] === 'tag' ) {
			$selector = isset( $block['tag'] ) ? $block['tag'] : ( isset( $block['name'] ) ? $block['name'] : '' );
		}
		return $selector;
	}

	/**
	 * Insert element related data if needed
	 *
	 * @param array $element single element data.
	 * @return void
	 */
	private function insertElementRelatedConfig( $element, $options = array() ) {
		$id = $element['id'];
		if ( isset( $element['properties'] ) ) {
			$properties = $element['properties'];

			if ( isset( $properties['interactions'] ) ) {
				$this->interactions[ $id ] = $this->updateClassListForInteractionFromStyleBlockId($properties['interactions']);
			}

			if ( isset( $properties['code'], $properties['code']['javascript'] ) ) {
				$this->custom_codes .= str_replace( 'DROIP_TARGET_ELEMENT_ID', $id, $properties['code']['javascript'] );
			}

			// Store slider properties.
			if ( $element['name'] === 'slider' ) {
				$this->sliders[ $id ] = $properties['slider'];
			}

			if ( $element['name'] === 'popup' ) {
				$this->popups[ $id ] = $properties['popup'];
			}

			if ( $element['name'] === 'map' ) {
				$this->maps[ $id ] = $properties['map'];
			}

			if ( $element['name'] === 'video' ) {
				$this->videos[ $id ] = $properties['attributes'];
			}
			// Store Lottie properties.
			if ( $element['name'] === 'lottie' ) {
				$this->lotties[ $id ] = $properties['lottie'];
			}
			// Store Lottie properties.
			if ( $element['name'] === 'dropdown' ) {
				$this->dropdown[ $id ] = $properties['dropdown'];
			}

			if ( $element['name'] === 'tabs' ) {
				$this->tabs[ $id ]['active_tab']    = $properties['active_tab'];
				$this->tabs[ $id ]['animationName'] = $properties['animationName'];
				$this->tabs[ $id ]['easing']        = isset( $properties['easing'] ) ? $properties['easing'] : 'ease';
				$this->tabs[ $id ]['duration']      = isset( $properties['duration'] ) ? $properties['duration'] : 100;
			}

			if ( $element['name'] === 'lightbox' ) {
				$this->lightboxes[ $id ] = $properties['lightbox'];
			}

			if ( $element['name'] === 'collection' ) {
				$this->collections[ $id ] = $properties['dynamicContent'];
			}

			if (
				$element['name'] === 'input' ||
				$element['name'] === 'textarea' ||
				$element['name'] === 'select' ||
				$element['name'] === 'checkbox-element' ||
				$element['name'] === 'radio-group' ||
				$element['name'] === 'file-upload'
			) {
				$parent_form_id = $options['form']['id'] ?? '';
				$session_data = HelperFunctions::get_session_data($parent_form_id);

				$type = $element['properties']['attributes']['type'] ?? '';
				$others_attributes = array();

				if ('file-upload' === $element['name']) {
					$type = 'file';
					$others_attributes['max-file-size'] = $element['properties']['maxFileSize'] ?? 2;
				}

				if ($session_data && isset($element['properties']['attributes']['name'])) {
					if (!isset($session_data['fields'])) {
						$session_data['fields'] = array(
							$element['properties']['attributes']['name'] => array_merge(
								array(
									'type' => $type,
									'required' => $element['properties']['attributes']['required'] ?? false
								),
								$element['properties']['attributes'],
								$others_attributes,
							)
						);
					} else {
						$session_data['fields'][$element['properties']['attributes']['name']] = array_merge(
							array(
								'type' => $type,
								'required' => $element['properties']['attributes']['required'] ?? false,
							),
							$element['properties']['attributes'],
							$others_attributes,
						);
					}

					HelperFunctions::set_session_data($parent_form_id, $session_data);
				}
			}
			if ( $element['name'] === 'form' ) {
				$this->forms[ $id ] = array_merge( $properties['form'], $properties['attributes'] );
				$this->check_popup_inside_form( $properties['form'] );
				HelperFunctions::set_session_data($id, array_merge( array( 'id' => $id ), $this->forms[ $id ] ));
			}

			if ( $element['name'] === 'button' ) {
				$this->check_popup_inside_button( $properties );
			}
			
			if ( $element['name'] === 'button' || $element['name'] === 'link-text' || $element['name'] === 'link-block' ) {
				$this->check_popup_inside_button( $properties );
			}

			if ( $element['name'] === 'recaptcha' ) {
				$common_data = WpAdmin::get_common_data( true );
				if ( ! isset( $common_data['recaptcha'], $common_data['recaptcha']['GRC_version'] ) ) {
					return;
				}
				$version   = $common_data['recaptcha']['GRC_version'];
				$recaptcha = $common_data['recaptcha'][ $version ];

				$this->re_captchas[ $id ]['data-version'] = $version;
				$this->re_captchas[ $id ]['data-sitekey'] = $recaptcha['GRC_site_key'];
			}
		}
	}

	private function updateClassListForInteractionFromStyleBlockId($interactionData){
		foreach ( $interactionData as $el_as_target_key => $el_as_target_value ) {
			if ( $el_as_target_key === 'deviceAndClassList' ) {
				if(isset($interactionData['deviceAndClassList']['styleBlockId'])){
					$this_block = $this->style_blocks[$interactionData['deviceAndClassList']['styleBlockId']];
					if($this_block){
						$interactionData['deviceAndClassList']['classList'] = is_array($this_block['name'])?$this_block['name']:[$this_block['name']];
					}
				}
			} elseif ( $el_as_target_key === 'elementAsTrigger' ) {
				foreach ( $el_as_target_value as $event_key => $event_value ) {

					foreach ( $event_value as $custom_or_preset_key => $custom_or_preset_value ) {
						foreach ( $custom_or_preset_value as $single_res_key => $single_res_value ) {
							$new_data = array();
							foreach ( $single_res_value['data'] as $ele_id => $animation ) {
								if ( strpos( $ele_id, '____info' ) !== false ) {
									continue;
								}
								$new_data[$ele_id] = $animation;
								if ( isset( $single_res_value['data'][ $ele_id . '____info' ] ) ) {

									if(isset($single_res_value['data'][ $ele_id . '____info' ]['styleBlockId'])){

										$this_block = $this->style_blocks[$single_res_value['data'][ $ele_id . '____info' ]['styleBlockId']];
										if($this_block){
											$single_res_value['data'][ $ele_id . '____info' ]['classList'] = is_array($this_block['name'])?$this_block['name']:[$this_block['name']];
											$new_data[$ele_id . '____info'] = $single_res_value['data'][ $ele_id . '____info' ];
										}
									}else{
										//legecy code support
										$new_data[$ele_id . '____info'] = $single_res_value['data'][ $ele_id . '____info' ];
									}

								}
							}
							$interactionData[ $el_as_target_key ][ $event_key ][ $custom_or_preset_key ][ $single_res_key ]['data'] = $new_data;
						}
					}
				}
			}
		}
		return $interactionData;
	}

	/**
	 * Get element related config
	 *
	 * @return array
	 */
	public function get_element_related_config() {
		return array(
			'interactions' => $this->interactions,
			'sliders'      => $this->sliders,
			'popups'       => $this->popups,
			'maps'         => $this->maps,
			'lotties'      => $this->lotties,
			'tabs'         => $this->tabs,
			'lightboxes'   => $this->lightboxes,
			'collections'  => $this->collections,
			'forms'        => $this->forms,
			'reCaptchas'   => $this->re_captchas,
			'dropdown'     => $this->dropdown,
		);
	}

	/**
	 * Merge element related config.
	 *
	 * Set/merge all element releted cofig.
	 *
	 * @param array $configs element congiguration.
	 *
	 * @return void
	 */
	public function merge_element_related_config( $configs ) {
		$this->interactions = array_merge( $this->interactions, $configs['interactions'] );
		$this->sliders      = array_merge( $this->sliders, $configs['sliders'] );
		$this->popups       = array_merge( $this->popups, $configs['popups'] );
		$this->maps         = array_merge( $this->maps, $configs['maps'] );
		$this->lotties      = array_merge( $this->lotties, $configs['lotties'] );
		$this->tabs         = array_merge( $this->tabs, $configs['tabs'] );
		$this->lightboxes   = array_merge( $this->lightboxes, $configs['lightboxes'] );
		$this->collections  = array_merge( $this->collections, $configs['collections'] );
		$this->forms        = array_merge( $this->forms, $configs['forms'] );
		$this->re_captchas  = array_merge( $this->re_captchas, $configs['reCaptchas'] );
		$this->dropdown     = array_merge( $this->dropdown, $configs['dropdown'] );
	}

	/**
	 * Check popup inside button element. Insert the popup inside data.
	 *
	 * @param array $button_properties button properties.
	 *
	 * @return void
	 */
	private function check_popup_inside_button( $button_properties ) {
		// Search for popups.
		$type = isset( $button_properties['type'] ) ? $button_properties['type'] : '';

		if ( $type === 'popup' ) {
			$popup_id = (int) $button_properties['attributes']['popup'];
			if ( is_numeric( $popup_id ) ) {
				$this->insert_popup_into_data( $popup_id );
			}
		}
	}

	/**
	 * Check popup inside form element. then insert the popup data.
	 *
	 * @param array $form_properties form properties.
	 * @return void
	 */
	private function check_popup_inside_form( $form_properties ) {
		// Search for popups.
		$action_on_submit = isset( $form_properties['onSubmit']['type'] ) ? $form_properties['onSubmit']['type'] : '';

		$action_on_submit_success = isset( $form_properties['onSubmit']['value']['success'] ) ? $form_properties['onSubmit']['value']['success'] : '';

		$action_on_submit_fail = isset( $form_properties['onSubmit']['value']['fail'] ) ? $form_properties['onSubmit']['value']['fail'] : '';

		if ( $action_on_submit === 'popup' ) {
			if ( is_numeric( $action_on_submit_success ) ) {
				$this->insert_popup_into_data( $action_on_submit_success );
			}

			if ( is_numeric( $action_on_submit_fail ) ) {
				$this->insert_popup_into_data( $action_on_submit_fail );
			}
		}
	}

	/**
	 * Insert popup into data
	 *
	 * @param int $popup_id popup post id.
	 *
	 * @return void
	 */
	private function insert_popup_into_data( $popup_id ) {
		if ( in_array( $popup_id, self::$only_used_popup_id_array, true ) ) {
			return;
		}
		self::$only_used_popup_id_array[] = $popup_id;
	}

	/**
	 * Recursive function to generate html string
	 *
	 * @param int   $id root id.
	 * @param array $options elements option.
	 *
	 * @return string
	 */
	public function recGenHTML( $id, $options = array() ) {
		if ( ! isset( $this->data[ $id ] ) ) {
			return '';
		}
		$this_data = $this->data[ $id ];
		if ( isset( $this_data['hide'] ) && $this_data['hide'] === true ) {
			return '';
		}

		$this->insertElementRelatedConfig( $this_data, $options );

		if ( isset( $this_data['source'] ) && $this_data['source'] !== DROIP_APP_PREFIX ) {
			// if souce is not equal droip then the element came from external plugin
			return apply_filters(
				'droip_element_generator_' . $this_data['source'],
				'',
				array(
					'element'                => $this_data,
					'elements'               => $this->data,
					'style_blocks'           => $this->style_blocks,
					'attributes'             => $this->getAllAttributes( $this_data ),
					'options'                => $options,
					'generate_child_element' => array( $this, 'recGenHTML' ),
					'generate_child_element_with_new_id' => array( new HelperFunctions, 'rec_update_data_id_then_return_new_html' ),
				)
			);
		}

		if ( in_array( $this_data['name'], $this->exceptional_elements, true ) ) {
			if ( ! in_array( $this_data['name'], $this->exceptional_elements_contains_dyn_content, true ) || isset( $this_data['properties']['dynamicContent'] ) ) {
				return $this->get_this_exceptional_element( $this_data, $this->getAllAttributes( $this_data ), $options );
			}
		}

		if ( isset( $this_data['properties'], $this_data['properties']['noEndTag'] ) ) {
			$html = $this->noEndTagElements( $this_data, $options );
		} else {
			$html = $this->hasEndTagElements( $this_data, $options );
		}
		return $html;
	}


	/**
	 * Elements for has end tag
	 *
	 * @param array $this_data single element data.
	 * @param array $options element options data.
	 *
	 * @return string html markup.
	 */
	private function hasEndTagElements( $this_data, $options ) {
		$tag = isset( $this_data['properties'], $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
		$attributes = $this->getAllAttributes( $this_data );

		if($this_data['name'] == 'link-text' && isset($this_data['properties']['dynamicContent'])) {
			$dynamic_content = $this_data['properties']['dynamicContent'];
			$href = '';
			
			if ( $dynamic_content['type'] === 'post' ) {
				if(
					isset($options['post']) && 
					$options['post']->{$dynamic_content['value']}
				) {
					$href = $options['post']->{$dynamic_content['value']};
				} else {
					$href = HelperFunctions::get_post_dynamic_content( $dynamic_content['value'], isset( $options['post'] ) ? $options['post'] : null );
				}
			} else if ( 
				$dynamic_content['type'] === 'term' && 
				isset($options['term'])
			) {
				$href = get_tag_link($options['term']['term_id']);
			}

			$href = HelperFunctions::content_manager_link_filter($dynamic_content, $href);

			if ( $href ) {
				// replace href.
				$attributes = preg_replace( '/href="([^"]+")/i', "href='$href'", $attributes );
			}

			unset($this_data['properties']['dynamicContent']);
		}

		$child_content_or_html = $this->get_child_content_or_childrens($this_data, $options);

		$nested_not_allowed_tags = ['a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
		if(in_array($tag, $nested_not_allowed_tags) && HelperFunctions::check_string_has_this_tags($child_content_or_html, $tag)){
			$tag = 'div';
		}
		// Start Tag <div>.
		$html = '<' . $tag . ' ' . $attributes . '>';
			$html .= $child_content_or_html;
		$html .= '</' . $tag . '>';
		// End Tag </div>.
		return $html;
	}

	private function get_child_content_or_childrens($this_data, $options){
		$html = '';
		if ( ! isset( $this_data['children'] ) ) {
			$html .= $this->print_content( $this_data, $options );
		} else {
			$child_count = count( $this->data[ $this_data['id'] ]['children'] );
			for ( $i = 0; $i < $child_count; $i++ ) {
				$html .= $this->recGenHTML( $this->data[ $this_data['id'] ]['children'][ $i ], $options );
			}
		}
		return $html;
	}

	/**
	 * Print richtext content.
	 *
	 * @param array $this_data single element data.
	 * @param array $options single element options/dynamic data.
	 * @return string html markup.
	 */
	private function print_content( $this_data, $options ) {
		$html            = '';
		$properties      = $this_data['properties'];
		$content         = isset( $properties['contents'] ) ? $properties['contents'] : '';
		$dynamic_content = isset( $properties['dynamicContent'] ) ? $properties['dynamicContent'] : false;
		$href            = isset( $properties['attributes']['href'] ) ? $properties['attributes']['href'] : false;

		if ( $dynamic_content ) {
			if ( $dynamic_content['type'] === 'post' ) {
				$content = HelperFunctions::get_post_dynamic_content(
					$dynamic_content['value'],
					$options['post'] ?? null,
					$dynamic_content['meta'] ?? '',
				);

				// Date may need to format
				if ('post_date' === $dynamic_content['value'] && isset($dynamic_content['format'])) {
					$content = HelperFunctions::format_date($content, $dynamic_content['format']);
				}

				$html .= $content;
			} elseif ( $dynamic_content['type'] === 'term' && isset( $options['term'] ) && isset( $options['term'][ $dynamic_content['value'] ] ) ) {
				$html .= $options['term'][ $dynamic_content['value'] ];
			}elseif ( $dynamic_content['type'] === 'menu' && isset( $options['menu'] ) && isset( $options['menu']->{$dynamic_content['value']} ) ) {
				$html .= $options['menu']->{$dynamic_content['value']};
			} elseif ( 
				$dynamic_content['type'] === 'comment' && 
				isset( $options['comment'] ) && 
				$options['comment'] instanceof \stdClass && 
				!empty($options['comment']->{$dynamic_content['value']})
			) {
				$html .= $options['comment']->{$dynamic_content['value']};
			}
		} else {
			if ( is_array( $content ) ) {
				$content_count = count( $content );
				for ( $i = 0; $i < $content_count; $i++ ) {
					if ( is_array( $content[ $i ] ) ) {
						$html .= $this->recGenHTML( $content[ $i ]['id'], $options );
					} else {
						$html .= htmlspecialchars( $content[ $i ] );
					}
				}
			} else {
				$html .= htmlspecialchars( $content );
			}
		}
		if ( $href && $this_data['name'] !== 'link-text' ) {
			$target = isset( $properties['attributes'], $properties['attributes']['target'] ) ? "target={$properties['attributes']['target']}" : '';

			$rel = isset( $properties['attributes'], $properties['attributes']['rel'] ) ? "rel={$properties['attributes']['rel']}" : '';

			$html = "<a href={$href} {$target} {$rel}>{$html}</a>";
		}

		return $html;
	}

	/**
	 * Elements for no end tag
	 *
	 * @param array $this_data element single data.
	 * @param array $options element single option data.
	 *
	 * @return string html markup.
	 */
	private function noEndTagElements( $this_data, $options ) {
		$html = '<' . $this_data['properties']['tag'] . ' ' . $this->getAllAttributes( $this_data ) . '/>';
		return $html;
	}

	/**
	 * Get elements all attributes
	 *
	 * @param array $this_element single element data.
	 * @param array $filter_condition Attribute filter condition. Empty array returns all attributes.
	 *
	 * @return string attributes string.
	 */
	public function getAllAttributes( $this_element, $filter_condition = array() ) {
		if ( ! isset( $this_element['properties'] ) ) {
			return '';
		}

		$attr_str    = '';
		$class_names = trim( $this->getClassNames( $this_element ) );
		if ( $class_names ) {
			$attr_str .= 'class="' . $class_names . '"';
		}

		$others_attributes = '';
		if ( isset( $this_element['properties']['attributes'] ) ) {
			$attributes   = $this_element['properties']['attributes'];
			$element_name = $this_element['name'];

			if ( $this_element['name'] === 'image' && isset( $attributes['width'] ) ) {
				unset( $attributes['width'] );
			}

			$others_attributes = array_map(
				function ( $value, $key ) use ( $element_name ) {
					if ( in_array( $element_name, $this->prevent_anchor_elements, true ) && in_array( $key, $this->anchor_attrs, true ) ) {
						return '';
					}

					if ( ! $this->attribute_validation( $key, $value ) ) {
						return '';
					}

					if (is_array($value)) {
						$value = implode(' ', $value);
					}

					return $key . '="' . $value . '"';
				},
				array_values( $attributes ),
				array_keys( $attributes )
			);

			$others_attributes = ' ' . implode( ' ', $others_attributes );
		}

		$custom_attributes = '';
		if ( isset( $this_element['properties']['customAttributes'] ) ) {
			// phpcs:ignore WordPress.PHP.DisallowShortTernary.Found
			$attributes        = $this_element['properties']['customAttributes'] ?: array();
			$custom_attributes = array_map(
				function ( $value, $key ) {
					return $key . '="' . $value . '"';
				},
				array_values( $attributes ),
				array_keys( $attributes )
			);
			$custom_attributes = ' ' . implode( ' ', $custom_attributes );
		}

		if ( count( $filter_condition ) > 0 ) {
			$merged_attributes = array_merge( $this_element['properties']['attributes'], $attributes );
			// Merge attributes from other sources.
			$merged_attributes['class']      = $class_names;
			$merged_attributes['data-droip'] = $this_element['id'];

			if ( isset( $filter_condition['rest'] ) && false === $filter_condition['rest'] ) {
				// `rest => false` will pick only the `true` filter attributes.
				$filtered_attributes = array_filter(
					$merged_attributes,
					function ( $at ) use ( $filter_condition ) {
						return array_key_exists( $at, $filter_condition ) && true === $filter_condition[ $at ];
					},
					ARRAY_FILTER_USE_KEY
				);
			} else {
				// By default `rest` will be avaluted to `true`, so it will only remove the `false` attributes.
				$filtered_attributes = array_filter(
					$merged_attributes,
					function ( $at ) use ( $filter_condition ) {
						return ! ( array_key_exists( $at, $filter_condition ) && false === $filter_condition[ $at ] );
					},
					ARRAY_FILTER_USE_KEY
				);
			}

			$attr_str = array_reduce(
				array_keys( $filtered_attributes ),
				function ( $carry, $key ) use ( $filtered_attributes ) {
					return $carry . ' ' . $key . '=' . wp_json_encode( $filtered_attributes[ $key ] );
				},
				'',
			);

		} else {
			$attr_str .= ' data-' . DROIP_CLASS_PREFIX . '="' . $this_element['id'] . '"' . $others_attributes . $custom_attributes;
		}

		return $attr_str;
	}

	/**
	 * Attribute validation form different element attributes.
	 *
	 * @param string $attr name of the attribute.
	 * @param string $value value of the attribute.
	 *
	 * @return bool
	 */
	private function attribute_validation( $attr, $value ) {
		if ( $attr === 'multiple' && ! $value ) {
			return false;
		} elseif ( $attr === 'required' && ! $value ) {
			return false;
		} elseif ( $attr === 'src' && ! $value ) {
			return false;
		} elseif ( $attr === 'href' && ! $value ) {
			return false;
		} elseif ( $attr === 'checked' && ! $value ) {
			return false;
		}
		return true;
	}

	/**
	 * Get element class names
	 *
	 * @param array $this_element element data.
	 *
	 * @return string
	 */
	private function getClassNames( $this_element ) {
		$class_array = array();

		if ( isset( $this_element['styleIds'] ) ) {
			$style_ids_count = count( $this_element['styleIds'] );
			for ( $i = 0; $i < $style_ids_count; $i++ ) {
				$style_id = $this_element['styleIds'][ $i ];
				$s_block  = isset( $this->style_blocks[ $style_id ] ) ? $this->style_blocks[ $style_id ] : null;
				if ( ! isset( $s_block ) ) {
					continue;
				}
				$this->only_used_style_blocks[ $style_id ] = $s_block;
				$c_name                                    = $s_block['name'];
				$prefix                                    = null;
				if ( $this->symbol_id ) {
					$prefix = 'droip-symbol-' . $this->symbol_id;
				}
				if ( is_array( $c_name ) ) {
					$c_name      = array_map(
						function ( $val ) use ( $prefix, $s_block ) {
							return $prefix ? $prefix . '-' . $val : $val;
						},
						$c_name
					);
					$class_array = array_merge( $class_array, $c_name );
				} else {
					$class_array[] = $prefix ? $prefix . '-' . $c_name : $c_name;
				}
			}
		}

		$ele_class_names = isset( $this_element['className'] ) ? explode( ' ', $this_element['className'] ) : array();
		$class_array     = array_merge( $ele_class_names, $class_array );

		// Check for disabled styles panels.
		if ( isset( $this_element['stylePanels'] ) && is_array( $this_element['stylePanels'] ) ) {
			foreach ( $this_element['stylePanels'] as $name => $value ) {
				if ( ! $value ) {
					array_push( $class_array, DROIP_APP_PREFIX . '-disabled-' . $name );
				}
			}
		}

		if ( in_array( $this_element['name'], $this->inline_elements, true ) ) {
			array_push( $class_array, DROIP_CLASS_PREFIX . '-inline-element' );
		}

		return $this->makeClassStringFromArray( $class_array );
	}

	/**
	 * Make class string from array
	 *
	 * @param array $arr class array.
	 *
	 * @return string
	 */
	private function makeClassStringFromArray( $arr ) {
		$arr = array_unique( $arr );
		$arr = array_map(
			function ( $c ) {
				$c = strtolower( str_replace( ' ', '-', $c ) );

				return $c;
			},
			$arr
		);
		return join( ' ', $arr );
	}
}