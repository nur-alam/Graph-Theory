<?php
/**
 * Preview script helper class for handle exceptional element
 *
 * @package droip
 */

namespace Droip\Frontend\Preview;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Symbol;
use Droip\Ajax\Users;
use Droip\HelperFunctions;
use Droip\Ajax\WordpressData;

/**
 * ExceptionalElements Class
 */
class ExceptionalElements {

	/**
	 * Get this exceptional element
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */
	public function get_this_exceptional_element( $this_data, $attributes, $options ) {
		switch ( $this_data['name'] ) {
			case 'custom-code': {
				return $this->custom_code( $this_data, $attributes );
			}
			case 'form': {
				return $this->form_element($this_data, $attributes, $options);
			}
			case 'map': {
				return $this->map_element( $this_data, $attributes );
			}
			case 'svg':
			case 'svg-icon':
			{
				return $this->svg_and_icon_element($this_data, $attributes, $options);
			}
			case 'textarea': {
				return '<textarea ' . $attributes . '></textarea>';
			}
			case 'select': {
				return $this->select_element($this_data, $attributes, $options);
			}
			case 'video': {
				return $this->video_element( $this_data, $attributes, $options );
			}
			case 'radio-group': {
				return $this->radio_group( $this_data, $attributes );
			}
			case 'checkbox-element': {
				return $this->checkbox_element( $this_data, $attributes, $options );
			}
			case 'radio-button': {
				return '<input type="radio" ' . $attributes . ' />';
			}
			case 'image': {
				return $this->image_element( $this_data, $attributes, $options );
			}
			case 'nav_menu': {
				return $this->nav_menu_element( $this_data, $attributes );
			}
			case 'link-block': {
					return $this->link_block_element( $this_data, $attributes, $options );
			}

			case 'file-upload-inner': {
					return $this->file_input_element($this_data, $attributes, $options);
			}

			case 'file-upload-threshold-text': {
					return $this->file_upload_threshold_text($this_data, $attributes, $options);
			}

			case 'file-upload': {
					return $this->file_upload_element($this_data, $attributes, $options);
			}

			case 'collection': {
				$properties = $this_data['properties'];
				$dynamic_content = $properties['dynamicContent'];

				$children = array();

				if (empty($dynamic_content['collectionType'])) {
					$dynamic_content['collectionType'] = 'posts'; // default value
				}

				switch($dynamic_content['collectionType']) {
					case 'posts': {
						$children = $this->construct_posts_collection_markup($properties, $this_data, $options);
						break;
					}

					case 'comments': {
						$children = $this->construct_comments_collection_markup($properties, $this_data, $options);
						break;
					}

					case 'terms': {
						$children = $this->construct_terms_collection_markup($properties, $this_data, $options);
						break;
					}
					
					case 'menus': {
						$children = $this->construct_menus_collection_markup($properties, $this_data, $options);
						break;
					}
					case 'users': {
						$children = $this->construct_users_collection_markup($properties, $this_data, $options);
						break;
					}
					
					default: {
						break;
					}
				}
				return $this->construct_collection_markup( $children, $this_data, $attributes );
			}

			case 'collection-wrapper': {
				$tag                = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$collection         = isset( $options['collection'] ) ? $options['collection'] : array();
				$collection_item_id = $this_data['children'][0];

				$children = array();

				foreach ( $collection as $key => $collection_item ) {
						$options =  	array( 
									'post' => $collection_item, 
									'componentType' => 'collection',
						);
						$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $collection_item_id, $options, ($key === 0) );
				};

				return $this->get_template(
					'collection-wrapper',
					array(
						'attributes' => $attributes,
						'children'   => $children,
						'tag'        => $tag,
					)
				);
			}

			case 'comments': {
				$tag                = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$comments         = isset( $options['comments'] ) ? $options['comments'] : array();
				$comment_item_id = $this_data['children'][0];

				$children = array();

				foreach ( $comments as $key => $comment_item ) {
						$options = array_merge(
							$options,
							array(
								'comment' => $comment_item,
								'componentType' => 'comments',
								'commentItemId' => $comment_item_id,
							)
						);
						$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $comment_item_id, $options,  ($key === 0) );
				};

				return $this->get_template(
					'comments',
					array(
						'attributes' => $attributes,
						'children'   => $children,
						'tag'        => $tag,
					)
				);
			}

			case 'comment-item': {
				$tag                = isset($this_data['properties']['tag']) ? $this_data['properties']['tag'] : 'div';

				$comment_id = $options['comment']->comment_ID;

				$children = $this_data['children'] ?? array();
				$markup = '';

				foreach ($children as $child) {
					$markup .= $this->recGenHTML($child, $options);
				}

				return <<<EOF
					<$tag $attributes data-comment_id="$comment_id">
						$markup
					</$tag>
				EOF;
			}

			case 'terms': {
				$tag                = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$terms         = isset( $options['terms'] ) ? $options['terms'] : array();
				$term_item_id = $this_data['children'][0];

				$additional_options = array(
					'componentType' => 'term',
				);

				if (isset($options['related'])) {
					$additional_options['related'] = $options['related'];
				}

				$children = array();

				foreach ( $terms as $key => $term_item ) {
						$options = array_merge(
							$options,
							$additional_options, 
							array(
								'term' => $term_item,
							)
						);

						$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $term_item_id, $options, ($key === 0) );
				};


				return $this->get_template(
					'terms',
					array(
						'attributes' => $attributes,
						'children'   => $children,
						'tag'        => $tag,
					)
				);
			}
			case 'menus': {
				$tag                = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'ul';
				$menus         = isset( $options['menus'] ) ? $options['menus'] : array();
				$menu_item_id = $this_data['children'][0];

				$additional_options = array(
					'componentType' => 'menu',
				);

				$children = array();
				
				foreach ( $menus as $key => $menu ) {
						$options = array_merge(
							$options,
							$additional_options, 
							array(
								'menu' => $menu,
							)
						);
						$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $menu_item_id, $options, ($key === 0) );
				};

				return $this->get_template(
					'terms',
					array(
						'attributes' => $attributes,
						'children'   => $children,
						'tag'        => $tag,
					)
				);
			}

			case 'users': {
				$tag           = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$users         = isset( $options['users'] ) ? $options['users'] : array();
				$user_item_id = $this_data['children'][0];
				
				$children = array();

				foreach ( $users as $user_item ) {
						$options =  	array( 
								'user' => $user_item, 
								'componentType' => 'user',
						);
						$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $user_item_id, $options );
				};

				return $this->get_template(
					'users',
					array(
						'attributes' => $attributes,
						'children'   => $children,
						'tag'        => $tag,
					)
				);
			}

			case 'pagination': {
				$tag             = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$markup          = '';
				$show_pagination = isset( $options['pagination'] ) ? $options['pagination'] : true;

				if ( $show_pagination) {
					$collection_count   = 0;

					if (isset($options['collectionType'])) {
						if ($options['collectionType'] === 'post' && isset($options['collection_count'])) {
							$collection_count = $options['collection_count'];
						} else if ($options['collectionType'] === 'comment' && isset($options['comment_count'])) {
							$collection_count = $options['comment_count'];
						}else if($options['collectionType'] === 'user' && isset($options['user_count'])){
							$collection_count = $options['user_count'];
						}
					}

					$current_page       = isset( $options['page_no'] ) ? $options['page_no'] : 1;
					$items_per_page     = isset( $options['items_per_page'] ) ? $options['items_per_page'] : 3;
					$total_pages        = (int) ceil( $collection_count / $items_per_page );
					$pagination_item_id = $this_data['children'][0];

					$children = array();

					if($total_pages > 1) {
						for ( $i = 1; $i <= $total_pages; $i++ ) {
							$options = array(
									'page_number'  => $i,
									'current_page' => $current_page === $i,
							);
							$children[] = HelperFunctions::rec_update_data_id_then_return_new_html( $this->data, $this->style_blocks, $pagination_item_id, $options,  ($i === 1) );
						}
					}

					$markup = $this->get_template(
						'pagination',
						array(
							'attributes' => $attributes,
							'children'   => $children,
							'tag'        => $tag,
						)
					);
				}

				return $markup;
			}

			case 'pagination-item': {
				$tag          = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
				$current_page = isset( $options['current_page'] ) ? $options['current_page'] : false;
				$page_number  = isset( $options['page_number'] ) ? $options['page_number'] : false;

				$children = array();

				foreach ( $this_data['children'] as $child ) {
						$children[] = $this->recGenHTML(
							$child,
							array(
								'page_number' => $page_number,
							)
						);
				}

				return $this->get_template(
					'pagination-item',
					array(
						'attributes'   => $attributes,
						'children'     => $children,
						'current_page' => $current_page,
						'page_number'  => $page_number,
						'tag'          => $tag,
					)
				);
			}

			case 'pagination-number': {
				$tag         = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'span';
				$page_number = isset( $options['page_number'] ) ? $options['page_number'] : 1;

				return $this->get_template(
					'pagination-number',
					array(
						'attributes'  => $attributes,
						'page_number' => $page_number,
						'tag'         => $tag,
					)
				);
			}

			case 'symbol': {
				return $this->generate_symbol_html( $this_data, $attributes );
			}
			case 'popup-body': {
				return $this->popup_element( $this_data, $attributes, $options );
			}

			case 'button': {
				return $this->button_element( $this_data, $attributes, $options );
			}
		}
	}

	private function form_element($this_data, $attributes, $options){
		$properties = $this_data['properties'];
		$post_id   = HelperFunctions::get_post_id_if_possible_from_url();
		$form_id   = $this_data['id'];
		$post_data = $form_id . '|' . $post_id;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		$form_id_base64       = base64_encode( base64_encode( $post_data ) );

		$form_nonce_field     = wp_nonce_field( 'wp_rest', '_wpnonce', true, false );

		$options = array_merge(
			$options,
			array(
				'form' => array(
					'id' => $form_id
				)
			)
		);
		
		$form_children_markup = $this->construct_children_markup( isset( $this_data['children'] ) ? $this_data['children'] : array(), $options );

		if (isset($properties['form']['type']) && $properties['form']['type'] !== 'external') {
			$attributes = $this->getAllAttributes(
				$this_data,
				array(
					'action' => false,
					'method' => false,
					'rest' => true,
				),
			);
		}

		return <<<EOF
			<form $attributes>
				<input type="hidden" name="_droip_form" value="$form_id_base64" />
				$form_nonce_field
				$form_children_markup
			</form>
		EOF;
	}
	
	private function select_element($this_data, $attributes, $options){
		$properties = $this_data['properties'];
		$select_options = isset( $properties['options']['list'] ) ? $properties['options']['list'] : array();
				$selected       = isset( $properties['options']['selectedOption'] ) ? $properties['options']['selectedOption'] : '';
				$html           = '<select ' . $attributes . '>';
				foreach ( $select_options as $option ) {
					$html .= "<option value='";
					$html .= $option['value'] . "'";
					$html .= $selected === $option['value'] ? ' selected' : '';
					$html .= '>';
					$html .= $option['contents'];
					$html .= '</option>';
				}
				$html .= '</select>';

				return $html;
	}
	private function checkbox_element($this_data, $attributes, $options){
		if (
			isset($options['term'], $options['term']['term_id'], $options['term']['taxonomy'], $options['related']) &&
			'term' === $options['componentType'] &&
			$options['related']
		) {
			$taxonomy = $options['term']['taxonomy'];
			$term_id = $options['term']['term_id'];

			$checked_ids = isset($options['selected_taxonomies']) ? $options['selected_taxonomies'] : array();
			$checked = in_array((string) $term_id, $checked_ids, true);

			if ($checked) {
				$attributes = "checked " . $attributes;
			}

			$attributes = "name='$taxonomy' value='$term_id' " . $attributes;
		}

		return '<input type="checkbox" ' . $attributes . ' />';
	}
	private function link_block_element($this_data, $attributes, $options){
		$href = $this->get_href_value($this_data, $options);

		if ($href) {
			$attributes = preg_replace('/href="([^"]+")/i', '', $attributes);
		}

		return '<a ' . $attributes . ' href="' . $href . '" >' . $this->construct_children_markup( isset( $this_data['children'] ) ? $this_data['children'] : array(), $options ) . '</a>';
	}
	
	private function button_element($this_data, $attributes, $options){
		$href = $this->get_href_value($this_data, $options);

		if ( $href ) {
			$attributes = preg_replace( '/href="([^"]+")/i', '', $attributes );
		}

		$children_markup = $this->construct_children_markup( isset( $this_data['children'] ) ? $this_data['children'] : array(), $options );
		$tag = isset( $this_data['properties'], $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'a';
		if($href){
			$tag = 'a';
		}

		return <<<EOF
			<$tag $attributes href="$href">
				$children_markup
			</$tag>
		EOF;
	}
	
	private function svg_and_icon_element($this_data, $attributes, $options){
		$properties = $this_data['properties'];
		$svg = isset($properties['svgOuterHtml']) ? $properties['svgOuterHtml'] : '';
		return str_replace('<svg', "<svg $attributes", $svg);
	}

	/**
	 * Construct children markup
	 *
	 * @param array $children single element all childrens.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */
	private function construct_children_markup( $children, $options ) {
		$markup = '';
		if ( isset( $children ) && is_array( $children ) ) {
			foreach ( $children as $child ) {
				$markup .= $this->recGenHTML( $child, $options );
			}
		}
		return $markup;
	}

	private function construct_posts_collection_markup($properties, $this_data, $options) {
		$dynamic_content = $properties['dynamicContent'];
		$args            = array();

		if ( isset( $dynamic_content['sorting'], $dynamic_content['sorting']['type'], $dynamic_content['sorting']['value'] ) ) {
			$args['sorting']['order']   = $dynamic_content['sorting']['type'];
			$args['sorting']['orderby'] = $dynamic_content['sorting']['value'];
		}

		if (isset($options['filters'])) {
			$args['filters'] = $options['filters'];
		} else if ( isset( $dynamic_content['filters'] ) ) {
			$args['filters'] = $dynamic_content['filters'];
		}

		if (isset($dynamic_content['collectionRandomId'])) {

			if (isset($_GET['taxonomy']) && is_array($_GET['taxonomy'])) {
				$filters = array();
				foreach ($_GET['taxonomy'] as $name => $value) {
					if (!empty($value)) {
						$filters[] = array(
							'id'       => 'taxonomy',
							'type' 		 => 'taxonomy',
							'taxonomy' => $name,
							'terms' 	 => $value,
						);
					}
				}

				$args['filters'] = array_merge($args['filters'], $filters);
			}
		}

		if ( isset( $dynamic_content['type'] ) ) {
			$args['name'] = $dynamic_content['type'];
		}
		
		if ( isset( $dynamic_content['inherit'] ) && $dynamic_content['inherit'] === true ) {
			$args['inherit'] = true;
			$args['post_parent'] = $options['post']->ID ?? HelperFunctions::get_post_id_if_possible_from_url();
			
			if(isset($options['user'])){
				//update $filter data with this user author in property

				$args['context'] = array(
					'id' => $options['user']['ID'],
					'collectionType' => 'user',
				);
			}
		} 
		
		if ( isset( $dynamic_content['related'] ) && $dynamic_content['related'] === true ) {
			$args['related'] = true;
			$args['related_post_parent'] = $options['post']->ID ?? HelperFunctions::get_post_id_if_possible_from_url();
		}

		if (false !== strpos($dynamic_content['type'], DROIP_CONTENT_MANAGER_PREFIX)) {
			$parent_id = str_replace(DROIP_CONTENT_MANAGER_PREFIX . '_', '', $dynamic_content['type']);
			$args['post_parent'] = $parent_id;
		}
		

		$item_per_page  = isset( $this_data['properties']['dynamicContent']['items'] ) ? $this_data['properties']['dynamicContent']['items'] : 3;
		$show_pagination = isset( $this_data['properties']['dynamicContent']['pagination'] ) ? $this_data['properties']['dynamicContent']['pagination'] : true;

		$current_page   =  1;
		if (isset($options['page'])) {
			$current_page = $options['page'];
		}

		$args['current_page'] = $current_page;
		$args['item_per_page'] = $item_per_page;

		// if options has query value
		if(isset($options['q'])){
			$args['q'] = $options['q'] ;
		}

		$collection = HelperFunctions::get_posts( $args );
		$data = $collection['data'];
		$pagination = $collection['pagination'];

		$children = array();

		foreach ( $this_data['children'] as $child ) {
			$children[] = $this->recGenHTML(
				$child,
				array(
					'collection'       => $data,
					'collection_count' => $pagination['total_count'],
					'items_per_page'   => $pagination['per_page'],
					'page_no'          => $pagination['current_page'],
					'pagination'       => $show_pagination,
					'collectionType'	=> 'post'
				)
			);
		}

		return $children;
	}

	/***
	 * Construct users  collection markup
	 */

	private function construct_users_collection_markup($properties, $this_data, $options) {
		$dynamic_content = $properties['dynamicContent'];
		$args            = array();

		if ( isset( $dynamic_content['sorting'], $dynamic_content['sorting']['type'], $dynamic_content['sorting']['value'] ) ) {
			$args['sorting']['order']   = $dynamic_content['sorting']['type'];
			$args['sorting']['orderby'] = $dynamic_content['sorting']['value'];
		}

		if (isset($options['filters'])) {
			$args['filters'] = $options['filters'];
		} else if ( isset( $dynamic_content['filters'] ) ) {
			$args['filters'] = $dynamic_content['filters'];
		}
		
		if ( isset( $dynamic_content['inherit'] ) && $dynamic_content['inherit'] === true ) {
			$args['inherit'] = true;
			$args['post_parent'] = $options['post']->ID ?? HelperFunctions::get_post_id_if_possible_from_url();
		} 

		$item_per_page  = isset( $this_data['properties']['dynamicContent']['items'] ) ? $this_data['properties']['dynamicContent']['items'] : 3;
		$show_pagination = isset( $this_data['properties']['dynamicContent']['pagination'] ) ? $this_data['properties']['dynamicContent']['pagination'] : true;
		
		$current_page = 1;
		if (isset($options['page'])) {
			$current_page = $options['page'];
		}

		$args['current_page'] = $current_page;
		$args['item_per_page'] = $item_per_page;

		if(isset($options['q'])){
			$args['q'] = $options['q'];
		}

		$users = Users::get_users($args);
		$data = $users['data'];
		$pagination = $users['pagination'];
		
		$children = array();

		foreach ( $this_data['children'] as $child ) {
			$children[] = $this->recGenHTML(
				$child,
				array_merge(
					$options,
					array(
						'users'       => $data,
						'user_count' => $pagination['total_count'],
						'items_per_page'   => $pagination['per_page'],
						'page_no'          => $pagination['current_page'],
						'pagination'       => $show_pagination,
						'collectionType'	=> 'user'
					)
				)
			);
		}
		return $children;
	}

	private function construct_comments_collection_markup($properties, $this_data, $options) {
		$dynamic_content = $properties['dynamicContent'];
		$args            = array();

		if (isset($dynamic_content['commentType'])) {
			$args['type'] = $dynamic_content['commentType'];
		}

		$args['post_id'] = isset($options['post']) ? $options['post']->ID : HelperFunctions::get_post_id_if_possible_from_url();

		if (isset($options['comment'])) {
			$args['parent'] = $options['comment']->comment_ID;
		}

		if (isset($dynamic_content['filters'])) {
			$args['filters'] = $dynamic_content['filters'];
		}

		if (isset(
			$dynamic_content['sorting'],
			$dynamic_content['sorting']['type'],
			$dynamic_content['sorting']['value']
		)) {
			$args['sorting']['order']   = $dynamic_content['sorting']['type'];
			$args['sorting']['orderby'] = $dynamic_content['sorting']['value'];
		}

		$item_per_page  = isset( $this_data['properties']['dynamicContent']['items'] ) ? $this_data['properties']['dynamicContent']['items'] : 3;
		$show_pagination = isset( $this_data['properties']['dynamicContent']['pagination'] ) ? $this_data['properties']['dynamicContent']['pagination'] : true;
		
		$current_page   = 1;
		if (isset($options['page'])) {
			$current_page = $options['page'];
		}

		$args['current_page'] = $current_page;
		$args['item_per_page'] = $item_per_page;

		$comments = HelperFunctions::get_comments( $args );

		$data = $comments['data'];
		$pagination = $comments['pagination'];

		$children = array();

		foreach ( $this_data['children'] as $child ) {
			$children[] = $this->recGenHTML(
				$child,
				array_merge(
					$options,
					array(
						'comments'       => $data,
						'comment_count' => $pagination['total_count'],
						'items_per_page'   => $pagination['per_page'],
						'page_no'          => $pagination['current_page'],
						'pagination'       => $show_pagination,
						'collectionType'	=> 'comment'
					)
				)
			);
		}

		return $children;
	}

	/**
	 * Construct taxonomy markup
	 *
	 * @param array $taxonomy_list single element collection data.
	 * @param array $this_data single element.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function construct_terms_collection_markup($properties, $this_data, $options) {
		$dynamic_content = $properties['dynamicContent'];

		if(empty($dynamic_content['taxonomy'])) {
			return array();
		}

		$terms_arr = array();

		if (isset($dynamic_content['inherit']) && $dynamic_content['inherit']) {
			$post_id = 0;

			if (isset($options['componentType']) && $options['componentType'] === 'collection') {
				$post_id = $options['post']->ID;
			} else {
				$post_id = HelperFunctions::get_post_id_if_possible_from_url();
			}

			$terms_arr = get_the_terms( $post_id, $dynamic_content['taxonomy'] );
			
			if(is_array($terms_arr)) {
				foreach($terms_arr as $key => &$item) {
					$item = $item->to_array();
				}
			} else {
				$terms_arr = array();
			}

		} else {
			$terms_arr = get_terms( array(
				'taxonomy'   => $dynamic_content['taxonomy'],
				'hide_empty' => false,
			));

			if(!is_wp_error($terms_arr)){

				foreach($terms_arr as &$item) {
					$item = $item->to_array();
				}
			}
		}

		$children = array();

		$additional_options = array(
			'terms'       => $terms_arr,
		);

		if (
			isset($dynamic_content['related'], $dynamic_content['relatedCollection']) &&
			$dynamic_content['related'] &&
			$dynamic_content['relatedCollection']
		) {
			if ( isset($_GET['taxonomy'][$dynamic_content['taxonomy']]) && is_array($_GET['taxonomy'][$dynamic_content['taxonomy']]) ) {
				$additional_options['selected_taxonomies'] = $_GET['taxonomy'][$dynamic_content['taxonomy']];
			}
			
			$additional_options['related'] = $dynamic_content['relatedCollection'];
		}

		foreach ( $this_data['children'] as $child ) {
			$children[] = $this->recGenHTML(
				$child,
				array_merge(
					$options,
					$additional_options
				)
			);
		}

		return $children;
	}
	
	
	private function construct_menus_collection_markup($properties, $this_data, $options) {
		$dynamic_content = $properties['dynamicContent'];

		if(empty($dynamic_content['menu'])) {
			return array();
		}
		
		$inherit = isset($dynamic_content['inherit']) ? $dynamic_content['inherit'] : false;
		$children = array();

		if($inherit){
			$menus = $options['menu']->submenus;
		}else{
			$menus = WordpressData::get_wordpress_single_menu_data($dynamic_content['menu'], true);

			if($menus && isset($menus->submenus)){
				$menus = $menus->submenus;
			}else{
				$menus = array();
			}
		}
		
		$additional_options = array(
			'menus'       => $menus,
			'inherit' => $inherit
		);

		//TODO: inherited from submenu.

		foreach ( $this_data['children'] as $child ) {
			$children[] = $this->recGenHTML(
				$child,
				array_merge(
					$options,
					$additional_options
				)
			);
		}

		return $children;
	}

	/**
	 * Construct collection markup
	 *
	 * @param array $collection single element collection data.
	 * @param array $this_data single element.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function construct_collection_markup( $children, $this_data, $attributes ) {
		$tag             = isset( $this_data['properties']['tag'] ) ? $this_data['properties']['tag'] : 'div';
		
		$data_n_styles = array(
			'blocks' => array(),
			'styles' => array(),
		);

		DataHelper::get_data_n_styles_from_root($this_data['id'],  $data_n_styles, $this->data, $this->style_blocks);

		if (isset($this_data['properties']['dynamicContent']['collectionRandomId'])) {
			$attributes .= ' droip_collection_random_id="' . $this_data['properties']['dynamicContent']['collectionRandomId'] . '"';
		}

		if ( is_array( $children ) ) {
			return $this->get_template(
				'collection',
				array(
					'data' => $data_n_styles,
					'attributes' => $attributes,
					'children'   => $children,
					'tag'        => $tag,
				)
			);
		} else {
			return '';
		}
	}


	/**
	 * Generate custom code markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function custom_code( $this_data, $attributes ) {
		$properties = $this_data['properties'];
		if ( isset( $properties['content'] ) ) {
			if ( isset( $properties['data-type'] ) && $properties['data-type'] === 'url' ) {
				return '<div ' . $attributes . '>
                  <iframe
                    src="' . $properties['content'] . '"
                    title="' . $this_data['id'] . '"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    style="width:100%;height:100%;"
                  ></iframe>
                </div>';
			} else {
				return '<div ' . $attributes . '>' . $properties['content'] . '</div>';
			}
		}
		return '';
	}

	/**
	 * Generate Map element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function map_element( $this_data, $attributes ) {
		$properties = isset( $this_data['properties']['map'] ) ? $this_data['properties']['map'] : false;
		if ( ! $properties ) {
			return '';
		}
		return '<div ' . $attributes . '></div>';
	}

	/**
	 * Generate Video element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function video_element( $this_data, $attributes, $options ) {
		$properties       = $this_data['properties'];
		$name             = $properties['attributes']['name'];
		$src              = $properties['attributes']['src'];
		$type             = $properties['attributes']['type'];
		$controls         = $properties['attributes']['controls'];
		$play_inline      = isset( $properties['attributes']['playInline'] ) ? $properties['attributes']['playInline'] : true;
		$duration         = isset( $properties['attributes']['duration'] ) ? $properties['attributes']['duration'] : 0;
		$start_time       = $properties['attributes']['startTime'];
		$end_time         = isset( $properties['attributes']['endTime'] ) ? $properties['attributes']['endTime'] : $duration;
		$span_attr_string = $this->getAllAttributes(
			$this_data,
			array(
				'class'      => true,
				'data-droip' => true,
				'rest'       => false,
			),
		);
		$dynamic_content = isset( $properties['dynamicContent'] ) ? $properties['dynamicContent'] : false;

		if ( isset( $this_data['properties']['attributes']['muted'] ) && $this_data['properties']['attributes']['muted'] === false ) {
			unset( $this_data['properties']['attributes']['muted'] );
		}

		$video_attr_string = $this->getAllAttributes(
			$this_data,
			array(
				'class'                 => false,
				'data-droip'            => false,
				'src'                   => false,
				'autoPlay'              => false,
				'controls'              => false,
				'dataVideoPlayListener' => false,
				'rest'                  => true,
			),
		);

		if ( $play_inline ) {
			$video_attr_string .= ' playsinline';
		}

		$poster = '';
		if ( isset( $properties['thumbnail'], $properties['thumbnail']['status'] ) && $properties['thumbnail']['status'] ) {
			$poster = isset( $properties['thumbnail'], $properties['thumbnail']['url'] ) ? $properties['thumbnail']['url'] : null;
		}

		$video_src = '';
		if ($dynamic_content) {
			if (isset($options['componentType'])) {
				if ($options['componentType'] === 'collection') {
					if ($options['post']->{$dynamic_content['value']}) {
						$video_obj = $options['post']->{$dynamic_content['value']};

						if (isset($video_obj['url'])) {
							$video_src = $video_obj['url'];
						}
					} else {
						$video_obj = HelperFunctions::get_post_dynamic_content( $dynamic_content['value'], isset( $options['post'] ) ? $options['post'] : null );

						if (isset($video_obj['url'])) {
							$video_src = $video_obj['url'];
						}
					}
				}
			} else {
				$video_obj = HelperFunctions::get_post_dynamic_content( $dynamic_content['value'], isset( $options['post'] ) ? $options['post'] : null );

				if (isset($video_obj['url'])) {
					$video_src = $video_obj['url'];
				}
			}
		}

		//if no dynamic video src then check original source for fallback video url
		if(!$video_src && !$src){
			return '';
		}else{
			$src = $video_src ? $video_src: $src;
		}

		$video_url_type = $this->video_type( $src );

		if ( $video_url_type === 'youtube' ) {
			$video_src = $this->get_youtube_embed_url( $src ) . '?controls=' . $controls . '&amp;start=' . $start_time . '&end=' . $end_time;
		} else {
			$video_src = $src . '#t=' . $start_time . ',' . $duration;
		}

		$html = '<span ' . $span_attr_string . '>';
		if ( $video_url_type === 'youtube' || $video_url_type === 'vimeo' || $video_url_type === 'tiktok' ) {
			$html .= '<iframe height="100%" width="100%" title="' . $name . '" src="' . $video_src . '" ></iframe>';
		} else {
			if ( isset( $properties['attributes']['lazy'] ) && $properties['attributes']['lazy'] ) {
				// `data-src` is used in `source` tag to lazy load the video using JS. Check JS preview script for videos.
				$html .= '<video' . $video_attr_string . ' poster="' . $poster . '">
				<source data-src="' . $video_src . '" type="' . $type . '"></source></video>';
			} else {
				$html .= '<video' . $video_attr_string . ' poster="' . $poster . '">
				<source src="' . $video_src . '" type="' . $type . '"></source></video>';
			}
		}
		$html .= '</span>';
		return $html;
	}

	/**
	 * Generate Video element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function radio_group( $this_data, $attributes ) {
		$properties = $this_data['properties'];
		$data       = $properties['data']['child'];
		$name       = $properties['attributes']['name'];

		$str = '<div ' . $attributes . '>';

		foreach ( $data as $key => $child ) {
			$attrs  = "type='radio' name='{$name}' value='{$child['value']}'";
			$attrs .= $child['checked'] ? ' checked' : '';

			$str .= '<label>
                  <input ' . $attrs . '/>
                  <span>' . $child['content'] . '</span>
                </label>';
		}
		$str .= '</div>';
		return $str;
	}

	/**
	 * Generate Nav menu element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function nav_menu_element( $this_data, $attributes ) {
		$menu_id = $this_data['properties']['dynamicContent']['value'];
		$menu    = WordpressData::get_wordpress_single_menu_data( $menu_id, true );
		if ( ! $menu ) {
			return '';
		}
		return $this->rec_gen_menu_items( $menu->submenus, 0 );
	}
	
	/**
	 * Generate popup-body element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function popup_element( $this_data, $attributes, $options ) {
		$children_markup = $this->construct_children_markup( isset( $this_data['children'] ) ? $this_data['children'] : array(), $options );
		return '<div class="droip-popup-body-wrapper"><div '.$attributes.'>' . $children_markup . '</div></div>';
	}

	/**
	 * Recursively Generate menu items element markup
	 *
	 * @param array $submenus all submenus.
	 * @param int   $depth menu nesting info.
	 * @return string HTML markup.
	 */
	private function rec_gen_menu_items( $submenus, $depth ) {
		if ( count( $submenus ) === 0 ) {
			return '';
		}
		if ( $depth === 0 ) {
			$str = '<ul class="' . DROIP_CLASS_PREFIX . '-nav-menu">';
		} else {
			$str = '<ul class="' . DROIP_CLASS_PREFIX . '-element-submenu">';
		}
		$depth++;
		foreach ( $submenus as $key => $menu ) {
			$str .= '<li class="' . DROIP_CLASS_PREFIX . '-element-nav-item"><a class="' . DROIP_CLASS_PREFIX . '-link-element" href="' . $menu->url . '" target="' . $menu->target . '">' . $menu->title . '</a>' . $this->rec_gen_menu_items( $menu->submenus, $depth ) . '</li>';
		}
		$str .= '</ul>';
		return $str;
	}

	/**
	 * This method will add css value and unit
	 *
	 * @param array $value css value and unit pair.
	 * @return string 5px | auto.
	 */
	private function add_unit( $value ) {
		if ( isset( $value['unit'] ) && $value['unit'] !== 'auto' ) {
			return $value['value'] . $value['unit'];
		}
		return 'auto';
	}

	/**
	 * Generate Image element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */
	private function image_element( $this_data, $attributes, $options ) {
		$properties      = $this_data['properties'];
		$svg_outer_html  = isset( $properties['svgOuterHtml'] ) ? $properties['svgOuterHtml'] : false;
		$dynamic_content = isset( $properties['dynamicContent'] ) ? $properties['dynamicContent'] : false;
		
		$src = '';

		if ($dynamic_content) {
			$image_data = array();

			if (isset($options['componentType'])) {
				if ($options['componentType'] === 'collection') {
					if ($options['post']->{$dynamic_content['value']}) {
						$image_data = $options['post']->{$dynamic_content['value']};
					} else {
						$image_data = HelperFunctions::get_post_dynamic_content( $dynamic_content['value'], isset( $options['post'] ) ? $options['post'] : null );
					}
				} else if ($options['componentType'] === 'comments') {
					if ($options['comment']->{$dynamic_content['value']}) {
						$image_data = $options['comment']->{$dynamic_content['value']};
					}
				}else if ($options['componentType'] === 'user') {
					if ($options['user'][$dynamic_content['value']]) {
						$image_data = array(
							'src' => $options['user'][$dynamic_content['value']]
						);
					}
				}

			} else {
				$post = isset( $options['post'] ) ? $options['post'] : get_post(HelperFunctions::get_post_id_if_possible_from_url());
				$image_data = HelperFunctions::get_post_dynamic_content( $dynamic_content['value'], $post, isset($dynamic_content['meta'])?$dynamic_content['meta']:null );
				if(is_string($image_data)) {
					$image_data = array(
						'src' => $image_data
					);
				}

				if(isset($options['user'], $options['user'][$dynamic_content['value']])){
					$image_data = array(
						'src' => $options['user'][$dynamic_content['value']]
					);
				}
			}

			if (isset($image_data['src'])) {
				$src = $image_data['src'];
			}

			if (isset($image_data['wp_attachment_id'])) {
				$properties['wp_attachment_id'] = $image_data['wp_attachment_id'];
			}
		}

		if ( $dynamic_content && $src) {
			// replace src and alt.
			$attributes = preg_replace( array( '/src="([^"]+")/i', '/alt="([^"]+")/i' ), array( '', 'alt=""' ), $attributes );
		} else {
			$src = isset( $properties['attributes']['src'] ) ? $properties['attributes']['src'] : '';
		}

		$srcset = null;
		if ( isset( $properties['wp_attachment_id'] ) && $properties['wp_attachment_id'] ) {
			$srcset      = wp_get_attachment_image_srcset( $properties['wp_attachment_id'] );
			$attributes .= $srcset ? ' srcset="' . $srcset . '"' : '';

			$sizes       = '';
			$a_meta_data = wp_get_attachment_metadata( $properties['wp_attachment_id'] );
			if ( $a_meta_data && isset($a_meta_data['width']) ) {
				$width       = $a_meta_data['width'];
				$sizes       = '(max-width: ' . $width . 'px) 100vw, ' . $width . 'px';
				$attributes .= $sizes ? ' sizes="' . $sizes . '"' : '';
			}
		}

		if ( ( isset( $properties['load'] ) && $properties['load'] !== 'auto' ) || ! isset( $properties['load'] ) ) {
			$attributes .= isset( $properties['load'] ) ? ' loading="' . $properties['load'] . '"' : ' loading="lazy"';
		}

		if ( isset( $properties['width'] ) ) {
			$attributes .= ' width="' . $this->add_unit( $properties['width'] ) . '"';

		}
		if ( isset( $properties['height'] ) ) {
			$attributes .= ' height="' . $this->add_unit( $properties['height'] ) . '"';
		}

		if(!$src)return '';

		$str = '';

		if($svg_outer_html){
			$str .= '<img ' . $attributes . ' src="' . $src . '"/>
               <span>' . $svg_outer_html . '</span>';
		}else{
			$str .= '<img ' . $attributes . ' src="' . $src . '"/>';
		}

		return $str;
	}

	/**
	 * Get video type from url
	 *
	 * @param string $url single element block.
	 * @return string|bool video url type.
	 */
	private function video_type( $url ) {
		if ( strpos( $url, 'youtube' ) > 0 ) {
			return 'youtube';
		} elseif ( strpos( $url, 'vimeo' ) > 0 ) {
			return 'vimeo';
		} elseif ( strpos( $url, 'tiktok' ) > 0 ) {
			return 'tiktok';
		} else {
			return false;
		}
	}

	/**
	 * Get video type from url
	 *
	 * @param string $url single element block.
	 * @return string youtube url type.
	 */
	private function get_youtube_embed_url( $url ) {
		preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match );
		return 'https://www.youtube.com/embed/' . $match[1];
	}

	/**
	 * Generate symbol markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @return string HTML markup.
	 */
	private function generate_symbol_html( $this_data, $attributes ) {
		$properties = $this_data['properties'];
		$symbol_id  = $properties['symbolId'];
		$symbol     = Symbol::get_single_symbol( $symbol_id, true );

		if ( ! $symbol ) {
			return '';
		}

		$symbol_data = $symbol['symbolData'];
		if (!$symbol_data) {
			return '';
		}
		$s = HelperFunctions::rec_update_data_id_then_return_new_html($symbol_data['data'], $symbol_data['styleBlocks'], $symbol_data['root']);
		$fonts_links = '';
		if ( isset( $symbol_data['customFonts'] ) ) {
			foreach ( $symbol_data['customFonts'] as $key => $f ) {
				if ( isset( $f['fontUrl'] ) ) {
					$fonts_links .= $this->getFontsHTMLMarkup( $f );
				}
			}
		}
		return '<div ' . $attributes . '>' . $fonts_links . $s . '</div>';
	}

	/**
	 * Get html template.
	 *
	 * @param string $template template file name.
	 * @param array  $vars if extra variable needs inside template file.
	 * @return string $message
	 */
	private function get_template( $template, $vars ) {
		ob_start();
		include __DIR__ . "/templates/$template.view.php";
		$message = ob_get_contents();
		ob_end_clean();
		return $message;
	}

	/**
	 * Generate File upload element markup
	 *
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */
	private function file_upload_element($this_data, $attributes, $options)
	{
		$tag  = isset($this_data['properties']['tag']) ? $this_data['properties']['tag'] : 'div';
		$data_attr = isset($this_data['properties']['attributes']) ? $this_data['properties']['attributes'] : array();
		$options = array_merge(
			$options,
			array(
				'file_upload' => array(
					'name' => isset($data_attr['name']) ? $data_attr['name'] : '',
					'accept' => isset($data_attr['accept']) ? $data_attr['accept'] : '',
					'required' => isset($data_attr['required']) ? $data_attr['required'] : '',
					'maxFileSize' => isset($this_data['properties']['maxFileSize']) ? $this_data['properties']['maxFileSize'] : 2,
				)
			)
		);

		$attributes = $this->getAllAttributes(
			$this_data,
			array(
				'name' => false,
				'accept' => false,
				'required' => false,
				'rest' => true,
			),
		);

		$children_markup = $this->construct_children_markup( isset( $this_data['children'] ) ? $this_data['children'] : array(), $options );
		return <<<EOF
						<$tag $attributes>
							$children_markup
						</$tag>
				EOF;
	}

	/**
	 * Generate File input threshold text element markup
	 * 
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */

	private function file_upload_threshold_text($this_data, $attributes, $options)
	{
		$tag  = isset($this_data['properties']['tag']) ? $this_data['properties']['tag'] : 'span';
		$max_file_size = isset($options['file_upload']['maxFileSize']) ? $options['file_upload']['maxFileSize'] : 2;

		return "<$tag $attributes>Max file size " . $max_file_size . "MB.</$tag>";
	}

	/**
	 * Generate File input element markup
	 * 
	 * @param array $this_data single element block.
	 * @param array $attributes single element all attributes.
	 * @param array $options single element all options.
	 * @return string HTML markup.
	 */
	private function file_input_element($this_data, $attributes, $options)
	{
		$tag  = isset($this_data['properties']['tag']) ? $this_data['properties']['tag'] : 'div';
		$children = $this_data['children'] ?? array();
		$markup = '';

		$name = isset($options['file_upload']['name']) ? $options['file_upload']['name'] : '';
		$accept = isset($options['file_upload']['accept']) ? $options['file_upload']['accept'] : '';
		$required = isset($options['file_upload']['required']) ? $options['file_upload']['required'] : '';
		$max_file_size = isset($options['file_upload']['maxFileSize']) ? $options['file_upload']['maxFileSize'] : 2;

		foreach ($children as $child) {
			$markup .= $this->recGenHTML($child, $options);
		}

		return <<<EOF
						<$tag $attributes>
							$markup
							<input
								type="file"
								readonly
								style="display: none;"
								name="$name"
								accept="$accept"
								required="$required"
								droip-max_file_size=$max_file_size
								/>
							</$tag>
					EOF;
	}

}