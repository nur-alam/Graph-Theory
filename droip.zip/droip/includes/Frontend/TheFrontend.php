<?php
/**
 * Front end post hooks and content controller
 *
 * @package droip
 */

namespace Droip\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Frontend\Preview\Preview;
use Droip\HelperFunctions;

/**
 * TheFrontend class
 */
class TheFrontend {


	/**
	 * Droip editor data.
	 */
	private $droip_data = false;
	/**
	 * Flag for where from call this instance
	 */
	private $call_from = 'front-end';

	/**
	 * Collect droip type data header, footer, content, popups
	 */
	private $droip_type_html_data = array(
		'header'  => '',
		'content' => '',
		'footer'  => '',
		'popups'  => '',
	);
	/**
	 * Initialize the class
	 *
	 * @param string $call_from where from call this instance.
	 * @return void
	 */
	public function __construct( $call_from = 'front-end' ) {
		if($call_from === 'iframe'){
			remove_all_filters('the_content');
		}
		add_action( 'wp', array( $this, 'collect_all_droip_type_data' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'load_assets' ) );

		add_action( 'wp_head', array( $this, 'add_inside_head_tag' ) );

		add_action( 'get_header', array( $this, 'load_custom_header' ), 1, 1 ); // call if template has get_header method.

		add_filter( 'the_content', array( $this, 'replace_content' ), 9999999 );
		add_action( 'get_footer', array( $this, 'load_custom_footer' ), 1, 1 ); // call if template has get_header method.

		add_action( 'wp_footer', array( $this, 'add_before_body_tag_end' ) );

		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$action = HelperFunctions::sanitize_text( isset( $_GET['action'] ) ? $_GET['action'] : null );
		if ( 'front-end' === $call_from && DROIP_APP_PREFIX === $action ) {
			$call_from = 'editor';
		}

		$this->call_from = $call_from;
	}
	/**
	 * Collect droip related custom sections html string
	 *
	 * @return void
	 */
	public function collect_all_droip_type_data() {
		$this->get_current_post_related_dependency();
		if ( 'iframe' !== $this->call_from ) {
			$this->droip_type_html_data['header'] = HelperFunctions::get_page_custom_section( 'header' );
			$this->droip_type_html_data['footer'] = HelperFunctions::get_page_custom_section( 'footer' );
			$this->droip_type_html_data['popups'] = HelperFunctions::get_page_popups_html();
		}
	}

	/**
	 * Check Droip asset will load or not.
	 *
	 * @return bool
	 */

	private function will_droip_asset_load() {
		$should_load = apply_filters( 'droip_assets_should_load', $this->droip_type_html_data['content'] || $this->droip_type_html_data['header'] || $this->droip_type_html_data['footer'] || $this->droip_type_html_data['popups'] );
		$should_load = $should_load || 'iframe' == $this->call_from;
		if(!$should_load && HelperFunctions::get_template_data_if_current_page_is_droip_template()){
			//check if this is droip template page 
			return true;
		}
		return $should_load;
	}

	/**
	 * Get Post preview related data.
	 * this function is called for enqueueing the icon assets and get only used style blocks
	 * and also get the html string of the preview
	 *
	 * @return void
	 */
	public function get_current_post_related_dependency() {
		$d = HelperFunctions::is_droip_type_data();
		if ( $d ) {
			$this->droip_data                      = $d;
			$this->droip_type_html_data['content'] = HelperFunctions::get_html_using_preview_script( $d['blocks'], $d['styles'], 'root' );
		}
	}

	// get_header => vs enquey. ref: https://developer.wordpress.org/reference/hooks/get_header/.

	/**
	 * Load assets for Editor
	 *
	 * @return void
	 */
	public function load_assets() {
		if ( 'iframe' === $this->call_from || ( $this->will_droip_asset_load() && 'editor' !== $this->call_from) ) {
			$version = DROIP_VERSION;
			wp_enqueue_script(DROIP_APP_PREFIX, DROIP_ASSETS_URL . 'js/droip.min.js', array('wp-i18n'), $version, true);
			wp_enqueue_style( DROIP_APP_PREFIX, DROIP_ASSETS_URL . 'css/droip.min.css', null, $version );
		}
	}

	/**
	 * Add elements style to the header
	 *
	 * @return void
	 */
	public function add_inside_head_tag() {
		$s = Preview::getSeoMetaTags();
		$s .= Preview::getHeadCustomCode();
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $s;
	}

	/**
	 * Load custom header
	 *
	 * @param string $header header text.
	 * @return void
	 */
	public function load_custom_header( $header ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->droip_type_html_data['header'];
	}

	/**
	 * Load custom footer
	 *
	 * @param string $footer footer text.
	 * @return void
	 */
	public function load_custom_footer( $footer ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->droip_type_html_data['footer'];
	}

	/**
	 * Replace the content with our droip data
	 *
	 * @param string $content wp content.
	 *
	 * @return the_contnet
	 */
	public function replace_content( $content ) {
		// $flag = false;
		if ( 'iframe' === $this->call_from ) {
			return '<div id="' . DROIP_CLASS_PREFIX . '-builder"></div>';
		}

		if ( $this->droip_type_html_data['content'] ) {
			$content = $this->droip_type_html_data['content'];
		}

		// Run shortcode manually
		$content = do_shortcode( $content );

		if ( 'migration' === $this->call_from ) {
			return '<div id="' . DROIP_CLASS_PREFIX . '-builder-migration">' . $content . '</div>';
		}
		return $content;
	}

	/**
	 * Add script tag to the footer
	 *
	 * @return void
	 */
	public function add_before_body_tag_end() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$s = $this->droip_type_html_data['popups'];

		if ( $this->will_droip_asset_load() ) {
			$template_data = HelperFunctions::get_template_data_if_current_page_is_droip_template();
			
			$url_arr = HelperFunctions::get_post_url_arr_from_post_id( HelperFunctions::get_post_id_if_possible_from_url() );
			$s      .= HelperFunctions::get_view_port_lists();
			$s      .= '<script id="' . DROIP_APP_PREFIX . '-api-and-nonce"> 
              window.wp_droip = {
                ajaxUrl: "' . $url_arr['ajax_url'] . '",
                restUrl: "' . $url_arr['rest_url'] . '",
                siteUrl: "' . $url_arr['site_url'] . '",
                apiVersion: "v1",
                postId: "' . $url_arr['post_id'] . '",
                nonce: "' . $url_arr['nonce'] . '",
                call_from: "' . $this->call_from . '",
								templateId: "' . ($template_data ? $template_data['template_id'] : false) . '"
              };
            </script>';
			if ( $this->droip_type_html_data['content'] ) {
				$s .= Preview::getBodyCustomCode();
			}
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $s;
	}
}
