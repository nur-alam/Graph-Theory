<?php

/**
 * Template Name: Full-width page layout
 * Template Post Type: page, post
 *
 * @package droip
 */

use Droip\HelperFunctions;

if (!defined('ABSPATH')) {
	exit;
}

$custom_data = get_query_var(DROIP_APP_PREFIX . '_custom_data');
$the_content = false;
$droip_include_wp_header = false;
$droip_include_wp_footer = false;

$template_data = HelperFunctions::get_template_data_if_current_page_is_droip_template();
if ($template_data) {
	$the_content = $template_data['content'];
	$template_id = $template_data['template_id'];

	$template_settings = get_post_meta($template_id, DROIP_PAGE_SEO_SETTINGS_META_KEY, true);
	$droip_include_wp_header = get_post_meta($template_id, 'droip_include_wp_header', true);
	$droip_include_wp_footer = get_post_meta($template_id, 'droip_include_wp_footer', true);
}

if (!$droip_include_wp_header && !$droip_include_wp_footer) {
	$post_id = HelperFunctions::get_post_id_if_possible_from_url();
	$page_settings = get_post_meta($post_id, DROIP_PAGE_SEO_SETTINGS_META_KEY, true);

	$droip_include_wp_header = get_post_meta($post_id, 'droip_include_wp_header', true);
	$droip_include_wp_footer = get_post_meta($post_id, 'droip_include_wp_footer', true);
}

$droip_include_wp_header = $droip_include_wp_header === 'true' ? true : false;
$droip_include_wp_footer = $droip_include_wp_footer === 'true' ? true : false;
?>

<?php if ($droip_include_wp_header) {
	get_header();
} else { ?>
	<!DOCTYPE html>
	<html <?php language_attributes(); ?>>

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title><?php echo esc_html(get_the_title()); ?></title>
		<link rel="icon" href="<?php echo esc_url(get_site_icon_url()); ?>" sizes="32x32">
		<?php wp_head(); ?>
	</head>

	<body class="<?php echo esc_html(DROIP_CLASS_PREFIX); ?>-tool" style="margin:0;">
	<?php } ?>

	<?php
	//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo HelperFunctions::get_page_custom_section('header');
	if ($the_content) {
		echo $the_content;
	} else {
		the_content();
	}
	//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo HelperFunctions::get_page_custom_section('footer');
	?>

	<?php if ($droip_include_wp_footer) {
		get_footer();
	} else {
		wp_footer();
	?>
	</body>
<?php } ?>