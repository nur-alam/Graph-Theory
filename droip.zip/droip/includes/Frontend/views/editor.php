<?php
/**
 * Editor template php file.
 *
 * @package droip
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Droip\HelperFunctions;

$post_url_arr = HelperFunctions::get_post_url_arr_from_post_id( HelperFunctions::get_post_id_if_possible_from_url() );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>
	<?php echo esc_html_e( DROIP_APP_NAME, 'droip' ) . ' | ' . esc_html( get_the_title( HelperFunctions::get_post_id_if_possible_from_url() ) ); ?>
  </title>
  <?php wp_head(); ?>
</head>

<body class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-tool">
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-editor-wrapper">
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-top-bar"></div>
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-left-bar"></div>
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-content-bar">
			<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-editor-bar">
			<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-builder">
				<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-canvas-preview">
				<?php $load_iframe_url = $post_url_arr['iframe_url']; ?>
				<iframe
					class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-iframe-desktop <?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-iframe"
					name="<?php echo esc_html( DROIP_APP_IFRAME_ID ); ?>"
					data-url="<?php echo esc_url( $load_iframe_url ); ?>"
					id="<?php echo esc_html( DROIP_APP_IFRAME_ID ); ?>"></iframe>
				</div>
			</div>
			</div>
		</div>
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-right-bar"></div>
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-footer-bar"></div>
		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-floating-elems">
			<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-alert-dialog-anchor-ele"></div>
		</div>
		</div>

		<div id="droip-builder-dnd-provider-dom"></div>

		<div id="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loadingDiv"
		style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; background-color: #2d2d2d; overflow: hidden; z-index: 9;">
		<div class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loading-wrapper"
			style="width: 190px; height: 48px; border: 1px solid #FFFFFF; border-radius: 45px; display: flex; align-items: center; justify-content: center;">
			<div class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loading"
			style="width: 100%; height: 42px; background: #2D2D2D; border-radius: 29px; margin-left: 2px; margin-right: 2px; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
			<div class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loading-overlay"
				style="width: 2%;position: absolute; left: 0; top: 0; bottom: 0; background-color: #FFFFFF; transition: all 0.3s linear;">
			</div>
			<h1 class="<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loading-title"
				style="font-size: 24px; line-height: 32px; font-weight: 400; letter-spacing: 0.08em; color: #FFFFFF; mix-blend-mode: difference; margin-bottom: 0; font-family: 'Inter', sans-serif; margin-top: 0;">
				LOADING...</h1>
			</div>
		</div>
		<script>
		const loadingOverlay = document.querySelector('.<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loading-overlay');
		const loading = (parentage) => {
			loadingOverlay.style.width = parentage + '%';
		}
		window.loading = loading;
		window.removeLoading = () => {
			setTimeout(() => {
			let loadingDiv = document.getElementById("<?php echo esc_html( DROIP_CLASS_PREFIX ); ?>-loadingDiv");
			loadingDiv?.remove();
			}, 400);
		}

		const loadingInterval = setInterval(() => {
			let parentage = parseInt(loadingOverlay.style.width);
			let random = Math.floor(Math.random() * 2) + 1;

			if (parentage < 95) {
			loading(parentage + random);
			} else {
			clearInterval(loadingInterval);
			}
		}, 50);
		</script>
		</div>



		<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
		<defs>
			<filter id="protanopia">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.567, 0.433, 0,     0, 0
					0.558, 0.442, 0,     0, 0
					0,     0.242, 0.758, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="protanomaly">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.817, 0.183, 0,     0, 0
					0.333, 0.667, 0,     0, 0
					0,     0.125, 0.875, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="deuteranopia">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.625, 0.375, 0,   0, 0
					0.7,   0.3,   0,   0, 0
					0,     0.3,   0.7, 0, 0
					0,     0,     0,   1, 0" />
			</filter>
			<filter id="deuteranomaly">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.8,   0.2,   0,     0, 0
					0.258, 0.742, 0,     0, 0
					0,     0.142, 0.858, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="tritanopia">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.95, 0.05,  0,     0, 0
					0,    0.433, 0.567, 0, 0
					0,    0.475, 0.525, 0, 0
					0,    0,     0,     1, 0" />
			</filter>
			<filter id="tritanomaly">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.967, 0.033, 0,     0, 0
					0,     0.733, 0.267, 0, 0
					0,     0.183, 0.817, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="achromatopsia">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.299, 0.587, 0.114, 0, 0
					0.299, 0.587, 0.114, 0, 0
					0.299, 0.587, 0.114, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="achromatomaly">
			<feColorMatrix in="SourceGraphic" type="matrix" values="0.618, 0.320, 0.062, 0, 0
					0.163, 0.775, 0.062, 0, 0
					0.163, 0.320, 0.516, 0, 0
					0,     0,     0,     1, 0" />
			</filter>
			<filter id="blurred">
			<feGaussianBlur in="SourceGraphic" stdDeviation="1.5" />
			</filter>
		</defs>
		</svg>

		<?php wp_footer(); ?>
</body>

</html>
