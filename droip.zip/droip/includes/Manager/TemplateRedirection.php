<?php
/**
 * Plugin update events handler
 *
 * @package droip
 */

namespace Droip\Manager;

use Droip\HelperFunctions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Do some task on WordPress template redirection
 */
class TemplateRedirection {

	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct() {
		// add_action( 'template_redirect', array( $this, 'droip_template_redirect' ) );
		/* update the the content with our droip data if page is droip */
		add_action( 'template_include', array( $this, 'load_page_template' ) );
	}

	/**
	 * Load droip page template
	 * it will include the template file insted of original template file
	 * $loadForIframe = true if load for iframe
	 *
	 * @param string $original wp action for template file load.
	 * @return string template name.
	 */
	public function load_page_template( $original ) {
		$post_id = HelperFunctions::get_post_id_if_possible_from_url();
		if(!$post_id) return $original;
		$post = get_post( $post_id );
		
		if($post->post_type === DROIP_APP_PREFIX.'_template'){
			$template_content = apply_filters( 'the_content', get_the_content(null, false, $post_id ) );
			$custom_data = array(
				DROIP_APP_PREFIX . '_template_content' => $template_content, // Example: Get the current post ID
				DROIP_APP_PREFIX . '_template_id' => $post->ID,
			);
			// Set a global variable with custom data to make it available in the template
			set_query_var(DROIP_APP_PREFIX . '_custom_data', $custom_data);

			if ( file_exists( DROIP_FULL_CANVAS_TEMPLATE_PATH ) ) {
				return DROIP_FULL_CANVAS_TEMPLATE_PATH;
			}
		}else{
			$template = HelperFunctions::find_template_for_this_post($post);

			if(!$template){
				if ( is_page() ) {
					$template_name = get_post_meta( $post_id, '_wp_page_template', true );
					if ( ! empty( $template_name ) && $template_name !== $original && DROIP_FULL_CANVAS_TEMPLATE_PATH === $template_name ) {
						add_action( 'wp_enqueue_scripts', array( new HelperFunctions(), 'remove_theme_style' ) );//we can remove it. need to rethink. dequeue_all_except_my_plugin
						return $template_name;
					}
				}
			}else{
				$droip_data = HelperFunctions::is_droip_type_data($template['id']);
				if($droip_data){
					$template_content = HelperFunctions::get_html_using_preview_script( $droip_data['blocks'], $droip_data['styles'], 'body', $template['id'] );
					$custom_data = array(
						DROIP_APP_PREFIX . '_template_content' => $template_content, // Example: Get the current post ID
						DROIP_APP_PREFIX . '_template_id' => $template['id'],
					);
					// Set a global variable with custom data to make it available in the template
					set_query_var(DROIP_APP_PREFIX . '_custom_data', $custom_data);
					
					if ( file_exists( DROIP_FULL_CANVAS_TEMPLATE_PATH ) ) {
						return DROIP_FULL_CANVAS_TEMPLATE_PATH;
					}
				}
			}
		}
		return $original;
	}

}
