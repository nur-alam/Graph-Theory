<?php

/**
 * Plugin update events handler
 *
 * @package droip
 */

namespace Droip\Manager;

use Droip\Ajax\Page;
use Droip\Ajax\Users;
use Droip\HelperFunctions;

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

/**
 * Do some task on WordPress template redirection
 */
class TemplateRedirection
{

	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct()
	{
		// add_action( 'template_redirect', array( $this, 'droip_template_redirect' ) );
		/* update the the content with our droip data if page is droip */
		add_action('template_include', array($this, 'load_page_template'));
		// add_action('init', array($this, 'auth_template_redirection'));

		add_action('init', [$this, 'droip_utility_pages_rewrite_rules']);
		add_filter('query_vars', [$this, 'droip_utility_pages_query_vars']);
		// add_action('template_redirect', [$this, 'custom_login_signup_template_redirect']);
	}

	public function droip_utility_pages_query_vars($vars) {
    $vars[] = 'droip_utility_page_type';
    $vars[] = 'droip_utility_page_id';
    return $vars;
	}
	public function droip_utility_pages_rewrite_rules() {
		$utility_pages = Page::fetch_list(DROIP_APP_PREFIX . '_utility', true,  array('publish'));
		foreach ($utility_pages as $key => $page) {
			$utility_page_type = $page['utility_page_type'];
			$id = $page['id'];
			$slug = $page['slug'];
			if( $utility_page_type !== '404' ){
				// Add custom rewrite rule for login
				add_rewrite_rule("^$slug$", "index.php?droip_utility_page_type=$utility_page_type&droip_utility_page_id=$id", 'top');
			}
		}
		flush_rewrite_rules(true);
	}

	/**
	 * Load droip page template
	 * it will include the template file insted of original template file
	 * $loadForIframe = true if load for iframe
	 *
	 * @param string $original wp action for template file load.
	 * @return string template name.
	 */
	public function load_page_template($original)
	{
		$post_id = HelperFunctions::get_post_id_if_possible_from_url();
		$post = null;
		if($post_id){
			//this is for template and utility preview
			$post = get_post($post_id);
			if ($post->post_type === DROIP_APP_PREFIX . '_template') {
				//this is for template preview.(droip_template post type)
				$template_content = apply_filters('the_content', get_the_content(null, false, $post_id));
				
				$custom_data = array(
					DROIP_APP_PREFIX . '_template_content' => $template_content, // Example: Get the current post ID
					DROIP_APP_PREFIX . '_template_id' => $post->ID,
				);
				// Set a global variable with custom data to make it available in the template
				set_query_var(DROIP_APP_PREFIX . '_custom_data', $custom_data);
				
				if (file_exists(DROIP_FULL_CANVAS_TEMPLATE_PATH)) {
					return DROIP_FULL_CANVAS_TEMPLATE_PATH;
				}
			}else if ($post->post_type === DROIP_APP_PREFIX . '_utility') {
				//this is for template preview.(droip_template post type)
				$custom_post_content = apply_filters('the_content', get_the_content(null, false, $post_id));
				
				$custom_data = array(
					DROIP_APP_PREFIX . '_custom_post_content' => $custom_post_content, // Example: Get the current post ID
					DROIP_APP_PREFIX . '_custom_post_id' => $post->ID,
				);
				// Set a global variable with custom data to make it available in the template
				set_query_var(DROIP_APP_PREFIX . '_custom_data', $custom_data);
				
				if (file_exists(DROIP_FULL_CANVAS_TEMPLATE_PATH)) {
					return DROIP_FULL_CANVAS_TEMPLATE_PATH;
				}
			}
		}

		$context = HelperFunctions::get_current_page_context(); //{id, type}
		// echo "<pre>";var_dump($context);die;
		if(empty($context)){
			return $original;
		}
		switch ($context['type']) {
			case 'user':{
				$user = Users::get_user_by_id($context['id']);
				$template = HelperFunctions::find_template_for_this_context('user', $user);
				if ($template) {
					$options = [];
					$options['user'] = $user;
					return $this->set_template_or_post_content_for_droip_full_canvas_template($template, $options, $original);
				}
				break;
			}
			case 'post':{
				$template = HelperFunctions::find_template_for_this_context('post', $post);
				if($template){
					$options = [];	
					return $this->set_template_or_post_content_for_droip_full_canvas_template($template, $options, $original);
				}else{
					if (is_page()) {
						$template_name = get_post_meta($post_id, '_wp_page_template', true);
						if (! empty($template_name) && $template_name !== $original && DROIP_FULL_CANVAS_TEMPLATE_PATH === $template_name) {
							add_action('wp_enqueue_scripts', array(new HelperFunctions(), 'remove_theme_style')); //we can remove it. need to rethink. dequeue_all_except_my_plugin
							return $template_name;
						}
					}
				}
				break;
			}
			case '404':{
				$template = HelperFunctions::find_utility_page_for_this_context( '404', 'type');
				$options = [];
				return $this->set_template_or_post_content_for_droip_full_canvas_template($template, $options, $original);
			}
			case 'droip_utility':{
				$droip_utility_page_type = $context['droip_utility_page_type'];
				$droip_utility_page_id = $context['droip_utility_page_id'];
				if(HelperFunctions::check_utility_page_visibility_condition($droip_utility_page_type)){
					$template = HelperFunctions::find_utility_page_for_this_context( $droip_utility_page_id, 'id' );
					$options = [];
					return $this->set_template_or_post_content_for_droip_full_canvas_template($template, $options, $original);
				}
			}
			default:{
				break;
			}
		}
		return $original;
	}
	private function set_template_or_post_content_for_droip_full_canvas_template($template, $options, $original_template_path){
		if(!$template) return $original_template_path;

		$droip_data = HelperFunctions::is_droip_type_data($template['id']);

		if ($droip_data) {
			$template_content = HelperFunctions::get_html_using_preview_script($droip_data['blocks'], $droip_data['styles'], 'body', $template['id'], $options);
			$custom_data = array();

			if($template['post_type'] === DROIP_APP_PREFIX . '_utility'){
				$custom_data = array(
					DROIP_APP_PREFIX . '_custom_post_content' => $template_content, // Example: Get the current post ID
					DROIP_APP_PREFIX . '_custom_post_id' => $template['id'],
				);
			}else{
				$custom_data = array(
					DROIP_APP_PREFIX . '_template_content' => $template_content, // Example: Get the current post ID
					DROIP_APP_PREFIX . '_template_id' => $template['id'],
				);
			}
			
			// Set a global variable with custom data to make it available in the template
			set_query_var(DROIP_APP_PREFIX . '_custom_data', $custom_data);

			add_filter('droip_assets_should_load', function () { return true;} );
			if (file_exists(DROIP_FULL_CANVAS_TEMPLATE_PATH)) {
				return DROIP_FULL_CANVAS_TEMPLATE_PATH;
			}

		}
		return $original_template_path;
	}
}
