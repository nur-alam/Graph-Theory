<?php
/**
 * Plugin active events handler
 *
 * @package droip
 */

namespace Droip\Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
use Droip\HelperFunctions;


/**
 * Do some task during plugin activation
 */
class PluginActiveEvents {


	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct() {
		$installed = get_option( DROIP_APP_PREFIX . '_installed' );
		if ( ! $installed ) {
			update_option( DROIP_APP_PREFIX . '_installed', time() );
		}

		HelperFunctions::set_droip_version_in_db();

		$this->update_rbac();
		$this->create_custom_tables();
		$this->store_log();
	}

	/**
	 * Create custom tables
	 *
	 * @return void
	 */
	private function create_custom_tables() {
		$this->create_forms_table();
		$this->create_collaboration_table();
	}

	/**
	 * Update role manager data
	 *
	 * @return void
	 */
	private function update_rbac() {
		global $wp_roles;
		$role_names = $wp_roles->role_names;

		if ( is_array( $role_names ) && count( $role_names ) ) {
			foreach ( $role_names as $key => $value ) {
				$exist = get_option( DROIP_APP_PREFIX . '_' . $key );
				if ( ! $exist ) {
					if ( in_array( $key, DROIP_USERS_DEFAULT_FULL_ACCESS, true ) ) {
						add_option( DROIP_APP_PREFIX . '_' . $key, DROIP_ACCESS_LEVELS['FULL_ACCESS'] );
					} else {
						add_option( DROIP_APP_PREFIX . '_' . $key, DROIP_ACCESS_LEVELS['NO_ACCESS'] );
					}
				}
			}
		}
	}

	/**
	 * Create forms table
	 *
	 * @return void
	 */
	private function create_forms_table() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$form_table       = $wpdb->prefix . DROIP_FORM_TABLE;
		$form_table_query = "CREATE TABLE IF NOT EXISTS $form_table (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
      post_id bigint(20) unsigned NOT NULL,
      form_ele_id varchar(255) NOT NULL,
      name varchar(255) DEFAULT 'My Droip Form', 
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset_collate;";

		$form_data_table       = $wpdb->prefix . DROIP_FORM_DATA_TABLE;
		$form_data_table_query = "CREATE TABLE $form_data_table (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
      form_id bigint(20) unsigned NOT NULL,
      user_id bigint(20) unsigned DEFAULT NULL,
      session_id varchar(255) NOT NULL,
      timestamp bigint(11) NOT NULL,
      input_key varchar(255) NOT NULL,
      input_value varchar(2000) NOT NULL,
			input_type varchar(100) NOT NULL DEFAULT 'text',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			FOREIGN KEY (form_id) REFERENCES {$form_table}(id)
    ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		dbDelta( $form_table_query );
		dbDelta( $form_data_table_query );
	}

	public static function alter_form_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$form_table       = $wpdb->prefix . DROIP_FORM_TABLE;
		$form_data_table       = $wpdb->prefix . DROIP_FORM_DATA_TABLE;

		$form_data_table_query = "CREATE TABLE $form_data_table (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
      form_id bigint(20) unsigned NOT NULL,
      user_id bigint(20) unsigned DEFAULT NULL,
      session_id varchar(255) NOT NULL,
      timestamp bigint(11) NOT NULL,
      input_key varchar(255) NOT NULL,
      input_value varchar(2000) NOT NULL,
      input_type varchar(100) NOT NULL DEFAULT 'text' AFTER input_value,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		dbDelta( $form_data_table_query );

		/**************************
		 * Remove foreign key constrains
		 **************************/
		$db_name = DB_NAME;

		/**
		 * This results an array of query like ALTER TABLE `wp_droip_forms_data` DROP FOREIGN KEY `wp_droip_forms_data_ibfk_1`;
		 */
		$drop_foreign_key_queries_forms_table = $wpdb->get_results(
			"SELECT concat('ALTER TABLE `', TABLE_NAME, '` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
			FROM information_schema.key_column_usage
			WHERE CONSTRAINT_SCHEMA = '$db_name'
			AND TABLE_NAME='$form_table'
			AND referenced_table_name IS NOT NULL;",
			ARRAY_N
		);

		foreach($drop_foreign_key_queries_forms_table as $query) {
			if( isset($query[0]) && is_string($query[0])) {
				$wpdb->query( $query[0] );
			}
		}

		/**
		 * This results an array of query like ALTER TABLE `wp_droip_forms_data` DROP FOREIGN KEY `wp_droip_forms_data_ibfk_1`;
		 */
		$drop_foreign_key_queries_forms_data_table = $wpdb->get_results(
			"SELECT concat('ALTER TABLE `', TABLE_NAME, '` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
			FROM information_schema.key_column_usage
			WHERE CONSTRAINT_SCHEMA = '$db_name'
			AND TABLE_NAME='$form_data_table'
			AND COLUMN_NAME='user_id'
			AND referenced_table_name IS NOT NULL;",
			ARRAY_N
		);

		foreach($drop_foreign_key_queries_forms_data_table as $query) {
			if( isset($query[0]) && is_string($query[0])) {
				$wpdb->query( $query[0] );
			}
		}
	}

	/**
	 * Create forms table
	 *
	 * @return void
	 */
	private function create_collaboration_table() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$table_name = $wpdb->prefix . DROIP_COLLABORATION_TABLE;
		$sql1       = "CREATE TABLE IF NOT EXISTS $table_name (
      id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id bigint(20) NOT NULL,
      session_id varchar(50) NOT NULL,
      parent varchar(255) NOT NULL COMMENT 'table name',
      parent_id bigint(20) COMMENT 'table row id', 
      data longtext COMMENT 'json data', 
      status int(1) NOT NULL COMMENT '1=active, 2=sent, 0=expire', 
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset_collate;";

		$table_name = $wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected';
		$sql2       = "CREATE TABLE IF NOT EXISTS $table_name (
		id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		user_id bigint(20) NOT NULL,
		session_id varchar(50) NOT NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		) $charset_collate;";

		$table_name = $wpdb->prefix . DROIP_COLLABORATION_TABLE . '_sent';
		$sql3       = "CREATE TABLE IF NOT EXISTS $table_name (
		id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		collaboration_id bigint(20) NOT NULL,
		session_id varchar(50) NOT NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql1 );
		dbDelta( $sql2 );
		dbDelta( $sql3 );
	}
	/**
	 * Stores the log.
	 *
	 * @return void
	 */
	private function store_log() {
		$site_url = get_site_url();

		HelperFunctions::http_get( DROIP_CORE_PLUGIN_URL . '?log_data=activity&event=activate&version=' . DROIP_VERSION . '&domain=' . $site_url);
	}


}
