<?php
/**
 * Plugin update events handler
 *
 * @package droip
 */

namespace Droip\Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Do some task on WordPress plugin update check
 */
class PluginUpdateEvents {

	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'update_plugins_' . DROIP_PUBLIC_ASSETS_DOMAIN, array( $this, 'droip_check_for_updates' ), 10, 3 );
	}

	/**
	 * Droip check for updates
	 *
	 * @param bool  $update wp update data.
	 * @param array $plugin_data wp plugin_data data.
	 */
	public function droip_check_for_updates( $update, $plugin_data ) {
		static $response = false;

		if ( empty( $plugin_data['UpdateURI'] ) || ! empty( $update ) ) {
			return $update;
		}

		if ( $response === false ) {
			$response = wp_remote_get( $plugin_data['UpdateURI'] );
		}

		if ( is_wp_error($response) || empty( $response['body'] ) ) {
			return $update;
		}

		$custom_plugins_data = json_decode( $response['body'], true );

		if ( ! empty( $custom_plugins_data['latest'] ) ) {
			$version = $custom_plugins_data['latest'];
			return array(
				'version' => $version,
				'package' => DROIP_PUBLIC_ASSETS_URL . "/droip-builds/droip-$version.zip",
			);
		} else {
			return $update;
		}

	}
}
