<?php
/**
 * Plugin init events handler
 *
 * @package droip
 */

namespace Droip\Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Media;
use Droip\HelperFunctions;

/**
 * Do some task during plugin activation
 */
class PluginInitEvents {


	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'plugins_initial_tasks' ) );
		add_filter( 'upload_mimes', array( $this, 'cc_mime_types' ) );
		add_filter( 'big_image_size_threshold', '__return_false' );
		add_theme_support( 'post-thumbnails' );

		add_filter( 'wp_handle_upload_prefilter', array( new Media(), 'droip_handle_upload_prefilter' ) );
		add_filter( 'wp_generate_attachment_metadata', array( new Media(), 'droip_convert_sizes_to_webp' ) );
		add_filter( 'droip_html_generator', array( new HelperFunctions(), 'droip_html_generator' ), 10, 2 );
		add_filter( 'droip_template_finder', array( new HelperFunctions(), 'find_template_for_this_context' ), 10, 1 );
	}

	/**
	 * Register custom post type , mime types and theme page templates
	 *
	 * @return void
	 */
	public function plugins_initial_tasks() {
		// register_post_type( 'droip_page', array( 'public' => true ) );
		add_filter( 'theme_page_templates', array( $this, 'add_page_template_to_dropdown' ) );
		load_plugin_textdomain( DROIP_TEXT_DOMAIN, false, DROIP_PLUGIN_REL_URL . '/languages' );
	}

	/**
	 * Filter hook upload_mimes.
	 *
	 * @param array $mimes wp mimes.
	 * @return array
	 */
	public function cc_mime_types( $mimes ) {
		$data = get_option( DROIP_WP_ADMIN_COMMON_DATA );
		if ( isset( $data['json_upload'] ) && $data['json_upload'] === true ) {
			$mimes['json'] = 'text/plain';
		}
		if ( isset( $data['svg_upload'] ) && $data['svg_upload'] === true ) {
			$mimes['svg'] = 'image/svg+xml';
		}

		return $mimes;
	}

	/**
	 * Add page templates.
	 *
	 * @param  array $templates  The list of page templates.
	 *
	 * @return array  $templates  The modified list of page templates.
	 */
	public function add_page_template_to_dropdown( $templates ) {
		$templates[ DROIP_FULL_CANVAS_TEMPLATE_PATH ] = DROIP_APP_NAME . ' Full Canvas';
		return $templates;
	}
}
