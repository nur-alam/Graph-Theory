<?php
/**
 * Plugin Loaded events handler
 *
 * @package droip
 */

namespace Droip\Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Admin;
use Droip\Frontend;
use Droip\HelperFunctions;

/**
 * Do some task during plugin activation
 */
class PluginLoadedEvents {


	/**
	 * Initilize the class
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init_plugin' ) );
		add_action( 'plugins_loaded', array( $this, 'maybe_alter_form_tables' ) );
	}

	/**
	 * Initialize the plugin
	 *
	 * @return void
	 */
	public function init_plugin() {
		if ( is_admin() ) {
			new Admin();
		} else {
			new Frontend();
		}
	}

	/**
	 * Check version whether db needs update or not
	 *
	 * @return void
	 */
	public function maybe_alter_form_tables() {
		$version_in_db = HelperFunctions::get_droip_version_from_db();
		$db_altered_in = '1.1.1';

		if(empty($version_in_db) || version_compare($version_in_db, $db_altered_in, '<')) {
			PluginActiveEvents::alter_form_tables();
			HelperFunctions::set_droip_version_in_db();
		}
	}
}
