<?php
/**
 * DynamicContent manager API
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;


/**
 * DynamicContent API Class
 */
class DynamicContent {

	/**
	 * Get Dynamic element data
	 *
	 * @return void wpjson response
	 */
	public static function get_dynamic_element_data() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$content_type = HelperFunctions::sanitize_text( isset( $_GET['content_type'] ) ? $_GET['content_type'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$content_value = HelperFunctions::sanitize_text( isset( $_GET['content_value'] ) ? $_GET['content_value'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$meta_name = HelperFunctions::sanitize_text( isset( $_GET['meta_name'] ) ? $_GET['meta_name'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_GET['post_id'] ) ? $_GET['post_id'] : null );

		if ( ! empty( $content_value ) ) {
			switch ( $content_type ) {
				case 'post': {
					$post = null;

					if ( !empty( $post_id ) ) {
						$post = get_post($post_id);
					}

					$content = HelperFunctions::get_post_dynamic_content($content_value, $post, $meta_name);
					
					wp_send_json( $content );
					break;
				}

				case 'author': {
					$content = HelperFunctions::get_post_dynamic_content( $content_value );
					wp_send_json( $content );
					break;
				}

				case 'site': {
					$content = HelperFunctions::get_post_dynamic_content( $content_value );
					wp_send_json( $content );
					break;
				}

				default: {
					wp_send_json( false );
					break;
				}
			}
		}
	}
}
