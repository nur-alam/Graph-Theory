<?php
/**
 * Page or post data manager
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
use Droip\Ajax\Collaboration\Collaboration;
use Droip\HelperFunctions;


/**
 * Page API Class
 */
class Page {


	/**
	 * Save page data
	 *
	 * @return void wp_send_json.
	 */
	public static function save_page_data() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$page_data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		$page_data = json_decode( stripslashes( $page_data ), true );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_POST['id'] ) ? $_POST['id'] : '' );
		if ( ! empty( $page_data ) && ! empty( $post_id ) ) {

			HelperFunctions::save_droip_data_to_db($post_id, $page_data);

			$post = get_post($post_id);
			$arr = ['ID'=>$post->ID, 'type'=> $post->post_type];
			$post_id = wp_update_post( $arr );
			wp_send_json( array( 'status' => 'Page data saved.' ) );
		} else {
			wp_send_json( array( 'status' => 'Page data save failed!' ) );
		}
		die();
	}

	/**
	 * Delete page
	 *
	 * @return void wp_send_json.
	 */
	public static function delete_page() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$id = (int) HelperFunctions::sanitize_text( isset( $_POST['id'] ) ? $_POST['id'] : '' );
		wp_delete_post( $id );
		wp_send_json( array( 'status' => 'Page deleted' ) );
	}

	/**
	 * Add new page
	 *
	 * @return void wp_send_json.
	 */
	public static function add_new_page() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$options = isset( $_POST['options'] ) ? $_POST['options'] : null;
		$options = json_decode( stripslashes( $options ), true );

		if ( HelperFunctions::user_has_page_edit_access() ) {
			$post_id = wp_insert_post(
				array(
					'post_title' => $options['post_title'],
					'post_name'  => $options['post_title'],
					// check if type = droip_page then change it to wp page type. cause we only set template if page type is droip_page.
					'post_type'  => $options['post_type'] === 'droip_page' ? 'page' : $options['post_type'],
				)
			);

			if ( isset( $options['blocks'] ) ) {
				// this is for popup creation. cause popup has predefined blocks.
				update_post_meta( $post_id, DROIP_APP_PREFIX, $options['blocks'] );
			}
			
			if ( isset( $options['conditions'] ) ) {
				// this is for template creation. cause popup has predefined conditions.
				update_post_meta( $post_id, DROIP_APP_PREFIX.'_template_conditions', $options['conditions'] );
			}

			update_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE, DROIP_APP_PREFIX );
			if ($options['post_type'] === 'page' || $options['post_type'] === 'droip_page') {
				// check if type = droip_page then change it to wp page type. cause we only set template if page type is droip_page.
				update_post_meta( $post_id, '_wp_page_template', DROIP_FULL_CANVAS_TEMPLATE_PATH );
			}
			wp_send_json( ( new self() )->format_single_post( $post_id ) );
		} else {
			wp_send_json_error( 'Limited permission', 403 );
		}
	}

	/**
	 * Update current page data
	 *
	 * @return void wp_send_json.
	 */
	public static function update_page_data() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$options = isset( $_POST['options'] ) ? $_POST['options'] : null;
		$options = json_decode( stripslashes( $options ), true );
		$arr     = array();
		if ( isset( $options['ID'] ) ) {
			$arr['ID'] = $options['ID'];
			$post_id = $arr['ID'];
			if ( isset( $options['post_title'] ) ) {
				$arr['post_title'] = $options['post_title'];
			}
			if ( isset( $options['post_status'] ) ) {
				$arr['post_status'] = $options['post_status'];
			}
			wp_update_post( $arr );
	
			if ( isset( $options['blocks'] ) ) {
				update_post_meta( $post_id, DROIP_APP_PREFIX, $options['blocks'] );
			}
			if ( isset( $options['styleBlocks'] ) ) {
				update_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', $options['styleBlocks'] );
			}
			if ( isset( $options['usedFonts'] ) ) {
				update_post_meta( $post_id, DROIP_META_NAME_FOR_USED_FONT_LIST, $options['usedFonts'] );
			}
			if ( isset( $options['conditions'] ) ) {
				update_post_meta( $post_id, DROIP_APP_PREFIX.'_template_conditions', $options['conditions'] );
			}
			wp_send_json( ( new self() )->format_single_post( $post_id ) );
			die();
		}else{
			wp_send_json( array( 'status' => 'Page data update failed' ) );
			die();
		}
	}

	/**
	 * Duplicate page data
	 *
	 * @return void wp_send_json.
	 */
	public static function duplicate_page() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id     = (int) HelperFunctions::sanitize_text( isset( $_POST['id'] ) ? $_POST['id'] : '' );
		$post        = get_post( $post_id );
		$new_post_id = wp_insert_post(
			array(
				'post_title'   => $post->post_title . ' (copy)',
				'post_content' => $post->post_content,
				'post_name'    => $post->post_name,
				'post_type'    => $post->post_type,
				'post_status'  => $post->post_status,
			)
		);

		$page_data = get_post_meta( $post_id, DROIP_APP_PREFIX, true );
		if ( $page_data ) {
			update_post_meta( $new_post_id, DROIP_APP_PREFIX, $page_data );
			update_post_meta( $new_post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE, DROIP_APP_PREFIX );
		}

		/**
		 * Also duplicate _wp_page_template meta if exists
		 */
		$page_template = get_post_meta( $post_id, '_wp_page_template', true );
		if ( $page_template ) {
			update_post_meta( $new_post_id, '_wp_page_template', $page_template );
		}

		/**
		 * Also duplicate this page style blocks if exists
		 */
		$post_styles = get_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', true );
		if ( $post_styles ) {
			update_post_meta( $new_post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', $post_styles );
		}

		$used_fonts = get_post_meta( $post_id, DROIP_META_NAME_FOR_USED_FONT_LIST, true );
		if ( $used_fonts ) {
			update_post_meta( $new_post_id, DROIP_META_NAME_FOR_USED_FONT_LIST, $used_fonts );
		}

		wp_send_json( ( new self() )->format_single_post( $new_post_id ) );
	}

	/**
	 * Back to droip editor
	 *
	 * @return void wp_send_json.
	 */
	public static function back_to_droip_editor() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_POST['postId'] ) ? $_POST['postId'] : '' );

		$post = get_post( $post_id );

		if ( $post->post_status === 'auto-draft' ) {
			//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$post_title = HelperFunctions::sanitize_text( isset( $_POST['title'] ) ? $_POST['title'] : null );

			if ( ! isset( $post_title ) ) {
				$post_title = DROIP_APP_NAME . ' - ' . $post_id;
			}

			$data = array(
				'ID'          => $post_id,
				'post_title'  => $post_title,
				// 'post_name' => $post_title,
				'post_status' => 'draft',
			);
			wp_update_post( $data );
		}
		wp_send_json( array( 'status' => true ) );
	}


	/**
	 * Back to WordPress editor
	 *
	 * @return void wp_send_json.
	 */
	public static function back_to_wordpress_editor() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_POST['postId'] ) ? $_POST['postId'] : '' );

		delete_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE );
		wp_send_json( array( 'status' => true ) );
	}

	/**
	 * This function is called from EDITOR panel
	 *
	 * @return void wp_send_json.
	 */
	public static function get_page_blocks_and_styles() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_GET['id'] ) ? $_GET['id'] : '' );
		if ( ! empty( $post_id ) ) {
			$post_meta = get_post_meta( $post_id, DROIP_APP_PREFIX, true );
			if ( ! $post_meta ) {
				$post_meta           = array();
				$post_meta['blocks'] = null;
			}
			$styles              = HelperFunctions::get_page_styleblocks( $post_id );
			$post_meta['styles'] = $styles;

			$post_meta['preview_url']          = HelperFunctions::get_post_url_arr_from_post_id( $post_id )['preview_url'];
			$post_meta['is_droip_editor_mode'] = HelperFunctions::is_editor_mode_is_droip( $post_id );

			$content = get_the_content(null, false, $post_id);
			$post_meta['content_length'] = strlen($content);
			wp_send_json( $post_meta );
		}
		die();
	}

	/**
	 * Format single post data
	 *
	 * @param int $post_id post id.
	 * @return object|null post with custom data.
	 */
	public function format_single_post( $post_id ) {
		$post = get_post( $post_id );
		if ( $post ) {
			$page = array();
			if ( DROIP_APP_PREFIX . '_popup' === $post->post_type ) {
				$page['blocks']      = get_post_meta( $post->ID, DROIP_APP_PREFIX, true );
				$page['styleBlocks'] = get_post_meta( $post->ID, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', true );
				$page['usedFonts']   = get_post_meta( $post->ID, DROIP_META_NAME_FOR_USED_FONT_LIST, true );
			}
			
			if ( DROIP_APP_PREFIX . '_template' === $post->post_type ) {
				$conditions = get_post_meta( $post->ID, DROIP_APP_PREFIX.'_template_conditions', true );
				$page['conditions']  = $conditions ? $conditions : [];
			}
			$page['id']          = $post->ID;
			$page['title']       = $post->post_title;
			$page['status']      = $post->post_status;
			$page['post_type']   = $post->post_type;
			$page['post_parent']   = $post->post_parent;
			$page['preview_url'] = HelperFunctions::get_post_url_arr_from_post_id( $post->ID )['preview_url'];
			$page['editor_url']  = HelperFunctions::get_post_url_arr_from_post_id( $post->ID )['editor_url'];
			return $page;
		}
		return null;
	}

	/**
	 * Fetch page list
	 *
	 * @return void wp_send_json.
	 */
	public static function fetch_list_api() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$type      = HelperFunctions::sanitize_text( isset( $_GET['type'] ) ? $_GET['type'] : '' );
		$query     = HelperFunctions::sanitize_text(isset($_GET['query']) ? $_GET['query'] : '');
		$numberposts = HelperFunctions::sanitize_text(isset($_GET['numberposts']) ? $_GET['numberposts'] : 20);

		$page_list = array();
		if ( HelperFunctions::user_has_page_edit_access() ) {
			if (!empty($query)) {
				$page_list = static::fetch_list($type, true, array('publish', 'draft'), $query, $numberposts);
			} else {
				$page_list = static::fetch_list($type, true);
			}
		}

		wp_send_json( $page_list );
	}
	
	/**
	 * Fetch post list for search
	 *
	 * @return void wp_send_json.
	 */
	public static function get_post_list_for_search() {
		$all_posts = [];
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_type      = HelperFunctions::sanitize_text( isset( $_GET['post_type'] ) ? $_GET['post_type'] : '' );
		$query     = HelperFunctions::sanitize_text(isset($_GET['query']) ? $_GET['query'] : '');
		$numberposts = 20;
		$post_status = array('publish', 'draft');
		if ( HelperFunctions::user_has_page_edit_access() ) {
			$arg = array(
				'post_type'   => $post_type,
				'post_status' => $post_status,
				'numberposts' => $numberposts,
				'orderby'     => 'ID',
				'order'       => 'DESC',
			);
			if ($query) {
				$arg['s'] = $query;
			}
			$posts = get_posts($arg);
			foreach ($posts as $key => $post) {
				$all_posts[$key] = array(
					'ID'=>$post->ID,
					'post_title'=>$post->post_title
				);
			}

		}
		wp_send_json( $all_posts );
	}

	/**
	 * Get all post types and found the all post types that are not discarded post types
	 *
	 * @return void wp_send_json
	 */
	public static function fetch_post_list_data_post_type_wise() {

		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$search_query = HelperFunctions::sanitize_text( isset( $_GET['search'] ) ? $_GET['search'] : '' );

		$post_types           = get_post_types();
		$discarded_post_types = array( 'droip_page', 'page', 'attachment', 'custom_css', 'customize_changeset', 'wp_global_styles', 'revision', 'nav_menu_item', 'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation' );
		$post_types           = array_diff_key( $post_types, array_flip( $discarded_post_types ) );

		$args = array(
			'post_type'      => $post_types,
			's'              => $search_query,
			'posts_per_page' => -1,
			'post_status'    => 'any',
		);

		$all_posts = get_posts( $args );
		$data      = array();

		foreach ( $all_posts as $key => $p ) {
			$single_post = array(
				'id'         => $p->ID,
				'title'      => $p->post_title,
				'editor_url' => HelperFunctions::get_post_url_arr_from_post_id( $p->ID )['editor_url'],
			);
			if ( isset( $data[ $p->post_type ] ) ) {
				$data[ $p->post_type ][] = $single_post;
			} else {
				$data[ $p->post_type ] = array(
					$single_post,
				);
			}
		}

		wp_send_json( $data );
	}

	/**
	 * Fetch page list
	 * if $internal is true then it will return array
	 * otherwise it will return json for api call
	 *
	 * @param string  $type post type.
	 * @param boolean $internal if this method call from internal response.
	 * @param string  $post_status post status.
	 *
	 * @return void|array
	 */
	public static function fetch_list($type = 'page', $internal = true, $post_status = array('publish', 'draft'), $query = null, $numberposts = 20)
	{
		$pages = array();

		$arg = array(
			'post_type'   => $type,
			'post_status' => $post_status,
			'numberposts' => $numberposts,
			'orderby'     => 'ID',
			'order'       => 'DESC',
		);
		if ($query) {
			$arg['s'] = $query;
		}

		$posts = get_posts($arg);

		if (!empty($posts)) {
			foreach ($posts as $post) {

				/**
				 * If page template type is droip full page then check if GET['type'] is set to droip_page otherwise send any page type data
				 */
				$pages[] = (new self())->format_single_post($post->ID);
			}
		}

		if($internal){
			return $pages;
		}
		wp_send_json( $pages );
	}


	/**
	 * Get current page data
	 *
	 * @return void wp_send_json.
	 */
	public static function get_current_page_data() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id        = HelperFunctions::sanitize_text( isset( $_GET['id'] ) ? $_GET['id'] : '' );
		$post_formatted = null;
		if ( $post_id ) {
			$post_formatted = ( new self() )->format_single_post( $post_id );
		}
		wp_send_json( $post_formatted );
	}

	/**
	 * Remove all unused style blocks from option meta
	 * it will collect all posts unused style block id
	 * then it will remove all unused style blocks from option meta
	 *
	 * @return void wp_send_json.
	 */
	public static function remove_unused_style_block_from_db() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id = (int) HelperFunctions::sanitize_text( isset( $_POST['post_id'] ) ? $_POST['post_id'] : '' );

		$global_unused_key_array = self::get_unused_global_style_ids();
		$global_styles           = HelperFunctions::get_global_data_using_key( DROIP_GLOBAL_STYLE_BLOCK_META_KEY );
		foreach ( $global_unused_key_array as $key => $value ) {
			unset( $global_styles[ $value ] );
		}
		HelperFunctions::save_global_style_blocks( $global_styles );

		$post_used_ids = get_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS . '_random', true );
		$post_used_ids = $post_used_ids ? $post_used_ids : array();
		$this_styles   = get_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', true );
		foreach ( $this_styles as $key => $sb ) {
			if ( ! in_array( $key, $post_used_ids, true ) ) {
				unset( $this_styles[ $key ] );
			}
		}

		HelperFunctions::save_random_style_blocks( $post_id, $this_styles );

		wp_send_json(
			array(
				'status' => 'success',
				'data'   => HelperFunctions::get_page_styleblocks( $post_id ),
			)
		);
	}

	/**
	 * Get unused class info from db
	 *
	 * @param boolean $internal if this method call from internally.
	 * @return void|array wp_send_json.
	 */
	public static function get_unused_class_info_from_db( $internal = false ) {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_id            = (int) HelperFunctions::sanitize_text( isset( $_GET['post_id'] ) ? $_GET['post_id'] : '' );
		$global_unused_keys = self::get_unused_global_style_ids();
		$post_unused_keys   = self::get_unused_post_style_ids( $post_id );

		$merged_style_ids = array_merge( $global_unused_keys, $post_unused_keys );

		if ( $internal ) {
			return $merged_style_ids;
		}

		wp_send_json(
			array(
				'status' => 'success',
				'data'   => $merged_style_ids,
			)
		);

	}

	/**
	 * Get all global used style block ids
	 * first get all posts used global style ids
	 * then merge and returns.
	 *
	 * @return array style ids.
	 */
	private static function get_all_global_used_style_block_ids() {
		global $wpdb;
		//phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery
		$used_global_ids = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}postmeta WHERE meta_key = '" . DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS . "'", OBJECT );

		$all_used_block_ids = array();
		foreach ( $used_global_ids as $key => $p_meta ) {
			$this_used_global   = get_post_meta( $p_meta->post_id, $p_meta->meta_key, true );
			$all_used_block_ids = array_merge( $all_used_block_ids, $this_used_global );
		}
		$all_used_block_ids_global = array_unique( $all_used_block_ids );
		return $all_used_block_ids_global;
	}

	/**
	 * Get all global unused style block ids
	 * first get all posts used global style ids using get_all_global_used_style_block_ids()
	 * then collect and return.
	 *
	 * @return array style ids.
	 */
	private static function get_unused_global_style_ids() {
		$all_used_ids = self::get_all_global_used_style_block_ids();
		$styles       = HelperFunctions::get_global_data_using_key( DROIP_GLOBAL_STYLE_BLOCK_META_KEY );
		$unused_keys  = array();

		foreach ( $styles as $key => $sb ) {
			if ( ( ( isset( $sb['isDefault'] ) && ! $sb['isDefault'] ) || ! isset( $sb['isDefault'] ) ) && ! in_array( $key, $all_used_ids, true ) ) {
				$unused_keys[] = $key;
			}
		}
		return $unused_keys;
	}

	/**
	 * Get all post unused style block ids
	 * first get all posts used post style ids using get_unused_post_style_ids()
	 * then collect and return.
	 *
	 * @param int $post_id wp post id.
	 * @return array style ids.
	 */
	private static function get_unused_post_style_ids( $post_id ) {
		$all_used_ids = get_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS . '_random', true );
		$styles       = get_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', true );

		if ( ! $styles ) {
			return array();
		}
		$unused_keys = array();

		foreach ( $styles as $key => $sb ) {
			if ( ! $all_used_ids || ! in_array( $key, $all_used_ids, true ) ) {
				$unused_keys[] = $key;
			}
		}
		return $unused_keys;
	}
}
