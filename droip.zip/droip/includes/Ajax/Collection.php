<?php
/**
 * Dynamic content/Collection API
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;

/**
 * Collection API Class
 */
class Collection {

	/**
	 * Get collection return api response
	 *
	 * @return void wpjson response
	 */
	public static function get_collection() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$name = HelperFunctions::sanitize_text( isset( $_GET['name'] ) ? $_GET['name'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$sorting_param = HelperFunctions::sanitize_text( isset( $_GET['sorting'] ) ? $_GET['sorting'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$filter_param = HelperFunctions::sanitize_text( isset( $_GET['filters'] ) ? $_GET['filters'] : null );
		$inherit = HelperFunctions::sanitize_text( $_GET['inherit'] ?? false );
		$related = HelperFunctions::sanitize_text( $_GET['related'] ?? false );
		$post_parent = HelperFunctions::sanitize_text( $_GET['post_parent'] ?? null );
		$related_post_parent = HelperFunctions::sanitize_text( $_GET['related_post_parent'] ?? false );
		$item_per_page = HelperFunctions::sanitize_text( $_GET['items'] ?? 3 );
		$current_page = HelperFunctions::sanitize_text( $_GET['current_page'] ?? 1 );
		$context_param = HelperFunctions::sanitize_text( $_GET['context'] ? $_GET['context'] : null );
		$query = HelperFunctions::sanitize_text( isset( $_GET['q'] ) ? $_GET['q'] : '' );

		$sorting      = null;
		$filters       = null;
		$context = null;

		// handle bool
		$inherit = $inherit === 'true' ? true : false;
		$related = $related === 'true' ? true : false;

		if ( isset( $sorting_param ) ) {
			$sorting = json_decode( stripslashes( $sorting_param ), true );
		}

		if ( isset( $filter_param ) ) {
			$filters = json_decode( stripslashes( $filter_param ), true );
		}

		if ( isset( $context_param ) ) {
			$context = json_decode( stripslashes( $context_param ), true );
		}

		$posts = HelperFunctions::get_posts(
			array(
				'name'    => $name,
				'sorting' => $sorting,
				'filters'  => $filters,
				'inherit'	=> $inherit,
				'post_parent'	=> $post_parent,
				'post_status' => 'any',
				'related'	=> $related,
				'related_post_parent' => $related_post_parent,
				'item_per_page' => $item_per_page,
				'current_page' => $current_page,
				'context' => $context,
				'q' => $query,
			)
		);

		wp_send_json( $posts );

		die();
	}
}
