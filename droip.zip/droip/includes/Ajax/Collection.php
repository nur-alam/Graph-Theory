<?php
/**
 * Dynamic content/Collection API
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;

/**
 * Collection API Class
 */
class Collection {

	/**
	 * Get collection return api response
	 *
	 * @return void wpjson response
	 */
	public static function get_collection() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$name = HelperFunctions::sanitize_text( isset( $_GET['name'] ) ? $_GET['name'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$sorting_param = HelperFunctions::sanitize_text( isset( $_GET['sorting'] ) ? $_GET['sorting'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$filter_param = HelperFunctions::sanitize_text( isset( $_GET['filter'] ) ? $_GET['filter'] : null );
		$inherit = HelperFunctions::sanitize_text( $_GET['inherit'] ?? null );
		$related = HelperFunctions::sanitize_text( $_GET['related'] ?? false );
		$post_parent = HelperFunctions::sanitize_text( $_GET['post_parent'] ?? null );
		$related_post_parent = HelperFunctions::sanitize_text( $_GET['related_post_parent'] ?? false );
		$sorting      = null;
		$filter       = null;

		if ( isset( $sorting_param ) ) {
			$sorting = json_decode( stripslashes( $sorting_param ), true );
		}

		if ( isset( $filter_param ) ) {
			$filter = json_decode( stripslashes( $filter_param ), true );
		}

		$posts = HelperFunctions::get_posts(
			array(
				'name'    => $name,
				'sorting' => $sorting,
				'filter'  => $filter,
				'inherit'	=> $inherit,
				'post_parent'	=> $post_parent,
				'post_status' => 'any',
				'related'	=> $related,
				'related_post_parent' => $related_post_parent
			)
		);

		wp_send_json( $posts );

		die();
	}
}
