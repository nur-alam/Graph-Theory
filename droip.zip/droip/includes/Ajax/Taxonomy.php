<?php
/**
 * Taxonomy API
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;
use Exception;

/**
 * Taxonomy API Class
 */
class Taxonomy {
	public static function get_post_terms()
	{
		try {
			$id = HelperFunctions::sanitize_text( isset( $_GET['id'] ) ? $_GET['id'] : null );
	
			$taxonomy = HelperFunctions::sanitize_text( isset( $_GET['taxonomy'] ) ? $_GET['taxonomy'] : null );
	
			$taxonomies = get_the_terms( $id, $taxonomy );

			if ($taxonomies instanceof \WP_Error) {
				throw new Exception("Failed!");
			}
	
			if (is_array($taxonomies)) {
				wp_send_json_success(
					$taxonomies
				);
			} else {
				wp_send_json_success([]);
			}
		} catch(Exception $e) {
			wp_send_json_error(
				$e->getMessage(), $e->getCode() ?? 400
			);
		}

		die;
	}

	public static function get_terms()
	{
		try {
			$name = HelperFunctions::sanitize_text( isset( $_GET['name'] ) ? $_GET['name'] : null );

			$terms = get_terms( array(
				'taxonomy'   => $name,
				'hide_empty' => false,
			));

			if($terms instanceof \WP_Error) {
				throw new Exception("Error!");
			}

			wp_send_json_success($terms);
		} catch(Exception $e) {
			wp_send_json_error(
				$e->getMessage(), $e->getCode() ?? 400
			);
		}

		die;
	}
}
