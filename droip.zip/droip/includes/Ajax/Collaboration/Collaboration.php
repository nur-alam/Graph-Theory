<?php
/**
 * Collaboration controller
 *
 * @package droip
 */

namespace Droip\Ajax\Collaboration;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;

/**
 * Collaboration class for running and getting the collaboration process.
 */
class Collaboration {

	/**
	 * This method will trigger from builder ajax actions.
	 * This method will save all type and action related data inside data column.
	 *
	 * @return void wp_send_json
	 */
	public static function save_actions() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		$data = json_decode( stripslashes( $data ), true );

		$parent    = $data['parent'];
		$parent_id = $data['parent_id'];
		$action    = $data['action'];
		$status    = 1;

		$d = self::save_action_to_db( $parent, $parent_id, $action, $status );
		wp_send_json_success(
			$d
		);
	}

	/**
	 * Save action to db function will save a event if more than one people connected.
	 *
	 * @param string $parent post | styleblock for now.
	 * @param string $parent_id post id or 0 if global data.
	 * @param array  $data total event data.
	 * @param int    $status event status.
	 *
	 * @return bool,array if success.
	 */
	public static function save_action_to_db( $parent, $parent_id, $data, $status = 1 ) {
		if ( count( self::get_all_connected_rows() ) > 1 ) {
			$session_id = HelperFunctions::get_session_id();
			$user_id    = get_current_user_id();

			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->insert(
				$wpdb->prefix . DROIP_COLLABORATION_TABLE,
				array(
					'user_id'    => (int) $user_id,
					'session_id' => $session_id,
					'parent'     => $parent,
					'parent_id'  => (int) $parent_id,
					'data'       => wp_json_encode( $data ),
					'status'     => (int) $status,
				),
				array(
					'%d',
					'%s',
					'%s',
					'%d',
					'%s',
					'%d',
				)
			);
			return array(
				'id'         => $wpdb->insert_id,
				'session_id' => $session_id,
			);
		}

		return false;
	}

	/**
	 * Send action is The main eventsouce function.
	 * this method will start the eventsouce mechanism.
	 *
	 * @return void
	 */
	public static function send_actions() {
		self::save_connection_data();
		$sender = new Sender();
		$sender->start();
		exit();
	}

	/**
	 * Save connection data
	 */
	private static function save_connection_data() {
		$session_id = HelperFunctions::get_session_id();
		$user_id    = get_current_user_id();

		if ( ! self::get_connection( $session_id ) ) {
			self::add_connection( $user_id, $session_id );
		}

	}

	/**
	 * Add connection if a user is give eventsource request.
	 *
	 * @param int    $user_id wp user id.
	 * @param string $session_id current user session id.
	 */
	private static function add_connection( $user_id, $session_id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected',
			array(
				'user_id'    => (int) $user_id,
				'session_id' => $session_id,
			),
			array(
				'%d',
				'%s',
			)
		);
		if ( $wpdb->insert_id ) {
			return self::get_connection( $session_id );
		}
		return false;
	}

	/**
	 * Delete connection if a user give event close request.
	 *
	 * @param string $session_id current user session id.
	 */
	public static function delete_connection( $session_id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected', array( 'session_id' => $session_id ) );
	}

	/**
	 * Get single connection.
	 *
	 * @param string $session_id current user session id.
	 *
	 * @return bool,array
	 */
	public static function get_connection( $session_id ) {
		global $wpdb;
		$query = $wpdb->prepare(
			'SELECT * FROM %1s WHERE session_id = %s',
			$wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected',
			$session_id
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$this_connection = $wpdb->get_row( $query );
		if ( $this_connection ) {
			$date = gmdate( 'Y-m-d H:i:s' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected',
				array(
					'updated_at' => $date,
				),
				array(
					'session_id' => $session_id,
				),
				array(
					'%s',
				),
				array(
					'%s',
				)
			);
			return $this_connection;
		}
		return false;
	}

	/**
	 * Get all connected rows.
	 * first clean disconnected rows then get only recent connected rows.
	 *
	 * @return array
	 */
	public static function get_all_connected_rows() {
		self::clean_disconnected_rows();
		global $wpdb;
		$query2 = $wpdb->prepare(
			'SELECT * FROM %1s',
			$wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected'
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$res = $wpdb->get_results( $query2 );
		return $res;
	}

	/**
	 * Clean disconnected rows if inactive less then 50 seconds.
	 *
	 * @return void
	 */
	private static function clean_disconnected_rows() {
		global $wpdb;
		$fifty_seconds_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-50 seconds' ) );
		$query1            = $wpdb->prepare(
			'DELETE FROM %1s WHERE updated_at <= %s',
			$wpdb->prefix . DROIP_COLLABORATION_TABLE . '_connected',
			$fifty_seconds_ago
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $query1 );
	}

}
