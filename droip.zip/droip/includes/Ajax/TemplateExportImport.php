<?php

/**
 * Manage dynamic form data api calls
 *
 * @package droip
 */

namespace Droip\Ajax;

use Droip\ExportImport\TemplateExport;
use Droip\ExportImport\TemplateImport;

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}
class TemplateExportImport
{

  public static function export(){
    $te = new TemplateExport();
    $zip_file_url = $te->export_and_get_url();
    if($zip_file_url){
      wp_send_json_success($zip_file_url);
    }else{
      wp_send_json_error('Failed to export template');
    }
  }

  public static function import()
  {
    set_time_limit(300);
    $file = $_FILES['file']; // zip file
    $upload_dir = wp_upload_dir();

    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_error = $file['error'];

    $file_ext = explode('.', $file_name); // ['file', 'ext']
    $file_ext = strtolower(end($file_ext)); // 'ext'

    $allowed = ['zip'];

    if (in_array($file_ext, $allowed)) {
      if ($file_error === 0) {

        $file_name_new = uniqid('', true) . '.' . $file_ext; // 'random.ext'
        $file_destination = $upload_dir['basedir'] . '/' . $file_name_new;

        if (move_uploaded_file($file_tmp, $file_destination)) {

          $ti = new TemplateImport();
          $status = $ti->import($file_destination, 'b_1', true);
          if($status){
            wp_send_json_success('Template Imported Successfully');
          }else{
            wp_send_json_error('Failed to import template');
          }
        } else {
          wp_send_json_error('Something went wrong');
        }
      } else {
        wp_send_json_error('Zip File upload Failed');
      }
    } else {
      wp_send_json_error('File type not allowed, Upload Droip Exported Zip file');
    }
  }

  public static function process(){
    $t = new TemplateImport();
    $res = $t->process();
    wp_send_json_success($res);
  }
}
