<?php
/**
 * Manager User data
 *
 * @package droip
 */

namespace Droip\Ajax;

use Droip\HelperFunctions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * UserData API Class
 */
class UserData {

	/**
	 * Save user controller data
	 *
	 * @return void wp_send_json
	 */
	public static function save_user_controller() {
		$user_id = get_current_user_id();
        //phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		$data = json_decode( stripslashes( $data ), true );
		if ( ! empty( $user_id ) ) {
			HelperFunctions::update_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY, $data );
			wp_send_json( array( 'status' => 'User controller data saved' ) );
		}
		die();
	}

	/**
	 * Save user saved data
	 *
	 * @return void wp_send_json
	 */
	public static function save_user_saved_data() {
		$user_id = get_current_user_id();
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		$data = json_decode( stripslashes( $data ), true );
		if ( ! empty( $user_id ) ) {
			HelperFunctions::update_global_data_using_key( DROIP_USER_SAVED_DATA_META_KEY, $data );
			wp_send_json( array( 'status' => 'User saved data saved' ) );
		}
		die();
	}

	/**
	 * Save user custom fonts data
	 *
	 * @return void wp_send_json
	 */
	public static function save_user_custom_fonts_data() {
		$user_id = get_current_user_id();
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		$data = json_decode( stripslashes( $data ), true );
		if ( ! empty( $user_id ) ) {
			HelperFunctions::update_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY, $data );
			wp_send_json( array( 'status' => 'User custom fonts data saved' ) );
		}
		die();
	}

	/**
	 * Get user controller data
	 *
	 * @return void wp_send_json
	 */
	public static function get_user_controller() {
		$user_id = get_current_user_id();
		if ( ! empty( $user_id ) ) {
			$control = HelperFunctions::get_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY );
			if ( $control ) {
				//TODO: this code will remove in future version
				if(isset($control['navbarMenus']) && !in_array('content-manager', $control['navbarMenus'])){
					$control['navbarMenus'][] = 'content-manager';
				}
				wp_send_json( $control );
			} else {
				wp_send_json( json_decode( '{}' ) );
			}
		}
		die();
	}


	/**
	 * Get User Saved data
	 *
	 * @return void wp_send_json
	 */
	public static function get_user_saved_data() {
		$user_id = get_current_user_id();
		if ( ! empty( $user_id ) ) {
			$saved_data = HelperFunctions::get_global_data_using_key( DROIP_USER_SAVED_DATA_META_KEY );
			if(!$saved_data){
				$saved_data = array();
			}

			if(!isset($saved_data['variableData'])){
				$saved_data['variableData'] = self::initial_variable_data();
			}

			wp_send_json( $saved_data );
		}
		die();
	}

	public static function initial_variable_data()
	{
		return json_decode('{"data":[]}', true);
	}
	
	public static function get_droip_variable_data()
	{
		$variables = array();
		$saved_data = HelperFunctions::get_global_data_using_key( DROIP_USER_SAVED_DATA_META_KEY );
		if($saved_data && isset($saved_data['variableData']) && count($saved_data['variableData']) > 0){
				$variables = $saved_data['variableData'];
		}else{
			$variables = self::initial_variable_data();
		}
		return $variables;
	}

	/**
	 * Get user custom fonts data
	 *
	 * @return void wp_send_json
	 */
	public static function get_user_custom_fonts_data() {
		$user_id = get_current_user_id();
		if ( ! empty( $user_id ) ) {
			$custom_fonts = HelperFunctions::get_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY );
			if ( $custom_fonts ) {
				wp_send_json( $custom_fonts );
			} else {
				wp_send_json( json_decode( '{}' ) );
			}
		}
		die();
	}

	/**
	 * Get View port list.
	 * this method only for front end. not for editor. cause list data not completed data.
	 *
	 * @return array
	 */
	public static function get_view_port_list() {
		$control = HelperFunctions::get_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY );
		if ( ! $control || ! isset( $control['viewport'],  $control['viewport']['list'] ) ) {
			return self::sort_viewport_list( HelperFunctions::get_initial_view_ports()['list']);
		}
		return self::sort_viewport_list( $control['viewport']['list'] );
	}

	/**
	 * Sort view port list
	 *
	 * @param array $arr list of view port list.
	 * @return array
	 */
	private static function sort_viewport_list( $arr ) {
		$arr = (array) $arr;
		$list = array();
		array_multisort( array_column( $arr, 'minWidth' ), SORT_ASC, SORT_NUMERIC, $arr );
		$flag = false;
		foreach ( $arr as $key => $value ) {
			if ( $flag ) {
				$list[ $key ]         = $value;
				$list[ $key ]['type'] = 'min';
				$list[ $key ]['id']   = $key;
			}
			if ( $key === 'md' ) {
				$flag                 = true;
				$list[ $key ]         = $value;
				$list[ $key ]['id']   = $key;
				$list[ $key ]['type'] = 'max';
			}
		}
		$flag = false;
		foreach ( array_reverse( $arr ) as $key => $value ) {
			if ( $flag ) {
				$list[ $key ]         = $value;
				$list[ $key ]['type'] = 'max';
				$list[ $key ]['id']   = $key;
			}
			if ( $key === 'md' ) {
				$flag = true;
			}
		}
		return $list;
	}
}
