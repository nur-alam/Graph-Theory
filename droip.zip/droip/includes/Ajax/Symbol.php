<?php
/**
 * Manage Symbol
 *
 * @package droip
 */

namespace Droip\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\HelperFunctions;


/**
 * Symbol API Class
 */
class Symbol {

	/**
	 * Create/save a symbol
	 *
	 * @return void wp_send_json.
	 */
	public static function save() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_symbol_data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		if ( ! empty( $post_symbol_data ) ) {
			$wp_post = array(
				'post_type' => DROIP_SYMBOL_TYPE,
			);

			$post_id = wp_insert_post( $wp_post );
			if ( isset( $post_id ) ) {

				$symbol_data = json_decode( stripslashes( $post_symbol_data ), true );
				$symbol_data['data'][ $symbol_data['root'] ]['properties']['symbolId'] = $post_id;

				add_post_meta( $post_id, DROIP_APP_PREFIX, $symbol_data );
				add_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE, DROIP_APP_PREFIX );

				$data = array(
					'id'         => $post_id,
					'symbolData' => $symbol_data,
					'type'       => isset( $symbol_data['category'] ) ? $symbol_data['category'] : 'other',
				);
				$data['html'] = self::get_symbol_html_preview($data);
				wp_send_json( $data );
			}
		};

		die();
	}

	/**
	 * Fetch symbol list
	 * if $internal is true then it will return array
	 * otherwise it will return json for api call
	 *
	 * @param boolean $internal if function call from internally.
	 * @param boolean $html if need html string.
	 * @return array|void wp_send_json.
	 */
	public static function fetch_list( $internal = false , $html=false) {
		$posts = get_posts(
			array(
				'post_type'   => DROIP_SYMBOL_TYPE,
				'post_status' => 'draft',
				'numberposts' => -1,
			)
		);

		$symbols = array();

		if ( ! empty( $posts ) ) {
			$symbols = array_map(
				function( $post ) use ($html, $internal){
					 $single_symbol = self::get_single_symbol( $post->ID, true, $html );
					 if(!$internal){
						unset($single_symbol["symbolData"]["data"]);
						unset($single_symbol["symbolData"]["styleBlocks"]);
					 }
					 return $single_symbol;
				},
				$posts
			);
		}

		if ( $internal ) {
			return $symbols;
		}
		wp_send_json( $symbols );
	}

	/**
	 * Fetch single symbol
	 * if $internal is true then it will return array
	 * otherwise it will return json for api call
	 *
	 * @param int     $symbol_id symbol id.
	 * @param boolean $internal if the function call from internally.
	 * @param boolean $html if need html preview string.
	 * @return array|void
	 */
	public static function get_single_symbol( $symbol_id = null, $internal = false, $html=false ) {
		//phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated,WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$symbol_id = $symbol_id ? $symbol_id : HelperFunctions::sanitize_text( isset( $_GET['symbol_id'] ) ? $_GET['symbol_id'] : null );
		$post      = get_post( $symbol_id );
		$symbol    = null;
		if ( $post ) {
			$symbol               = array();
			$symbol_data          = get_post_meta( $post->ID, DROIP_APP_PREFIX, true );
			$symbol['id']         = $post->ID;
			$symbol['symbolData'] = $symbol_data;
			$symbol['type']       = isset( $symbol_data['category'] ) ? $symbol_data['category'] : 'other';
			if($html === true){
				$symbol['html'] = self::get_symbol_html_preview($symbol);
			}
		}

		if ( $internal ) {
			return $symbol;
		}
		wp_send_json( $symbol );
	}

	private static function get_symbol_html_preview($symbol){
		$symbol_data = $symbol['symbolData'];
		$s = HelperFunctions::get_html_using_preview_script( $symbol_data['data'], $symbol_data['styleBlocks'], $symbol_data['root'], $symbol['id'], [], true, false );
		return $s;
	}

	/**
	 * Update Symbol data
	 *
	 * @return void wp_send_json.
	 */
	public static function update() {
		//phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated,WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$symbol_id = HelperFunctions::sanitize_text( isset( $_POST['symbol_id'] ) ? $_POST['symbol_id'] : null );
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$post_symbol_data = isset( $_POST['data'] ) ? $_POST['data'] : null;
		if ( $symbol_id && ! empty( $post_symbol_data ) ) {
			$data        = json_decode( stripslashes( $post_symbol_data ), true );
			$symbol_data = get_post_meta( $symbol_id, DROIP_APP_PREFIX, true );

			if ( $symbol_data ) {
				if ( isset( $data['data'] ) ) {
					$symbol_data['data'] = $data['data'];
				}
				if ( isset( $data['styleBlocks'] ) ) {
					$symbol_data['styleBlocks'] = $data['styleBlocks'];
				}
				if ( isset( $data['customFonts'] ) ) {
					$symbol_data['customFonts'] = $data['customFonts'];
				}
				if ( isset( $data['name'] ) ) {
					$symbol_data['name'] = $data['name'];
				}
				if ( isset( $data['category'] ) ) {
					$symbol_data['category'] = $data['category'];
				} else {
					$symbol_data['category'] = 'other';
				}
				if ( isset( $data['root'] ) ) {
					$symbol_data['root'] = $data['root'];
				}
				if ( isset( $data['conditions'] ) ) {
					$symbol_data['conditions'] = $data['conditions'];
				}
				$updated = update_post_meta( $symbol_id, DROIP_APP_PREFIX, $symbol_data );

				$updated === true ? wp_send_json( self::get_single_symbol($symbol_id, true, true) ) : wp_send_json( false );
			} else {
				wp_send_json( false );
			}
		}
		die();
	}

	/**
	 * Delete a symbol
	 *
	 * @return void
	 */
	public static function delete() {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$symbol_id = HelperFunctions::sanitize_text( isset( $_POST['symbol_id'] ) ? $_POST['symbol_id'] : null );
		if ( $symbol_id ) {
			$post = wp_delete_post( $symbol_id );
			isset( $post ) ? wp_send_json( true ) : wp_send_json( false );
		}
		die();
	}
}
