<?php
/**
 * Helper class for droip project
 *
 * @package droip
 */

namespace Droip;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Droip\Ajax\Collaboration\Collaboration;
use Droip\Ajax\Page;
use Droip\Ajax\Symbol;
use Droip\Ajax\UserData;
use Droip\Ajax\WpAdmin;
use Droip\API\ContentManager\ContentManagerHelper;
use Droip\Frontend\Preview\DataHelper;
use Droip\Frontend\Preview\Preview;
/**
 * HelperFunctions Class
 */
class HelperFunctions {
	/**
	 * Load assets for Editor
	 *
	 * @param string $for TheFrontend | null.
	 * @return false || array
	 */
	public static function is_droip_type_data( $post_id = false ) {
		if(!$post_id){
			$post_id = self::get_post_id_if_possible_from_url();
			if(!$post_id)return false;
		}

		if ( ! self::is_editor_mode_is_droip( $post_id ) ) {
			return false;
		}
		$droip_data = get_post_meta( $post_id, DROIP_META_NAME_FOR_POST_DATA, true );
		if ( ! $droip_data ) {
			$droip_data           = array();
			$droip_data['blocks'] = null;
		}

		$styles = self::get_page_styleblocks( $post_id );

		$droip_data['styles'] = isset( $styles ) ? $styles : '';

		return $droip_data;
	}

	public static function get_post_id_if_possible_from_url() {
		if ( isset( $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_child_post'] ) ) {
			return $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_child_post'];
		}else if(isset( $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_parent_post'] ) && false){//disable content manager archive page logic
			return $GLOBALS['wp']->query_vars[DROIP_CONTENT_MANAGER_PREFIX . '_parent_post'];
		}

		$post_id = get_the_ID();
		if(isset( $_GET['post_id'] )){
			$post_id = $_GET['post_id'];
		}else if(isset( $_POST['post_id'] )){//this block for symbol preview when dynamic content is used
			$post_id = $_POST['post_id'];
		}
		return $post_id;
	}

	public static function save_droip_data_to_db($post_id, $page_data){
		if ( isset( $page_data['styles'] ) ) {
			$styles = self::get_page_styleblocks( $post_id );
			if ( $styles ) {
				$merge_styles = array_merge( $styles, $page_data['styles'] );
			} else {
				$merge_styles = $page_data['styles'];
			}
			self::update_page_styleblocks( $post_id, $merge_styles );
			unset( $page_data['styles'] );
		}

		if ( isset( $page_data['usedStyles'] ) ) {
			update_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS, $page_data['usedStyles'] );
			unset( $page_data['usedStyles'] );
		}

		if ( isset( $page_data['usedStyleIdsRandom'] ) ) {
			update_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS . '_random', $page_data['usedStyleIdsRandom'] );
			unset( $page_data['usedStyleIdsRandom'] );
		}

		if ( isset( $page_data['usedFonts'] ) ) {
			update_post_meta( $post_id, DROIP_META_NAME_FOR_USED_FONT_LIST, $page_data['usedFonts'] );
			unset( $page_data['usedFonts'] );
		}

		if ( isset( $page_data['customFonts'] ) ) {
			//save others data if isset. this is for template import
			$custom_fonts = self::get_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY );
			foreach ($page_data['customFonts'] as $key => $cf) {
				$custom_fonts[$key] = $cf;
			}
			self::update_global_data_using_key( DROIP_USER_CUSTOM_FONTS_META_KEY, $custom_fonts );
			unset( $page_data['customFonts'] );
		}
		
		if ( isset( $page_data['viewportList'] ) ) {
			//save others data if isset. this is for template import
			$controller_data = self::get_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY );
			if ( ! $controller_data ) {
				$init = array( 
					'active' =>'md',
					'defaults'=> ["md", "tablet", "mobileLandscape", "mobile"],
					'list' => $page_data['viewportList'],
					'mdWidth'=> 1400,
					"scale"=>1,
					"width"=>2484,
					"zoom"=>1
				);
				$controller_data = array('viewport'=> $init);
			}else if(isset($controller_data['viewport'], $controller_data['viewport']['list'])){
				$controller_data['viewport']['list'] = $page_data['viewportList'];
			}

			HelperFunctions::update_global_data_using_key( DROIP_USER_CONTROLLER_META_KEY, $controller_data );
			unset( $page_data['viewportList'] );
		}

		if ( isset( $page_data['blocks'] ) ) {
			update_post_meta( $post_id, DROIP_APP_PREFIX, array('blocks'=>$page_data['blocks']) );
			$data = array(
				'type'    => 'COLLABORATION_PAGE_DATA',
				'payload' => array( 'data' => $page_data['blocks'] ),
			);
			Collaboration::save_action_to_db( 'post', $post_id, $data, 1 );
		}

		

		update_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE, DROIP_APP_PREFIX );
	}

	/**
	 * This function will return page style blocks from option meta and post meta
	 * post meta for migration and option meta for global style block
	 *
	 * @param int $post_id post id.
	 * @return object
	 */
	public static function get_page_styleblocks( $post_id ) {
		$random_style_blocks = get_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', true );
		$global_style_blocks = self::get_global_data_using_key( DROIP_GLOBAL_STYLE_BLOCK_META_KEY );

		$merged_style_blocks = array();
		if ( $random_style_blocks ) {
			$merged_style_blocks = array_merge( $merged_style_blocks, $random_style_blocks );
		}
		if ( $global_style_blocks ) {
			$merged_style_blocks = array_merge( $merged_style_blocks, $global_style_blocks );
		}

		return $merged_style_blocks;
	}

	/**
	 * This function will update page style blocks into option meta and post meta
	 * post meta for migration and option meta for global style block
	 *
	 * @param int    $post_id post id.
	 * @param object $style_blocks styleblocks.
	 */
	public static function update_page_styleblocks( $post_id, $style_blocks ) {
		$prev_style_blocks = self::get_page_styleblocks( $post_id );
		$style_blocks      = array_merge( $prev_style_blocks, $style_blocks );

		$global_style_blocks = array();
		foreach ( $style_blocks as $key => $sb ) {
			if ( ( isset( $sb['isDefault'] ) && $sb['isDefault'] === true ) || ( isset( $sb['isGlobal'] ) && $sb['isGlobal'] === true ) ) {
				$global_style_blocks[ $sb['id'] ] = $sb;
				unset( $style_blocks[ $key ] );
			}
		}

		self::save_global_style_blocks( $global_style_blocks );
		self::save_random_style_blocks( $post_id, $style_blocks );
	}

	/**
	 * Save global style blocks in option table. Also save collaboration data.
	 *
	 * @param array $style //take styleblocs if isDefault and isGlobal key is true.
	 * @return void
	 */
	public static function save_global_style_blocks( $style ) {
		self::update_global_data_using_key( DROIP_GLOBAL_STYLE_BLOCK_META_KEY, $style );
		$data = array(
			'type'    => 'COLLABORATION_UPDATE_GLOBAL_STYLE',
			'payload' => array( 'styleBlock' => $style ),
		);
		Collaboration::save_action_to_db( 'styleBlock', 0, $data, 1 );
	}

	/**
	 * Save post related random style blocks in option table. Also save collaboration data.
	 *
	 * @param array $post_id //current post id.
	 * @param array $style //take styleblocs if not isDefault and isGlobal key is true.
	 * @return void
	 */
	public static function save_random_style_blocks( $post_id, $style ) {
		update_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random', $style );
		$data = array(
			'type'    => 'COLLABORATION_UPDATE_GLOBAL_STYLE',
			'payload' => array( 'styleBlock' => $style ),
		);
		Collaboration::save_action_to_db( 'post', $post_id, $data, 1 );
	}

	/**
	 * No module import this method right now
	 *
	 * @return array
	 */
	public static function get_custom_code_block_element() {
		return array(
			'name'       => 'custom-code',
			'title'      => 'Code',
			'visibility' => true,
			'properties' => array(
				'tag'       => 'div',
				'content'   => '',
				'data-type' => 'code',
			),
			'styleIds'   => array(),
			'className'  => '',
			'id'         => DROIP_CLASS_PREFIX . uniqid(),
			'parentId'   => 'body',
		);
	}
	/**
	 * Get current editor mode is droip or others
	 *
	 * @param int $post_id post id.
	 * @return bool true if droip.
	 */
	public static function is_editor_mode_is_droip( $post_id ) {
		$editor_mode = get_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE, true );
		if ( DROIP_APP_PREFIX === $editor_mode ) {
			return true;
		}
		return false;
	}

	/**
	 * Get post url arr from post id
	 * preview_url, iframe_url, post_url
	 *
	 * @param int $post_id post id.
	 * @return array
	 */
	public static function get_post_url_arr_from_post_id( $post_id ) {
		$post_perma_link = get_permalink( $post_id );
		$protocol = strpos(home_url(), 'https://') !== false ? 'https' : 'http';
		if ( $protocol === 'https' ) {
			$post_perma_link = str_replace( 'http://', 'https://', $post_perma_link );
		} else {
			$post_perma_link = str_replace( 'https://', 'http://', $post_perma_link );
		}

		return array(
			'preview_url'     => add_query_arg(
				array(
					'post_id' => $post_id,
				),
				$post_perma_link
			),
			'editor_url'      => add_query_arg(
				array(
					'action'  => DROIP_EDITOR_ACTION,
					'post_id' => $post_id,
				),
				$post_perma_link
			),
			'iframe_url'      => add_query_arg(
				array(
					'action'   => DROIP_EDITOR_ACTION,
					'load_for' => 'droip-iframe',
					'post_id'  => $post_id,
				),
				$post_perma_link
			),
			'post_url'        => $post_perma_link,
			'ajax_url'        => admin_url( 'admin-ajax.php', $protocol ),
			'rest_url'        => rest_url(),
			'nonce'           => wp_create_nonce( 'wp_rest' ),
			'site_url'        => get_site_url(),
			'admin_url'       => get_admin_url(),
			'core_plugin_url' => DROIP_CORE_PLUGIN_URL,
			'post_id'         => $post_id,

			/*
			NB: These are sent debugging purpose, please don't remove them without being sure
			'home_url' => home_url(),
			'origin' => get_http_origin(),
			'site_url' => site_url(),
			'host' => $_SERVER['SERVER_NAME'],
			'http_host' => $domainLink,
			*/
		);
	}

	/**
	 * Get post content from content value. like => id, title, description, content
	 *
	 * @param string $content_value for post dynamic content.
	 * @param object $post post object.
	 *
	 * @return string
	 */
	public static function get_post_dynamic_content($content_value, $post = null, $meta_name = '')
	{
		if ( isset( $post ) && ! empty( $post ) ) {
			$post_id = $post->ID;
		}

		if ( empty( $post_id ) ) {
			$post_id = self::get_post_id_if_possible_from_url();
		}

		$content = null;

		switch ( $content_value ) {
			case 'post_id': {
					$content = $post_id;
					break;
			}

			case 'post_title': {
					$content = get_the_title( $post_id );
					break;
			}

			case 'post_excerpt': {
					$content = get_the_excerpt( $post_id );
					break;
			}

			case 'post_author': {
					$post    = get_post( $post_id );
					$content = get_the_author_meta( 'display_name', $post->post_author );
					break;
			}

			case 'post_date': {
					$content = get_the_date('', $post_id);
					break;
			}

			case 'post_time': {
					$content = get_the_time( '', $post_id );
					break;
			}

			case 'post_content': {
				$content = self::retrieve_post_content($post_id);
				break;
			}

			case 'post_status': {
					$content = get_post_status( $post_id );
					break;
			}

			case 'featured_image': {
					$content = array(
						'wp_attachment_id' => get_post_thumbnail_id( $post_id ),
						'src' => get_the_post_thumbnail_url( $post_id )
					);
					break;
			}

			case 'site_logo': {
					$custom_logo_id = get_theme_mod( 'custom_logo' );
					$imgs           = wp_get_attachment_image_src( $custom_logo_id, 'full' );

				if ( $imgs ) {
					$content = $imgs[0];
				}
				break;
			}

			case 'author_profile_picture': {
					$post = get_post( $post_id );

				if ( ! empty( $post ) ) {
					$post_author = $post->post_author;
					$content     = get_avatar_url( $post_author );
				} else {
					$content = 'Something wrong!';
				}

				break;
			}

			case 'user_profile_picture': {
					$content = get_avatar_url( get_current_user_id() );
					break;
			}

			case 'post_page_link': {
					$url     = \get_permalink( $post_id );
					$content = ! empty( $url ) ? $url : '';
					break;
			}

			case 'author_posts_page_link': {
					$post    = \get_post( $post_id );
					$url     = \get_author_posts_url( $post->post_author );
					$content = ! empty( $url ) ? $url : '';
					break;
			}

			case 'post_meta': {
				if ( ! empty( $meta_name ) ) {
					$meta = get_post_meta( $post_id, $meta_name, true );

					// For now, only string is supported!
					if ( is_string( $meta ) ) {
						$content = $meta;
					}
				}

				break;
			}

			default: {
				$post    = get_post( $post_id );
				if (isset($post) && 0 !== strpos(DROIP_CONTENT_MANAGER_PREFIX, $post->post_type)) {
					$meta_key = ContentManagerHelper::get_child_post_meta_key_using_field_id($post->post_parent, $content_value);
					$content = get_post_meta($post->ID, $meta_key, true);

					$fields = ContentManagerHelper::get_post_type_custom_field_keys($post->post_parent);

					if(isset($fields[$content_value]) && $fields[$content_value]['type'] === 'date'){
						$content = self::format_date($content, $fields[$content_value]['default_format']);
					}
					if ( isset($fields[$content_value]['type']) && $fields[$content_value]['type'] === 'image' ) {
						$content = array(
							'wp_attachment_id' =>  $content['id'] ?? '',
							'src' => $content['url'] ?? '',
						);
					}
					if(isset($fields[$content_value]['type']) && $fields[$content_value]['type'] === 'time') {
						$time = "";

						if(isset($fields[$content_value], $fields[$content_value]['default_value']) && $fields[$content_value]['default_value']){
							$default_time = $fields[$content_value]['default_value'];
							$time = $default_time['value'] . ' '. $default_time['unit'];
						}

						$content = $content ? $content['value'] . ' '. $content['unit'] : $time;
					}

				} else {
					$content = 'Not Implemented';
				}

				break;
			}
		}

		return $content ? $content : '';
	}

	public static function retrieve_post_content($post_id) {
		$content = apply_filters( 'the_content', get_the_content(null, false, $post_id ) );

		$load_for = HelperFunctions::sanitize_text( isset( $_GET['load_for'] ) ? $_GET['load_for'] : '' );

		if ($load_for !== 'droip-iframe' && $droip_data = HelperFunctions::is_droip_type_data($post_id)) {
			$content =  apply_filters( 'the_content', HelperFunctions::get_html_using_preview_script( $droip_data['blocks'], $droip_data['styles'], 'root', $post_id ));
		}

		return $content;
	}

	/**
	 * This methos is for if Theme enque some style and css then it will remove those styel and css codes.
	 *
	 * @return void
	 */
	public static function remove_theme_style() {
		$theme        = wp_get_theme();
		$parent_style = $theme->stylesheet . '-style';
		wp_dequeue_style( $parent_style );
		wp_deregister_style( $parent_style );
		wp_dequeue_style( $parent_style . '-css' );
		wp_deregister_style( $parent_style . '-css' );
	}

	public static function dequeue_all_except_my_plugin() {
    global $wp_scripts, $wp_styles, $droip_editor_assets;

    // Dequeue all scripts
    foreach ($wp_scripts->queue as $handle) {
        wp_dequeue_script($handle);
    }

    // Dequeue all styles
    foreach ($wp_styles->queue as $handle) {
        wp_dequeue_style($handle);
    }

    // Re-enqueue your plugin's scripts
    foreach ($droip_editor_assets['scripts'] as $script_handle) {
        wp_enqueue_script($script_handle);
    }

    // Re-enqueue your plugin's styles
    foreach ($droip_editor_assets['styles'] as $style_handle) {
        wp_enqueue_style($style_handle);
    }
	}

	/**
	 * Generate html using Preview script.
	 *
	 * @param array  $data blocks.
	 * @param array  $style_blocks style_blocks.
	 * @param string $root data root.
	 * @param int    $id if need prefix like symbol or popup post_id.
	 * @return string  the html string.
	 */
	public static function get_html_using_preview_script( $data, $style_blocks, $root = null, $post_symbol_or_template_id = null, $options = [] ) {
		$preview                = new Preview( $data, $style_blocks, $root, $post_symbol_or_template_id );
		$html                   = $preview->getHtml( $options );// this method need to call first cause after that only used style block array construct.
		$only_used_style_blocks = $preview->get_only_used_style_blocks();
		$s                      = $preview->getCustomFontsLinks();
		$s                     .= $preview->getStyleTag( $only_used_style_blocks );
		$s                     .= $html;
		$s                     .= $preview->getScriptTag();
		return $s;
	}

	/**
	 * Generate new id and html string for: symbol, collection etc.
	 *
	 * @param array  $data blocks.
	 * @param array  $style_blocks style_blocks.
	 * @param string $root data root.
	 */
	public static function rec_update_data_id_then_return_new_html( $data, $style_blocks, $root = 'body', $options = [] ) {
		$data_helper = new DataHelper();
		$data_helper->rec_update_data_id_to_new_id( $data, $root );
		$data = $data_helper->temp_data;
		$root = $data_helper->temp_ids[ $root ];
		return self::get_html_using_preview_script( $data, $style_blocks, $root, null, $options );
	}

	// hook
	public static function droip_html_generator( $s, $post_id ) {
		$d = self::is_droip_type_data( $post_id );
		if($d){
			return self::get_html_using_preview_script( $d['blocks'], $d['styles'], 'root', $post_id );
		}
		return false;
	}
	/**
	 * Find symbol for post id using condition
	 * it will find and return selected symbols html and css;
	 *
	 * @param string $type : symbol type.
	 * @param string $post : post object.
	 * @return symbol || bool(false)
	 */
	public static function find_template_for_this_post( $post ) {
		$templates = Page::fetch_list(DROIP_APP_PREFIX . '_template', true, $post_status = array('publish'));
		foreach ( $templates as $key => $template ) {
			if ( isset( $template['conditions'] ) ) {
				$conditions = $template['conditions'];
				if ( self::check_all_conditions_for_this_post( $post, $conditions ) ) {
					return $template;
				}
			}
		}
		return false;
	}

	/**
	 * Get Custom Header
	 * it will find and return selected symbols html and css;
	 *
	 * @param string $type stymbol type header|footer.
	 * @param string $html if true the function will return html otherwise return symbol object.
	 * @return string|object custom section html or stymbol object.
	 */
	public static function get_page_custom_section( $type, $html = true ) {
		global $post;
		if ( $post ) {
			$symbol = self::find_symbol_for_this_post( $type, $post );
			if ( ! $html ) {
				return $symbol;
			}

			if ( $symbol ) {
				$symbol_data = $symbol['symbolData'];
				return self::get_html_using_preview_script( $symbol_data['data'], $symbol_data['styleBlocks'], $symbol_data['root'], $symbol['id'] );
			}
		}
		return '';
	}

	/**
	 * Generate popup html
	 *
	 * @return strint
	 */
	public static function get_page_popups_html() {
		global $post;
		if ( $post ) {
			$popups = self::get_page_popups();
			if ( count( $popups ) > 0 ) {
				$s = '';
				foreach ( $popups as $key => $popup ) {
					$s .= self::get_html_using_preview_script( $popup['blocks'], $popup['styleBlocks'], $popup['root'], $popup['id'] );
				}
				return $s;
			}
		}
		return '';
	}

	/**
	 * Get Custom popups
	 * it will find and return selected popups;
	 *
	 * @return array
	 */
	public static function get_page_popups() {
		global $post;
		if ( $post ) {
			$popups = Page::fetch_list( DROIP_APP_PREFIX . '_popup', true, array( 'publish' ) );
			return self::find_popups_for_this_post( $popups, $post );
		}
		return array();
	}

	/**
	 * Find popups for post id using condition
	 * it will find and return selected popups arr;
	 *
	 * @param object $popups popup block object.
	 * @param object $post post object.
	 * @return popups || [];
	 */
	public static function find_popups_for_this_post( $popups, $post ) {
		$arr     = array();
		$post_id = $post->ID;
		foreach ( $popups as $key => $popup ) {
			$popup = self::format_single_popup_data_for_html_print( $popup );
			if ( self::check_popup_pagearr_logic( $popup, $post_id ) ) {
				$arr[] = $popup;
			}
		}
		return $arr;
	}

	private static function format_single_popup_data_for_html_print( $popup ) {
		$root = false;
		foreach ( $popup['blocks'] as $key2 => &$b ) {
			if ( 'root' === $b['parentId'] ) {
				$root = $b['id'];

				if ( isset( $b['properties']['attributes'] ) ) {
					$b['properties']['attributes']['popup-id'] = $popup['id'];
				} else {
					$b['properties']['attributes'] = array(
						'popup-id' => $popup['id'],
					);
				}
				$popup['root'] = $root;
			}
		}

		return $popup;
	}

	/**
	 * Check popup is active apply for this post or not.
	 *
	 * @param array $popup popup from Page::fetch_list.
	 * @param int   $post_id wp post id.
	 * @return bool
	 */
	private static function check_popup_pagearr_logic( $popup, $post_id ) {
		$root = $popup['root'];
		if ( $root && isset( $popup['blocks'][ $root ]['properties']['popup']['visibilityConditions'] ) ) {
			$conditions = $popup['blocks'][ $root ]['properties']['popup']['visibilityConditions'];
			$post       = get_post( $post_id );
			if ( self::check_all_conditions_for_this_post( $post, $conditions ) || in_array( $popup['id'], Preview::$only_used_popup_id_array, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Find symbol for post id using condition
	 * it will find and return selected symbols html and css;
	 *
	 * @param string $type : symbol type.
	 * @param string $post : post object.
	 * @return symbol || bool(false)
	 */
	public static function find_symbol_for_this_post( $type, $post ) {
		$all_symbols = Symbol::fetch_list( true, false );
		foreach ( $all_symbols as $key => $symbol ) {
			if ( $symbol['type'] === $type && isset( $symbol['symbolData']['conditions'] ) ) {
				$conditions = $symbol['symbolData']['conditions'];
				if ( self::check_all_conditions_for_this_post( $post, $conditions ) ) {
					return $symbol;
				}
			}
		}
		return false;
	}

	/**
	 * Check all conditon for this post
	 * This method will match all the condition and return true or false
	 * category = * || post_type
	 * taxonomy = 1=single post || * = all post || taxonomy slug
	 * apply[to] = * = all || id = post id || term id
	 * visibility = show || hide
	 *
	 * @param object $post post object.
	 * @param object $conditions symbol visibility condiotions object.
	 *
	 * @return Boolean
	 */
	public static function check_all_conditions_for_this_post( $post, $conditions ) {
		$show_flag = false;
		$hide_flag = false;
		
		foreach ( $conditions as $key => $condition ) {
			if(!isset($condition['taxonomy'])){
				return self::check_legecy_conditions($post, $conditions);
			}
			if($condition['category'] === '*'){
				//entire site
				$show_flag = $condition['visibility'] === 'show';
			}else if (strpos($condition['category'], DROIP_CONTENT_MANAGER_PREFIX) !== false) {
				//content manager related post
				$post_parent = str_replace(DROIP_CONTENT_MANAGER_PREFIX . '_', '', $condition['category']);
				if($post->post_parent == $post_parent){
					return true;
				}
			}else if($condition['category'] === $post->post_type){
				// post type related
				if($condition['taxonomy'] == '*'){
					//all post
					$show_flag = $condition['visibility'] === 'show';
				}else if($condition['taxonomy'] == 1){
					//single post
					if($condition['apply']['to'] === $post->ID){
						$show_flag = $condition['visibility'] === 'show';
						$hide_flag = $condition['visibility'] === 'hide';
					}
				}else{
					//taxonomy
					$taxonomy = $condition['taxonomy'];
					$term = $condition['apply']['to'];
					if($term === '*'){
						//all terms
						$show_flag = $condition['visibility'] === 'show';
					}else{
						if ( has_term( $term, $taxonomy, $post->ID ) ) {
							$show_flag = $condition['visibility'] === 'show';
							$hide_flag = $condition['visibility'] === 'hide';
						} 
					}
				}
			}
			if ( $hide_flag ) {
				return false;
			}
		}
		return $show_flag;
	}

	private static function check_legecy_conditions($post, $conditions){
		$show_flag = false;
		$hide_flag = false;
		foreach ( $conditions as $key => $condition ) {
			if ( $condition['category'] === $post->post_type ) {

				if ( $condition['visibility'] === 'show' ) {
					if ( $condition['apply'] === '*' || $condition['apply'] === $post->ID ) {
						$show_flag = true;
					}
				} elseif ( $condition['visibility'] === 'hide' ) {
					if ( $condition['apply'] === '*' || $condition['apply'] === $post->ID ) {
						$hide_flag = true;
					}
				}
			}

			if ( $hide_flag ) {
				return false;
			}
		}
		return $show_flag;
	}

	private static function attribute_in_post_table($attr = '') {
		$post_table_attributes = array(
			'ID',
			'post_author',
			'post_date',
			'post_date_gmt',
			'post_content',
			'post_title',
			'post_excerpt',
			'post_status',
			'post_name',
			'post_type',
			'post_category'
		);

		return in_array($attr, $post_table_attributes, true);
	}

	private static function sort_filters_by_relation($filter_items = array()) {
		$sorted_array = array();

		if (is_array($filter_items)) {
			array_walk($filter_items, function($item) use (&$sorted_array) {
				$relation = isset($item['relation']) ? $item['relation'] : 'OR';

				if (!isset($sorted_array[$relation])) {
					$sorted_array[$relation] = array();
				}

				unset($item['relation']);
		
				$sorted_array[$relation][] = $item;
    	});
		}

		return $sorted_array;
	}

	/**
	 * text, number, date/time, options, switch
	 */
	private static function post_table_filter_query($filter_item, $data_type) {
		$field_name = $filter_item['id'];
		$sorted_array = self::sort_filters_by_relation($filter_item['items']);

		$where_sql = '';

		array_walk($sorted_array, function($sorted_array_item, $condition) use ($data_type, $field_name, &$where_sql) {
			global $wpdb;

			$conditions = array();
			$column_name = "$wpdb->posts.$field_name";

			array_walk($sorted_array_item, function($filter_condition_item) use ($data_type, $column_name, &$conditions) {
				switch($data_type) {
					case 'text': {
						$conditions[] = PostsQueryUtils::post_table_text_query($column_name, $filter_condition_item['condition'], $filter_condition_item['value']);
						break;
					}

					// case 'date': {
					// 	$conditions[] = PostsQueryUtils::post_table_text_query($column_name, $filter_condition_item['condition'], $filter_condition_item['value']);
					// 	break;
					// }

					// case 'number': {
					// 	$conditions[] = PostsQueryUtils::post_table_number_query($column_name, $filter_condition_item['condition'], $filter_condition_item['value']);
					// 	break;
					// }

					// case 'option': {
					// 	$conditions[] = PostsQueryUtils::post_table_options_query($column_name, $filter_condition_item['condition'], $filter_condition_item['value']);
					// 	break;
					// }

					// case 'switch': {
					// 	$conditions[] = PostsQueryUtils::post_table_switch_query($column_name, $filter_condition_item['condition'], $filter_condition_item['value']);
					// 	break;
					// }

					default: {
						break;
					}
				}
			});
			
			$condition_sql = implode(" $condition ", $conditions);

			if('OR' === $condition) {
				$condition_sql = "($condition_sql)";
			}

			/**
			 * A query to 
			 * [x start with 'JoomShaper' or 'IcoFont' or 'Droip'
			 * and contains 'website' and ends with 'Ollyo']
			 * will be like below:
			 * 
			 * AND (x LIKE 'JoomShaper%' OR x LIKE 'IcoFont%' OR x LIKE 'Droip%') AND x LIKE '%website%' AND x LIKE '%Ollyo'
			 */
			$where_sql .= " AND $condition_sql";
		});

		add_filter('posts_where', function($where) use ($where_sql) {
			$where .= $where_sql;

			return $where;
		});
	}

	/**
	 * text, number, date/time, options, switch
	 * help: https://wordpress.stackexchange.com/questions/159426/meta-query-with-string-starting-like-pattern
	 */

	private static function post_meta_table_filter_query($filter_item, $key, $data_type) {
		$sorted_array = self::sort_filters_by_relation($filter_item['items']);
		$meta_query = array();

		array_walk($sorted_array, function($sorted_array_item, $condition) use (&$meta_query, $key, $data_type) {
			if (count($sorted_array_item) > 0) {
				$condition_arr = array('relation' => $condition);

				array_walk($sorted_array_item, function($filter_condition_item) use (&$condition_arr, $key, $data_type) {

					switch($data_type) {
						case 'text': {
							$condition_arr[] = PostsQueryUtils::post_meta_table_text_query($key, $filter_condition_item['condition'], $filter_condition_item['value']);
							break;
						}
	
						case 'date': {
							$condition_arr[] = PostsQueryUtils::post_meta_table_date_query($key, $filter_condition_item); // ['start-date' => '', 'end-date' => '']);
							break;
						}
	
						case 'number': {
							$condition_arr[] = PostsQueryUtils::post_meta_table_number_query($key, $filter_condition_item['condition'], $filter_condition_item['value']);
							break;
						}
	
						case 'option': {
							$condition_arr[] = PostsQueryUtils::post_meta_table_options_query($key, $filter_condition_item['condition'], $filter_condition_item['values']);
							break;
						}
	
						case 'switch': {
							$condition_arr[] = PostsQueryUtils::post_meta_table_switch_query($key, $filter_condition_item['condition']);
							break;
						}
	
						default: {
							break;
						}
					}
				});
				
				$meta_query[] = $condition_arr;
			}
		});

		return $meta_query;
	}

	/**
	 * handle legacy filter data
	 * 
	 * @param object $params filter array.
	 *
	 * @return array filter array
	 */
	public static function  handle_legacy_filter_to_new_filter($filter){
		$new_filter = array();

		foreach($filter as $key => $item){
			if(!isset($item['id']) && $item['type']){
				switch($item['type']){
					case 'date': {
						$new_filter[] = array(
							'type' => 'post_date',
							'id' => 'post_date',
							'title' => 'Post Date',
							'items' => [array(
									'start-date' => isset($item['start-date']) ? $item['start-date'] : '',
									'end-date' => isset($item['end-date']) ? $item['end-date'] : '',
									'relation' => 'OR',
							)],
						);

						break;
					}

					case 'author': {
						$new_filter[] = array(
							'type' => 'post_author',
							'id' => 'post_author',
							'title' => 'Author',
							'items' => [array(
									'condition' => 'in',
									'values' => $item['values'],
									'relation' => 'OR',
							)],
						);

						break; 
					}

					case 'category': {
						$new_filter[] = array(
							'type' => 'post_category',
							'id' => 'post_category',
							'title' => 'Category',
							'items' => [array(
									'condition' => 'in',
									'values' => $item['values'],
									'relation' => 'OR',
							)],
						);
						break;
					}

					default: {
						break;
					}
				}
			}else{
				$new_filter[] = $item;
			}
		}

		return $new_filter;
	 }

	/**
	 * Get dynamic collectiond data
	 *
	 * @param object $params query object.
	 *
	 * @return array post array
	 */
	public static function get_posts( $params ) {
		$name        = isset( $params['name'] ) ? $params['name'] : null;
		$posts_count = isset( $params['posts_count'] ) ? $params['posts_count'] : -1;
		$sorting     = isset( $params['sorting'] ) ? $params['sorting'] : null;
		$filter      = isset( $params['filter'] ) ? $params['filter'] : null;
		$offset      = isset( $params['offset'] ) ? $params['offset'] : 0;
		$inherit     = (bool)($params['inherit'] ?? false);
		$related     = (bool)($params['related'] ?? false);
		$post_parent = (int)($params['post_parent'] ?? 0);
		$post_status = isset( $params['post_status'] ) ? $params['post_status'] : 'publish';

		$args        = array(
			'numberposts' => $posts_count,
			'post_type'   => $name,
			'offset'      => $offset,
			'suppress_filters' => false,
			'post_status' => $post_status,
		);

		$filter  = self::handle_legacy_filter_to_new_filter($filter);

		if ( isset( $filter ) && is_array( $filter ) ) {
			foreach ( $filter as $filter_item ) {
				$field_name = isset( $filter_item['id'] ) ? $filter_item['id'] : '';

				if(!$field_name){
					continue;
				}

				if (self::attribute_in_post_table($filter_item['id']) && is_array($filter_item['items'])) {
					switch($field_name) {
						case 'post_excerpt':
						case 'post_content':
						case 'post_title': {
							self::post_table_filter_query($filter_item, 'text');
							break;
						}

						case 'post_date':
						case 'post_date_gmt': {
							/**
							 * $filter_item['items'] max contain one array. 
							 * in array may contain start-date, end-date
							 * Like: [{"start-date": "2020-01-01","end-date": "2020-01-02"}]
							 */
							
							if(isset($filter_item['items'], $filter_item['items'][0])) {
								$items = $filter_item['items'];
								$item = $items[0]; // Get first item in array.

								$date_query = array('column' => $field_name);
								$date_query['inclusive'] = true;

								if (!empty($item['start-date'])) {
									$date_query['after'] = $item['start-date'];
								}

								if (!empty($item['end-date'])) {
									$date_query['before'] = $item['end-date'];
								}
	
								$args['date_query'] = $date_query;
							}

							break;
						}

						case 'post_author': {
							/**
							 * $filter_item['items'] must not contain more than 2 array of conditions. 
							 * 1 array may contain 'in' conditions and another for 'not-in' conditions
							 * And values of 'in' and 'not-in' conditions should not collide
							 * Like: the condition should not be author 'in' [1, 2, 3] and 'not-in' [2, 4, 5]
							 */
							$items = $filter_item['items'];

							foreach($items as $item) {
								if ( isset( $item['condition'], $item['values'] ) && is_array( $item['values'] ) ) {
									if ( $item['condition'] === 'in' ) {
										$args['author__in'] = $item['values'];
									}
	
									if ( $item['condition'] === 'not-in' ) {
										$args['author__not_in'] = $item['values'];
									}
								}
							}

							break;
						}

						case 'post_category': {
							/**
							 * $filter_item['items'] must not contain more than 2 array of conditions. 
							 * 1 array may contain 'in' conditions and another for 'not-in' conditions
							 * And values of 'in' and 'not-in' conditions should not collide
							 * Like: the condition should not be category 'in' [1, 2, 3] and 'not-in' [2, 4, 5]
							 */
							$items = $filter_item['items'];

							foreach($items as $item) {
								if ( isset( $item['condition'], $item['values'] ) && is_array( $item['values'] ) ) {
									if ( $item['condition'] === 'in' ) {
										$args['category__in'] = $item['values'];
									}
	
									if ( $item['condition'] === 'not-in' ) {
										$args['category__not_in'] = $item['values'];
									}
								}
							}

							break;
						}
					}
				} else {
					$key = ContentManagerHelper::get_child_post_meta_key_using_field_id($post_parent, $field_name);
					$data_type = $filter_item['type'] ?? 'text';

					if (isset($args['meta_query']) && !is_array($args['meta_query'])) {
						$args['meta_query'] = array();
					}

					switch($data_type) {
						default:
						case 'rich_text':
						case 'text':
						case 'phone':
						case 'url':
						case 'email': {
							$args['meta_query'][] = self::post_meta_table_filter_query($filter_item, $key, 'text');
							break;
						}

						case 'date': {
							$args['meta_query'][] = self::post_meta_table_filter_query($filter_item, $key, 'date');
							break;
						}

						case 'number': {
							$args['meta_query'][] = self::post_meta_table_filter_query($filter_item, $key, 'number');
							break;
						}

						case 'option': {
							$args['meta_query'][] = self::post_meta_table_filter_query($filter_item, $key, 'option');
							break;
						}

						case 'switch': {
							$args['meta_query'][] = self::post_meta_table_filter_query($filter_item, $key, 'switch');
							break;
						}

						case 'taxonomy': {
							if (empty($args['tax_query'])) {
								$args['tax_query'] = array(
									'relation' => 'AND'
								);
							}

							if (
								isset($filter_item['taxonomy'], $filter_item['terms'] ) &&
								is_array( $filter_item['terms'] )
							) {
								$operators = array( 'NOT IN', 'IN' );

								$operator = 'IN';

								if (isset($filter_item['operator']) && in_array($filter_item['operator'], $operators, true)) {
									$operator = $filter_item['operator'];
								}

								$args['tax_query'][] = array(
									'taxonomy' => $filter_item['taxonomy'],
                  'field'    => 'term_id', // So far this is fixed
                  'terms'    => $filter_item['terms'],
                  'operator' => $operator,
								);
							}
							break;
						}

						case 'author': {
							if ( isset( $filter_item['condition'], $filter_item['values'] ) && is_array( $filter_item['values'] ) ) {
								if ( $filter_item['condition'] === 'is-equal' ) {
									$args['author__in'] = $filter_item['values'];
								}

								if ( $filter_item['condition'] === 'is-not-equal' ) {
									$args['author__not_in'] = $filter_item['values'];
								}
							}
							break;
						}
						
					}
				}
			}
		}

		if ( isset( $sorting ) ) {
			// Set the sort order (ASC/DESC)
			if ( isset( $sorting['order'] ) ) {
				$args['order'] = $sorting['order'];
			}
	
			// Check if the name is set and contains 'droip_cm' && not include 'droip_cm_post_meta'
			if ( isset($name) && str_contains($name, DROIP_CONTENT_MANAGER_PREFIX) && !in_array($sorting['orderby'], DROIP_WORDPRESS_SORT_BY_OPTIONS)) {
				$args['orderby'] = 'meta_value'; // Use 'meta_value' or 'meta_value_num' as needed
				if ( isset($sorting['orderby']) && !empty($sorting['orderby']) ) {
					$args['meta_key'] = ContentManagerHelper::get_child_post_meta_key_using_field_id($post_parent,$sorting['orderby']);
				}
			} else {
				// For other cases, set the orderby based on the sorting parameter
				if ( isset( $sorting['orderby'] ) && !empty($sorting['orderby']) ) {
					$args['orderby'] = $sorting['orderby'];
				}
			}
		}

		if ( $inherit || $post_parent ) {
			//TODO: if terms page then show terms post only. like tag, category.
			$args['post_parent'] = $post_parent;
		}

		if($related){
			$post_id = isset($params['related_post_parent']) ? $params['related_post_parent'] : self::get_post_id_if_possible_from_url();
			$post = get_post($post_id);
			if($post){
				$args['post_type'] = $post->post_type;
				$args['tax_query'] = self::buildTaxonomyForRelatedPosts($post);
				$args['post__not_in'] = [$post->ID];	
			}
		}

		$posts = get_posts( $args );

		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$image          = wp_get_attachment_image_src( $custom_logo_id, 'full' );

		$droip_content_manager_post_type_fields = array();
		
		if (DROIP_CONTENT_MANAGER_PREFIX === $args['post_type']) {
			$post_parent = $args['post_parent'];
			$droip_content_manager_post_type_fields = ContentManagerHelper::get_post_type_custom_field_keys($post_parent);
		}

		foreach ( $posts as  &$post ) {
			if (
				DROIP_CONTENT_MANAGER_PREFIX === $post->post_type && is_array($droip_content_manager_post_type_fields)
				) {
					foreach($droip_content_manager_post_type_fields as $field_key) {
						$meta_key = ContentManagerHelper::get_child_post_meta_key_using_field_id($post->post_parent, $field_key['id']);
						$post->{$field_key['id']} = get_post_meta($post->ID, $meta_key, true);

						if (
							isset($field_key['type']) &&
							$field_key['type'] === 'image' &&
							$post->{$field_key['id']}
						) {
							$post->{$field_key['id']} = array(
								'wp_attachment_id' => $post->{$field_key['id']}['id'],
								'src' => $post->{$field_key['id']}['url'],
							);
						}
				}
			}


			$post->post_id = $post->ID;
			$post->post_author = get_the_author_meta( 'display_name', $post->post_author );
			$post->post_time = get_the_time( '', $post->ID );
			$post->featured_image = array(
				'wp_attachment_id' => get_post_thumbnail_id( $post->ID ),
				'src' => get_the_post_thumbnail_url( $post->ID )
			);
			$post->site_logo = isset( $image[0] ) ? $image[0] : '';
			$post->author_profile_picture = get_avatar_url( $post->post_author );
			$post->post_page_link = \get_permalink( $post->ID );
			$post->author_posts_page_link = \get_author_posts_url( $post->post_author );
		};

		return $posts;
	}

	public static function buildTaxonomyForRelatedPosts(\WP_Post $post)
	{
		$taxonomies = get_object_taxonomies( $post->post_type );
			$taxQuery = [
					'relation' => 'OR',
			];

			foreach ($taxonomies as $taxonomy) {
					$taxQuery[] = [
							'taxonomy' => $taxonomy,
							'field'    => 'slug',
							'terms'    => array_filter(wp_get_object_terms($post->ID, $taxonomy, ['fields' => 'slugs']), function ($termSlug) {
									return strtolower($termSlug) !== 'uncategorized';
							}),
					];
			}


			return $taxQuery;
	}


	/**
	 * Get dynamic collectiond data
	 *
	 * @param object $params query object.
	 *
	 * @return array post array
	 */
	public static function get_comments( $params, $count = false ) {
		$offset      = isset( $params['offset'] ) ? $params['offset'] : 0;
		$parent = (int)($params['parent'] ?? 0);
		$post_id = (int)($params['post_id'] ?? 0);
		$type = ($params['type'] ?? 'comment');
		$number = (int)($params['number'] ?? 0);
		$sorting     = isset( $params['sorting'] ) ? $params['sorting'] : null;
		$filter      = isset( $params['filter'] ) ? $params['filter'] : null;
		

		$args        = array(
			'parent' => $parent,
			'post_id'   => $post_id,
			'type'   => $type,
			'offset'      => $offset,
		);

		if ( isset( $filter ) && is_array( $filter ) ) {
			foreach ( $filter as $filter_item ) {
				$field_name = isset( $filter_item['id'] ) ? $filter_item['id'] : '';

				if(!$field_name){
					continue;
				}
				switch($field_name) {
					case 'comment_date':
					case 'comment_date_gmt':{
						/**
						 * $filter_item['items'] max contain one array. 
						 * in array may contain start-date, end-date
						 * Like: [{"start-date": "2020-01-01","end-date": "2020-01-02"}]
						 */
						if(isset($filter_item['items'], $filter_item['items'][0])) {
							$items = $filter_item['items'];
							$item = $items[0]; // Get first item in array.

							$date_query = array('column' => $field_name);
							$date_query['inclusive'] = true;

							if (!empty($item['start-date'])) {
								$date_query['after'] = $item['start-date'];
							}

							if (!empty($item['end-date'])) {
								$date_query['before'] = $item['end-date'];
							}

							$args['date_query'] = $date_query;
						}

						break;
					}

					case 'comment_author': {
						$items = $filter_item['items']; // $items['items'] max contain one array. 

						foreach($items as $item) {
							if ( isset( $item['condition'], $item['values'] ) && is_array( $item['values'] ) ) {
								if ( $item['condition'] === 'in' ) {
									$args['author__in'] = $item['values'];
								}

								if ( $item['condition'] === 'not-in' ) {
									$args['author__not_in'] = $item['values'];
								}
							}
						}

						break;
					}

					case 'comment_approved': {
						$items = $filter_item['items']; //  $items['items'] max contain one array. 

						foreach($items as $item) {
							if ( isset( $item['condition'], $item['values'] ) && is_array( $item['values'] ) ) {
								if ( $item['condition'] === 'in' ) {
									$args['status'] = $item['values'];
								}
							}
						}
					}
				}
			}
		}

		if(isset($sorting)){
			// Set the sort order (ASC/DESC)
			if ( isset( $sorting['order'] ) ) {
				$args['order'] = $sorting['order'];
			}

			if ( isset( $sorting['orderby'] ) && !empty($sorting['orderby']) ) {
				$args['orderby'] = $sorting['orderby'];
			}
		}
		
		if ($number > 0) {
			$args['number'] = $number;
		}

		if ($count) {
			$args['count'] = true;
		}

		$comments = get_comments($args);

		// Some comments may not be fetched using get_comments function, so try manually
		if (empty($comments) && !isset($args['count'])) {
			global $wpdb;

			$query = self::construct_get_comments_query($args);
			$comments = $wpdb->get_results($query);
		}

		if (is_array($comments)) {
			foreach($comments as &$comment) {
				$comment = (object)(array)$comment;

				$author_posts_page_link = $comment->comment_author_url;

				if (!$author_posts_page_link) {
					$author_posts_page_link = \get_author_posts_url($comment->user_id);
				}

				$comment->author_profile_picture = get_avatar_url( $comment->user_id );
				$comment->author_posts_page_link = $author_posts_page_link;
			}
		}

		return $comments;
	}

	private static function construct_get_comments_query($params)
	{
		global $wpdb;

		$comment_type = $params['type'];
		$post_id = $params['post_id'];
		$parent = $params['parent'];
		$order = isset($params['order']) ? $params['order'] : 'DESC';
		$orderby = isset($params['orderby']) ? $params['orderby'] : 'comment_date_gmt';
		$limit = isset($params['number']) ? (int)$params['number'] : '';
		$offset = isset($params['offset']) ? (int)$params['offset'] : 0;

		if (isset($params['count']) && $params['count']) {
			$select_query = "SELECT COUNT(*) FROM $wpdb->comments";
		} else {
			$select_query = "SELECT * FROM $wpdb->comments";
		}

		$where_query = $wpdb->prepare("WHERE comment_type=%s AND comment_parent=%d AND comment_post_ID=%d", $comment_type, $parent, $post_id);

		$where_query .= self::construct_get_comments_filter_query($params);

		$order_query = "ORDER BY $orderby $order";

		if ($limit && $offset === 0) {
			$limit_query = $wpdb->prepare("LIMIT %d", $limit);
		} else if ($limit && $offset > 0) {
			$limit_query = $wpdb->prepare("LIMIT %d, %d", $offset, $limit);
		} else if (!$limit && $offset > 0) {
			$limit_query = $wpdb->prepare("LIMIT %d, %d", $offset, PHP_INT_MAX);
		} else {
			$limit_query = '';
		}

		return "$select_query $where_query $order_query $limit_query";
	}

	private static function construct_get_comments_filter_query($params)
	{
		global $wpdb;

		// Author filter
		$author_in = isset($params['author__in']) ? $params['author__in'] : '';
		$author_not_in = isset($params['author__not_in']) ? $params['author__not_in'] : '';

		// Status filter
		$status = isset($params['status']) ? $params['status'] : '';

		// Date filter
		$date_after = isset($params['date_query']['after']) ? $params['date_query']['after'] : '';
		$date_before = isset($params['date_query']['before']) ? $params['date_query']['before'] : '';

		$filter_query = '';

		if ($author_in && is_array($author_in) && count($author_in) > 0) {
			$placeholder = implode(
				',',
				array_fill(0, count($author_in), '%d')
			);

			$filter_query .= $wpdb->prepare(" AND user_id IN ($placeholder)", $author_in);
		}

		if ($author_not_in && is_array($author_not_in) && count($author_not_in) > 0) {
			$placeholder = implode(
				',',
				array_fill(0, count($author_not_in), '%d')
			);

			$filter_query .= $wpdb->prepare(" AND user_id NOT IN ($placeholder)", $author_not_in);
		}

		if ($status && is_string($status) && !empty($status)) {
			if ($status === 'hold') {
				$filter_query .= " AND comment_approved NOT IN ('approved', 1)";
			} else if ($status === 'approve') {
				$filter_query .= " AND comment_approved IN ('approved', 1)";
			}

			// For all, no need to add any filter
		}

		if ($date_after) {
			$filter_query .= $wpdb->prepare(" AND comment_date_gmt >= %s", $date_after);
		}

		if ($date_before) {
			$filter_query .= $wpdb->prepare(" AND comment_date_gmt <= %s", $date_before);
		}

		return $filter_query;
	}

	/**
	 * Remove all default assets
	 *
	 * @return void
	 */
	public static function remove_wp_assets() {
		/*
		// Remove all WordPress actions
		// remove_all_actions('wp_head');
		// remove_all_actions('wp_print_styles');
		// remove_all_actions('wp_print_head_scripts');
		// remove_all_actions('wp_footer');

		// // Handle `wp_head`
		// add_action('wp_head', 'wp_enqueue_scripts', 1);
		// add_action('wp_head', 'wp_print_styles', 8);
		// add_action('wp_head', 'wp_print_head_scripts', 9);
		// add_action('wp_head', 'wp_site_icon');

		// // Handle `wp_footer`
		// add_action('wp_footer', 'wp_print_footer_scripts', 20);

		// // Handle `wp_enqueue_scripts`
		// remove_all_actions('wp_enqueue_scripts');

		// // Also remove all scripts hooked into after_wp_tiny_mce.
		// remove_all_actions('after_wp_tiny_mce');
		*/
		// remove admin-bar.
		add_filter( 'show_admin_bar', '__return_false', PHP_INT_MAX );
	}

	/**
	 * Get server protocol
	 * currently not in use
	 *
	 * @return string protocol name.
	 */
	public static function get_protocol() {
		$protocol = isset( $_SERVER['HTTPS'] ) ? 'https' : 'http';
		return $protocol;
	}

	/**
	 * Check if the current user has specific role ($role)
	 *
	 * @param string $role The role to check.
	 * @return boolean
	 */
	public static function user_is( $role ) {
		$user  = wp_get_current_user();
		$roles = $user->roles;

		return is_array( $roles ) && count( $roles ) && in_array( $role, $roles, true ) ? true : false;
	}

	/**
	 * Check if the user has access to edit/create specific/all post
	 *
	 * @param int $post_id post id.
	 * @return boolean
	 */
	public static function user_has_post_edit_access( $post_id = '' ) {
		return $post_id ? current_user_can( 'edit_post', $post_id ) : current_user_can( 'edit_posts' );
	}

	/**
	 * Check if the user has access to edit/create specific/all page
	 *
	 * @param int $page_id post id.
	 * @return boolean
	 */
	public static function user_has_page_edit_access( $page_id = '' ) {
		return $page_id ? current_user_can( 'edit_page', $page_id ) : current_user_can( 'edit_pages' );
	}

	/**
	 * Check if the user has access to editor
	 *
	 * @return boolean
	 */
	public static function user_has_editor_access() {
		return self::has_access(
			array(
				DROIP_ACCESS_LEVELS['FULL_ACCESS'],
				DROIP_ACCESS_LEVELS['CONTENT_ACCESS'],
				DROIP_ACCESS_LEVELS['VIEW_ACCESS'],
			)
		);
	}

	/**
	 * Check if the current user has specific access
	 *
	 * @param string|string[] $access_level The access level to check access.
	 */
	public static function has_access( $access_level ) {
		$user       = wp_get_current_user();
		$roles      = $user->roles;
		$has_access = false;

		if ( is_array( $access_level ) ) {
			foreach ( $roles as $role ) {
				$access = get_option( DROIP_APP_PREFIX . '_' . $role );
				if ( ! empty( $access ) && in_array( $access, $access_level, true ) ) {
					$has_access = true;
					break;
				}
			}
		} elseif ( is_string( $access_level ) ) {
			foreach ( $roles as $role ) {
				$access = get_option( DROIP_APP_PREFIX . '_' . $role );
				if ( ! empty( $access ) && $access === $access_level ) {
					$has_access = true;
					break;
				}
			}
		}

		return $has_access;
	}

	/**
	 * This method will collect license info from droip.com
	 *
	 * @param string $license_key user license key.
	 * @return array license info.
	 */
	public static function get_my_license_info( $license_key ) {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$info = self::http_get( DROIP_CORE_PLUGIN_URL . '/?license_key=' . $license_key . '&host=' . rawurlencode( self::sanitize_text( isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : null ) ) );
		$info = json_decode( $info, true );
		if ( $info && isset( $info['success'] ) ) {
			return $info['data'];
		} else {
			return array( 'key' => $license_key );
		}
	}

	/**
	 * HTTP get
	 *
	 * @param string $url api endpoint url.
	 * @return string|bool response.
	 */
	public static function http_get( $url ) {
		try {
			$response = wp_remote_get( $url );

			if ( ( !is_wp_error($response)) && (200 === wp_remote_retrieve_response_code( $response ) ) ) {
				$responseBody = $response['body'];

				return $responseBody;
			}

			return false;
		} catch( \Exception $ex ) {
			return false;
		}
	}

	/**
	 * HTTP post
	 *
	 * @param string $url api endpoint url.
	 * @param array  $options options.
	 * @return array|WP_Error response.
	 */
	public static function http_post( $url, $options ) {
		$res = wp_remote_post( $url, $options );
		return $res;
	}

	/**
	 * Text domain load hooks
	 *
	 * @param string $handle droip handle.
	 * @return void
	 */
	public static function load_script_text_domain( $handle ) {
		wp_set_script_translations( $handle, DROIP_TEXT_DOMAIN, DROIP_ROOT_PATH . 'languages/' );
	}

	/**
	 * Check and update user license
	 *
	 * @return array full license
	 */
	public static function check_my_license() {
		$data = get_option( DROIP_WP_ADMIN_COMMON_DATA );
		if ( $data && isset( $data['license_key'], $data['license_key']['key'] ) ) {
			$license_info = self::get_my_license_info( $data['license_key']['key'] );
		} else {
			$license_info = self::get_my_license_info( '' );
		}
		if ( $data ) {
			$data['license_key'] = $license_info;
		} else {
			$data = array( 'license_key' => $license_info );
		}
		update_option( DROIP_WP_ADMIN_COMMON_DATA, $data, false );
		return $data;
	}

	/**
	 * Delete droip related meta if a post is deleted.
	 *
	 * @param int $post_id post id.
	 * @return void
	 */
	public static function delete_post_with_meta_key( $post_id ) {
		delete_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS );
		delete_post_meta( $post_id, DROIP_META_NAME_FOR_USED_STYLE_BLOCK_IDS . '_random' );
		delete_post_meta( $post_id, DROIP_APP_PREFIX );
		delete_post_meta( $post_id, DROIP_META_NAME_FOR_POST_EDITOR_MODE );
		delete_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY );
		delete_post_meta( $post_id, DROIP_GLOBAL_STYLE_BLOCK_META_KEY . '_random' );
	}
	/**
	 * Get the query string for the media type
	 *
	 * @param string $type media type.
	 * @return string The query string.
	 * @example  HelperFunctions::get_media_type_query_string('image') => 'image/jpeg, image/png, image/gif'
	 */
	public static function get_media_type_query_string( $type ) {
		return implode(
			', ',
			array_map(
				function ( $v ) {
					return "'" . $v . "'";
				},
				DROIP_SUPPORTED_MEDIA_TYPES[ $type ]
			)
		);
	}

	/**
	 * This is for component configuration/object javascript variable.
	 *
	 * @return string script tag
	 */
	public static function get_empty_variables() {
		$s  = "<script id='" . DROIP_APP_PREFIX . "-elements-property-empty-vars'>";
		$s .= 'var ' . DROIP_APP_PREFIX . 'Sliders = [], ' . DROIP_APP_PREFIX . 'Maps = [], ' . DROIP_APP_PREFIX . 'Lotties = [], ' . DROIP_APP_PREFIX . 'Popups = [], ' . DROIP_APP_PREFIX . 'Lightboxes = [], ' . DROIP_APP_PREFIX . 'ReCaptchas = [], ' . DROIP_APP_PREFIX . 'Videos = [], ' . DROIP_APP_PREFIX . 'Tabs = [], ' . DROIP_APP_PREFIX . 'Interactions = [], ' . DROIP_APP_PREFIX . 'Collections = [], ' . DROIP_APP_PREFIX . 'Dropdown = [], ' . DROIP_APP_PREFIX . 'Forms = [];';
		$s .= '</script>';
		return $s;
	}

	/**
	 * Check droip and droip pro is active or not
	 * 'droip/droip.php'
	 *
	 * @param string $plugin_main_file plugin main PHP file name.
	 * @return boolean
	 */
	public static function is_plugin_activate( $plugin_main_file ) {
		if ( in_array( $plugin_main_file, apply_filters( 'active_plugins', get_option( 'active_plugins' ) ), true ) ) {
			// plugin is activated.
			return true;
		}
		return false;
	}

	/**
	 * This function will verify nonce
	 * ACT like API calls auth middleware
	 *
	 * @param string $action ajax action name.
	 *
	 * @return void
	 */
	public static function verify_nonce( $action = -1 ) {
		//phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$nonce = self::sanitize_text( isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? $_SERVER['HTTP_X_WP_NONCE'] : null );
		if ( ! wp_verify_nonce( $nonce, $action ) ) {
			wp_send_json_error( 'Not authorized' );
			exit;
		}
	}

	/**
	 * Unslash and sanitize text
	 *
	 * @param string $v text.
	 * @return string sanitized text.
	 */
	public static function sanitize_text( $v ) {
		return sanitize_text_field( wp_unslash( $v ) );
	}

	/**
	 * Get current browser session id.
	 * this method also start the session if no session id found.
	 *
	 * @return string session id.
	 */
	public static function get_session_id() {
		// Start a session or resume an existing one.
		if ( ! session_id() ) {
			session_start();
		}
		// Get the session ID.
		$session_id = session_id();
		session_write_close();
		return $session_id;
	}

	/**
	 * Get session data by key.
	 *
	 * @param string $key The key of the session data to retrieve.
	 * @return mixed|null The session data if found, null otherwise.
	 */
	public static function get_session_data($key) {
		// Start the session or resume an existing one.
		if (!session_id()) {
				session_start();
		}

		$data = isset($_SESSION[DROIP_APP_PREFIX], $_SESSION[DROIP_APP_PREFIX][$key]) ? $_SESSION[DROIP_APP_PREFIX][$key] : null;
		// Close the session.
		session_write_close();
		return $data;
	}

	/**
	* Add or update session data.
	*
	* @param string $key The key of the session data.
	* @param mixed $value The value of the session data.
	* @return void
	*/
	public static function set_session_data($key, $value) {
		// Start the session or resume an existing one.
		if (!session_id()) {
				session_start();
		}

		if(!isset($_SESSION[DROIP_APP_PREFIX])){
			$_SESSION[DROIP_APP_PREFIX] = array();
		}
		$_SESSION[DROIP_APP_PREFIX][$key] = $value;
		// Close the session.
		session_write_close();
	}

	/**
	* Delete session data by key.
	*
	* @param string $key The key of the session data to delete.
	* @return void
	*/
	public static function delete_session_data($key) {
		// Start the session or resume an existing one.
		if (!session_id()) {
				session_start();
		}

		if(isset($_SESSION[DROIP_APP_PREFIX])){
			unset($_SESSION[DROIP_APP_PREFIX][$key]);
		}

		// Close the session.
		session_write_close();
	}


	/**
	 * Is Pro user checking function.
	 *
	 * @return bool
	 */
	public static function is_pro_user() {
		$common_data = WpAdmin::get_common_data( true );
		
		return isset( $common_data['license_key']['valid'] ) && boolval( $common_data['license_key']['valid'] ) === true;
	}

	/**
	 * Store Error log to droip server
	 *
	 * @param string $error_text the error text created in PHP.
	 *
	 * @return void
	 */
	public static function store_error_log( $error_text ) {
		$droip_version = DROIP_VERSION;

		self::http_get(
			DROIP_CORE_PLUGIN_URL . "?log_data=error&version=$droip_version&error_type=php&error_text=$error_text"
		);
	}

	/**
	 * Get all view port lists
	 *
	 * @return string viewports list variable in script markup.
	 */
	public static function get_view_port_lists() {
		$s       = '';
		$list = UserData::get_view_port_list();
		if ( $list ) {
			$s .= "<script id='" . DROIP_APP_PREFIX . "-viewport-lists'>";
			$s .= 'var ' . DROIP_APP_PREFIX . 'Viewports = ' . wp_json_encode( $list ) . ';';
			$s .= '</script>';
		}
		return $s;
	}

	/**
	 * Format the date with date format
	 *
	 * @return string
	 */
	public static function format_date($date, $format)
	{
		if ($date && $format) {
			$date_formats_arr = [
				'DD/MM/YYYY' => 'd/m/Y',
				'DD-MM-YYYY' => 'd-m-Y',
				'DD.MM.YYYY' => 'd.m.Y',
				'MM/DD/YYYY' => 'm/d/Y',
				'MM-DD-YYYY' => 'm-d-Y',
				'MM.DD.YYYY' => 'm.d.Y',
				'MMMM DD, YYYY' => 'F j, Y',
				'MMM DD, YYYY' => 'M j, Y',
				'YYYY-MM-DD' => 'Y-m-d',
				'YYYY/MM/DD' => 'Y/m/d',
				'YY.MM.DD' => 'y.m.d',
				'YY/MM/DD' => 'y/m/d',
				'YY-MM-DD' => 'y-m-d',
			];

			$date = new \DateTime($date);
			$date = $date->format($date_formats_arr[$format]);

			return $date;
		}

		return $date;
	}

	/**
	 * Get single post if has a droip type post
	 *
	 * @return object|bool
	 */
	public static function get_last_edited_droip_editor_type_page(){
		$args = array(
			'post_type'      => 'page', // Change to 'post' if you want to search for posts
			'numberposts'    => 1,      // Number of results to retrieve (change as needed)
			'meta_key'       => 'droip_editor_mode',
			'meta_value'     => 'droip',
			'orderby'        => 'modified', // Order by post date
    	'order'          => 'DESC',  // Sort in descending order
		);
		
		$pages = get_posts($args);
		if(count($pages) > 0){
			return $pages[0];
		}
		return false;
	}

	public static function get_droip_version_from_db() {
		$version = wp_cache_get(DROIP_APP_PREFIX . '_version', DROIP_DEFAULT_CACHE_GROUP);

		if (false === $version) {
			$version = get_option(DROIP_APP_PREFIX . '_version', '');
			
			if ( !empty($version) ) {
				wp_cache_set(DROIP_APP_PREFIX . '_version', $version, DROIP_DEFAULT_CACHE_GROUP);
			}
		}

		return $version;
	}

	public static function set_droip_version_in_db() {
		update_option(DROIP_APP_PREFIX . '_version', DROIP_VERSION, false);
		wp_cache_set(DROIP_APP_PREFIX . '_version', DROIP_VERSION, DROIP_DEFAULT_CACHE_GROUP);
	}

	public static function accepted_file_types_by_plugin($accepted_media_types = DROIP_SUPPORTED_MEDIA_TYPES) {
    $result = array();

    foreach ($accepted_media_types as $value) {
			if (is_array($value)) {
				$result = array_merge($result, self::accepted_file_types_by_plugin($value));
			} else {
				$result[] = $value;
			}
    }

    return $result;
	}

	public static function content_manager_link_filter($dynamic_content = array(), $href="#") {
		$current_post = get_post(self::get_post_id_if_possible_from_url());

		if ($current_post->post_type === DROIP_CONTENT_MANAGER_PREFIX) {
			$fields = ContentManagerHelper::get_post_type_custom_field_keys($current_post->post_parent);

			if (isset($fields[$dynamic_content['value']]) && is_array($fields[$dynamic_content['value']])) {
				if ('email' === $fields[$dynamic_content['value']]['type']) {
					$href = "mailto:$href";
				} else if ('phone' === $fields[$dynamic_content['value']]['type']) {
					$href = "tel:$href";
				}
			}
		}

		return $href;
	}

	public static function check_string_has_this_tags($string, $tag) {
    // Check if the string contains either a <p> tag or an <h1> tag
    return preg_match("/<".$tag."[^>]*>/i", $string) === 1;
	}
	private static function get_global_data_post_id(){
		$post_id = get_option('DROIP_GLOBAL_DATA_POST_TYPE_ID', false);
		if($post_id){
			return $post_id;
		}else{
			//this block will run only once
			$posts = get_posts(array(
				'post_type' => DROIP_GLOBAL_DATA_POST_TYPE_NAME,
				'numberposts' => 1,
			));
			if($posts){
				$post_id = $posts[0]->ID;
			}else{
				//create new post
				$post = array(
					'post_title' => DROIP_GLOBAL_DATA_POST_TYPE_NAME,
					'post_type' => DROIP_GLOBAL_DATA_POST_TYPE_NAME,
					'post_status' => 'draft'
				);
				$post_id = wp_insert_post($post);
			}
			update_option('DROIP_GLOBAL_DATA_POST_TYPE_ID', $post_id, true);
		}

		return $post_id;
	}

	/**
	 * Get global data using key
	 * 
	 */
	public static function get_global_data_using_key($key){
		//first get post using DROIP_GLOBAL_DATA_POST_TYPE_NAME post_type name. if not found then create new one.
		$post_id = self::get_global_data_post_id();
		$value = get_post_meta($post_id, $key, true);
		if(!$value){
			//this block will run only once for a option key
			$value = get_option($key);
			update_post_meta($post_id, $key, $value);
			delete_option($key);
		}
		return $value;
	}
	
	/**
	 * Get global data using key
	 * 
	 */
	public static function update_global_data_using_key($key, $value){
		$post_id = self::get_global_data_post_id();
		update_post_meta($post_id, $key, $value);
	}

	public static function get_template_data_if_current_page_is_droip_template(){
		$custom_data = get_query_var(DROIP_APP_PREFIX . '_custom_data');
		$data = false;
		if ($custom_data && isset($custom_data[DROIP_APP_PREFIX . '_template_content'])) {
			$data = array(
				'content' => $custom_data[DROIP_APP_PREFIX . '_template_content'],
				'template_id' => $custom_data[DROIP_APP_PREFIX . '_template_id']
			);
		}
		return $data;
	}

}